<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1;
}

// Database connection
$host = 'localhost';
$dbname = 'financialtracker';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get search filters from URL (same as in expenses.php)
$search_query = $_GET['search_query'] ?? '';
$filter_start_date = $_GET['start_date'] ?? '';
$filter_end_date = $_GET['end_date'] ?? '';
$filter_min_amount = $_GET['min_amount'] ?? '';
$filter_vendor = $_GET['vendor_search'] ?? '';

// Build the same query as in expenses.php
$sql = "SELECT * FROM expenses WHERE 1=1";
$params = [];

if(!empty($filter_start_date)) {
    $sql .= " AND DateSpent >= ?";
    $params[] = $filter_start_date;
}

if(!empty($filter_end_date)) {
    $sql .= " AND DateSpent <= ?";
    $params[] = $filter_end_date;
}

if(!empty($filter_min_amount)) {
    $sql .= " AND Amount >= ?";
    $params[] = $filter_min_amount;
}

if(!empty($filter_vendor)) {
    $sql .= " AND Vendor LIKE ?";
    $params[] = '%' . $filter_vendor . '%';
}

$sql .= " ORDER BY DateSpent DESC";

// Fetch filtered expenses
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$expenses = $stmt->fetchAll();

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=expenses_export_' . date('Y-m-d_H-i-s') . '.csv');

// Create output stream
$output = fopen('php://output', 'w');

// Add BOM for UTF-8
fputs($output, "\xEF\xBB\xBF");

// Add CSV headers
fputcsv($output, ['Amount', 'Vendor', 'Date', 'Description']);

// Add data rows
foreach ($expenses as $expense) {
    fputcsv($output, [
        '$' . number_format($expense['Amount'], 2),
        $expense['Vendor'],
        $expense['DateSpent'],
        $expense['Description']
    ]);
}

fclose($output);
exit;
?>