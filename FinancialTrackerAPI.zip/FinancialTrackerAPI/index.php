<?php
// =============================================
// SIMPLIFIED DASHBOARD - FIXED VERSION
// =============================================

session_start();

// Simple database configuration (remove this once you create config/database.php)
$host = 'localhost';
$dbname = 'financialtracker';
$username = 'root';
$password = '';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .nav-links {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin: 30px 0;
            flex-wrap: wrap;
        }
        .nav-links a {
            background: #007bff;
            color: white;
            padding: 12px 20px;
            text-decoration: none;
            border-radius: 6px;
            transition: background-color 0.3s;
        }
        .nav-links a:hover {
            background: #0056b3;
        }
        .welcome {
            text-align: center;
            font-size: 1.2em;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>💰 Financial Tracker Dashboard</h1>
        
        <div class="welcome">
            <p>Welcome to your Financial Tracker! Manage your income and expenses efficiently.</p>
        </div>

        <div class="nav-links">
            <a href="incomes.php">💰 Income Management</a>
            <a href="expenses.php">💸 Expense Management</a>
            <a href="login.php" style="background: #28a745;">🔐 Login</a>
        </div>

        <div style="text-align: center; margin-top: 40px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
            <h3>Getting Started</h3>
            <p>Start by managing your incomes or expenses using the links above.</p>
        </div>
    </div>
</body>
</html>