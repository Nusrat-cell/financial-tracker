<?php
// Start session to check if user is logged in
session_start();

// Redirect to login page if user is not authenticated
// This prevents unauthorized access to the edit page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection configuration
$host = 'localhost'; // Database server
$dbname = 'financialtracker'; // Database name
$username = 'root'; // Database username  
$password = ''; // Database password

try {
    // Create secure database connection using PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set error mode to exceptions for better error handling
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    // Display error and stop execution if database connection fails
    die("❌ Connection failed: " . $e->getMessage());
}

// Get existing expense data for editing
$expense = null;
if(isset($_GET['id'])) {
    // Prepare SELECT statement to get the specific expense by ID
    $stmt = $pdo->prepare("SELECT * FROM expenses WHERE ExpenseID = ?");
    $stmt->execute([$_GET['id']]);
    $expense = $stmt->fetch(); // Get single expense record
}

// Show error if expense not found
if(!$expense) {
    die("❌ Expense not found!");
}

// Update expense when form is submitted
$error = ''; // Variable to store error messages
if(isset($_POST['update_expense'])) {
    // Get form data and sanitize
    $amount = $_POST['amount'];
    $vendor = trim($_POST['vendor']);
    $date = $_POST['date_spent'];
    $description = trim($_POST['description']);
    
    // Enhanced validation - check all required fields
    if(empty($amount) || empty($vendor) || empty($date)) {
        $error = "❌ Please fill all required fields!";
    } elseif($amount <= 0) {
        $error = "❌ Amount must be greater than 0!";
    } elseif(strlen($vendor) < 2) {
        $error = "❌ Vendor must be at least 2 characters!";
    } elseif($date > date('Y-m-d')) {
        $error = "❌ Date cannot be in the future!";
    } else {
        // If validation passes, try to update the expense
        try {
            // Prepare UPDATE statement to modify expense record
            $sql = "UPDATE expenses SET Amount = ?, Vendor = ?, DateSpent = ?, Description = ? WHERE ExpenseID = ?";
            $stmt = $pdo->prepare($sql);
            
            // Execute update with form values and expense ID
            if($stmt->execute([$amount, $vendor, $date, $description, $_GET['id']])) {
                // Redirect to expenses page with success message
                header("Location: expenses.php?message=updated");
                exit();
            } else {
                $error = "❌ Error updating expense!";
            }
        } catch (Exception $e) {
            $error = "❌ Database error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Expense - Financial Tracker</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #ff6b6b 0%, #ff8e8e 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(255, 107, 107, 0.3);
            backdrop-filter: blur(10px);
            max-width: 600px;
            width: 100%;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h1 {
            color: #ff6b6b;
            font-size: 2.2rem;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }

        .header-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #ff6b6b, #ff8e8e);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }

        .error {
            background: #ffebee;
            color: #c62828;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 25px;
            text-align: center;
            border: 1px solid #ffcdd2;
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #5d5d5d;
            font-weight: 500;
            font-size: 1rem;
        }

        input, textarea, select {
            width: 100%;
            padding: 15px 18px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }

        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: #ff6b6b;
            background: white;
            box-shadow: 0 0 0 3px rgba(255, 107, 107, 0.2);
        }

        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            padding: 15px 25px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
            transition: all 0.3s ease;
            text-align: center;
            text-decoration: none;
        }

        .btn-primary {
            background: linear-gradient(135deg, #ff6b6b, #ff8e8e);
            color: white;
            box-shadow: 0 4px 15px rgba(255, 107, 107, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(255, 107, 107, 0.4);
        }

        .btn-secondary {
            background: linear-gradient(135deg, #6c757d, #5a6268);
            color: white;
            box-shadow: 0 4px 15px rgba(108, 117, 125, 0.3);
        }

        .btn-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(108, 117, 125, 0.4);
        }

        .form-note {
            text-align: center;
            color: #666;
            font-style: italic;
            margin-top: 20px;
            font-size: 0.9rem;
        }

        @media (max-width: 768px) {
            .container {
                padding: 30px 20px;
            }
            
            .btn-group {
                flex-direction: column;
            }
            
            .header h1 {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>
                <div class="header-icon">✏️</div>
                Edit Expense
            </h1>
            <p style="color: #666; margin-top: 10px;">Update your expense record below</p>
        </div>
        
        <?php if($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <!-- Amount field with validation -->
            <div class="form-group">
                <label>Amount ($)</label>
                <input type="number" name="amount" step="0.01" min="0.01" value="<?php echo $expense['Amount']; ?>" required>
            </div>
            
            <!-- Vendor field with character validation -->
            <div class="form-group">
                <label>Vendor</label>
                <input type="text" name="vendor" value="<?php echo htmlspecialchars($expense['Vendor']); ?>" required>
            </div>
            
            <!-- Date field with future date prevention -->
            <div class="form-group">
                <label>Date Spent</label>
                <input type="date" name="date_spent" value="<?php echo $expense['DateSpent']; ?>" required>
            </div>
            
            <!-- Optional description field -->
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" rows="4" placeholder="What was this expense for?"><?php echo htmlspecialchars($expense['Description']); ?></textarea>
            </div>
            
            <!-- Action buttons -->
            <div class="btn-group">
                <button type="submit" name="update_expense" class="btn btn-primary">Update Expense</button>
                <a href="expenses.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
        
        <div class="form-note">
            Make your changes and click "Update Expense" to save
        </div>
    </div>
</body>
</html>