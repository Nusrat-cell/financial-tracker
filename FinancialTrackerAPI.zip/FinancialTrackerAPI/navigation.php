<?php
// dashboard-finance2/navigation.php
?>
<nav style="background: #333; padding: 15px; color: white;">
    <a href="index.php" style="color: white; margin-right: 15px;">Dashboard</a>
    <a href="add_transaction.php" style="color: white; margin-right: 15px;">Add Transaction</a>
    <a href="manage_budgets.php" style="color: white; margin-right: 15px;">Manage Budgets</a>
    
    <!-- ADD THESE TWO LINKS -->
    <a href="../FinancialTrackerAPI/incomes.php" style="color: white; margin-right: 15px;">My Income</a>
    <a href="../FinancialTrackerAPI/expenses.php" style="color: white; margin-right: 15px;">My Expenses</a>
</nav>