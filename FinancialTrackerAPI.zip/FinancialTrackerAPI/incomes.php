

    
   
<?php
// Start session to access session variables
session_start();
// Check if user is authenticated for income access
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1; // Default user ID for testing
}

// YOUR EXISTING SUCCESS MESSAGES CODE STARTS HERE
// Check if there's a message parameter in URL
if(isset($_GET['message'])) {
    // Check if message is for updated record
    if($_GET['message'] == 'updated') {
        // Set success message for update
        $success = "✅ Income record updated successfully!";
    // Check if message is for deleted record
    } elseif($_GET['message'] == 'deleted') {
        // Set success message for deletion
        $success = "✅ Income record deleted successfully!";
    }
}
// ... KEEP ALL YOUR EXISTING CODE BELOW THISs

// Then success messages  
// Check again for message parameter (duplicate code)
if(isset($_GET['message'])) {
    // Check if update message
    if($_GET['message'] == 'updated') {
        // Set update success message
        $success = "✅ Income record updated successfully!";
    // Check if delete message
    } elseif($_GET['message'] == 'deleted') {
        // Set delete success message
        $success = "✅ Income record deleted successfully!";
    }
}

// Then rest of your incomes.php code...

// =============================================
// DATABASE CONNECTION (DATA LAYER)
// =============================================
// Database server hostname
$host = 'localhost';
// Database name
$dbname = 'financialtracker';
// Database username
$username = 'root';
// Database password
$password = '';

// Try to connect to database
try {
    // Create PDO database connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set error mode to exceptions
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// Catch connection errors
} catch(PDOException $e) {
    // Display error and stop script
    die("Database connection failed: " . $e->getMessage());
}

// =============================================
// MIDDLE LAYER - BUSINESS LOGIC
// =============================================
// Include IncomeService class file
require_once 'classes/IncomeService.class.php';
// Include BudgetService class file
require_once 'classes/BudgetService.class.php';
// Include SecurityService class file
require_once 'classes/SecurityService.class.php';

// Initialize Business Logic Services
// Create IncomeService instance
$incomeService = new IncomeService($pdo);
// Create BudgetService instance
$budgetService = new BudgetService($pdo);
// Create SecurityService instance
$securityService = new SecurityService($pdo);

// =============================================
// CREATE MISSING TABLES (DATA LAYER)
// =============================================
// Create budgets table if it doesn't exist
$pdo->exec("CREATE TABLE IF NOT EXISTS budgets (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    category VARCHAR(100) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    period VARCHAR(20) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    repeat_budget BOOLEAN DEFAULT FALSE,
    repeat_interval VARCHAR(20) DEFAULT 'monthly',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Create user_preferences table if it doesn't exist
$pdo->exec("CREATE TABLE IF NOT EXISTS user_preferences (
    
    id INT PRIMARY KEY AUTO_INCREMENT,
    
    user_id INT,
    
    balance_password VARCHAR(255),
    
    email VARCHAR(255),
    
    email_verified BOOLEAN DEFAULT FALSE,
   
    verification_code VARCHAR(6),
   
    code_expires_at DATETIME,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Create security_questions table if it doesn't exist
$pdo->exec("CREATE TABLE IF NOT EXISTS security_questions (
   
    id INT PRIMARY KEY AUTO_INCREMENT,
    
    user_id INT UNIQUE,
   
    question1 VARCHAR(255),
    
    answer1_hash VARCHAR(255),
    
    question2 VARCHAR(255),
    
    answer2_hash VARCHAR(255),
   
    question3 VARCHAR(255), 
  
    answer3_hash VARCHAR(255),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Create currencies table if it doesn't exist
$pdo->exec("CREATE TABLE IF NOT EXISTS currencies (
    
    id INT PRIMARY KEY AUTO_INCREMENT,
    
    currency_code VARCHAR(3) NOT NULL,
    
    currency_name VARCHAR(50) NOT NULL,
    
    exchange_rate DECIMAL(10,4) NOT NULL,
    
    symbol VARCHAR(5) NOT NULL
)");

// Initialize currencies if empty
// Count existing currencies
$currencyCount = $pdo->query("SELECT COUNT(*) FROM currencies")->fetchColumn();
// Check if no currencies exist
if ($currencyCount == 0) {
    // Insert default currencies
    $pdo->exec("INSERT INTO currencies (currency_code, currency_name, exchange_rate, symbol) VALUES 
        // US Dollar
        ('USD', 'US Dollar', 1.00, '$'),
        // Euro
        ('EUR', 'Euro', 0.85, '€'),
        // British Pound
        ('GBP', 'British Pound', 0.73, '£'),
        // Canadian Dollar
        ('CAD', 'Canadian Dollar', 1.25, 'C$'),
        // Bangladeshi Taka
        ('BDT', 'Bangladeshi Taka', 110.50, '৳')");
}

// =============================================
// PRESENTATION LAYER VARIABLES
// =============================================
// Get all currencies from database
$currencies = $pdo->query("SELECT * FROM currencies")->fetchAll();
// Get selected currency from session or default to USD
$selected_currency = $_SESSION['selected_currency'] ?? 'USD';
// Prepare query for current currency data
$current_currency = $pdo->prepare("SELECT * FROM currencies WHERE currency_code = ?");
// Execute query with selected currency
$current_currency->execute([$selected_currency]);
// Fetch currency data
$currency_data = $current_currency->fetch();

// Search and Filter Variables
// Get search query from URL or empty string
$search_query = $_GET['search_query'] ?? '';
// Get start date filter from URL or empty string
$filter_start_date = $_GET['start_date'] ?? '';
// Get end date filter from URL or empty string
$filter_end_date = $_GET['end_date'] ?? '';
// Get minimum amount filter from URL or empty string
$filter_min_amount = $_GET['min_amount'] ?? '';
// Get source filter from URL or empty string
$filter_source = $_GET['source_search'] ?? '';
// Search and Filter Variables (duplicate - can be removed)
$search_query = $_GET['search_query'] ?? '';
$filter_start_date = $_GET['start_date'] ?? '';
$filter_end_date = $_GET['end_date'] ?? '';
$filter_min_amount = $_GET['min_amount'] ?? '';
$filter_source = $_GET['source_search'] ?? '';

// ADD THIS LINE RIGHT HERE to fix the error:
// Determine if filters should be shown based on any filter being active
$show_filters = !empty($search_query) || !empty($filter_start_date) || !empty($filter_end_date) || !empty($filter_min_amount) || !empty($filter_source);

// Security Modal Variables
// Type of security modal to display
$security_modal_type = '';
// Error message variable
$error = '';
// Success message variable
$success = '';
// Security Modal Variables (duplicate - can be removed)
$security_modal_type = '';
$error = '';
$success = '';

// Common security questions
// Array of predefined security questions
$common_security_questions = [
    "What was the name of your first pet?",
    "In what city were you born?",
    "What is your mother's maiden name?",
    "What was the name of your elementary school?",
    "What was your childhood nickname?",
    "What is the name of your favorite childhood friend?"
];

// Time-based greeting system
// Get current hour in 24-hour format
$current_hour = date('H');
// Get current time in 12-hour format
$current_time = date('h:i A');
// Get current date in full format
$current_date = date('F j, Y');

// Determine greeting based on time of day
if ($current_hour < 12) {
    // Morning greeting
    $greeting = "Good Morning";
    // Morning icon
    $time_image = "🌅";
} elseif ($current_hour < 17) {
    // Afternoon greeting
    $greeting = "Good Afternoon"; 
    // Afternoon icon
    $time_image = "☀️";
} elseif ($current_hour < 21) {
    // Evening greeting
    $greeting = "Good Evening";
    // Evening icon
    $time_image = "🌇";
} else {
    // Night greeting
    $greeting = "Good Night";
    // Night icon
    $time_image = "🌙";
}

// Theme system
// Get current theme from session or default to light
$current_theme = $_SESSION['theme'] ?? 'light';
// Control doll visibility
$show_doll = false;
// Smart money quotes
// Array of inspirational financial quotes
$money_quotes = [
    "The best time to start budgeting was yesterday. The second best time is now.",
    "Financial freedom is available to those who learn about it and work for it.",
    "It's not about how much you earn, but how much you keep and grow.",
    "Budgeting has one rule: Do not go over budget.",
    "Every dollar saved today is a step towards financial independence tomorrow.",
    "Wealth is not built on income alone, but on disciplined spending habits.",
    "The goal isn't more money. The goal is living life on your terms.",
    "Small, consistent investments in your financial education pay the best returns.",
    "Don't tell your money where to go. Tell it where not to go and save the rest.",
    "Financial peace isn't the acquisition of stuff. It's learning to live on less than you make."
];
// Select random quote from array
$random_quote = $money_quotes[array_rand($money_quotes)];

// =============================================
// FORM PROCESSING (USING MIDDLE LAYER)
// =============================================

// ADD INCOME - Using Business Logic Layer
// Check if add income form was submitted
if(isset($_POST['add_income'])) {
    // Show doll animation
    $show_doll = true;
    
    // Try to add income
    try {
        // Call income service to add income
        $incomeService->addIncome(
            // Income amount
            $_POST['amount'],
            // Income source
            $_POST['source'],
            // Date received
            $_POST['date_received'],
            // Income description
            $_POST['description'],
            // Currency code
            $_POST['currency'] ?? 'USD'
        );
        // Set success message
        $success = "Income added successfully! Great job! 🎉";
    // Catch any errors
    } catch (Exception $e) {
        // Set error message
        $error = $e->getMessage();
    }
}

// ADD BUDGET - Using Business Logic Layer
// Check if add budget form was submitted
if(isset($_POST['add_budget'])) {
    // Try to add budget
    try {
        // Call budget service to add budget
        $budgetService->addBudget(
            // Current user ID
            $_SESSION['user_id'],
            // Budget category
            $_POST['budget_category'],
            // Budget amount
            $_POST['budget_amount'],
            // Budget period
            $_POST['budget_period'],
            // Whether budget repeats (checkbox)
            isset($_POST['repeat_budget']),
            // Repeat interval if applicable
            $_POST['repeat_interval'] ?? 'monthly'
        );
        // Set success message with repeat status
        $success = "Budget set successfully! 🎯" . (isset($_POST['repeat_budget']) ? " (Auto-repeat enabled)" : "");
    // Catch any errors
    } catch (Exception $e) {
        // Set error message
        $error = $e->getMessage();
    }
}

// SETUP SECURITY QUESTIONS - Using Business Logic Layer
// Check if security questions form was submitted
if (isset($_POST['setup_security_questions'])) {
    // Try to setup security questions
    try {
        // Call security service to setup questions
        $securityService->setupSecurityQuestions(
            // Current user ID
            $_SESSION['user_id'],
            // First question
            $_POST['question1'],
            // First answer
            $_POST['answer1'],
            // Second question
            $_POST['question2'],
            // Second answer
            $_POST['answer2'],
            // Third question
            $_POST['question3'],
            // Third answer
            $_POST['answer3']
        );
        // Set success message
        $success = "Security questions set up successfully! 🛡️";
        // Switch to security dashboard modal
        $security_modal_type = 'security_dashboard';
    // Catch any errors
    } catch (Exception $e) {
        // Set error message
        $error = $e->getMessage();
        // Stay on security questions setup modal
        $security_modal_type = 'security_questions_setup';
    }
}

// VERIFY SECURITY QUESTIONS - Using Business Logic Layer
// Check if security verification form was submitted
if (isset($_POST['verify_security_and_reset'])) {
    // Try to verify and reset password
    try {
        // Verify security questions answers
        if (!$securityService->verifySecurityQuestions(
            // Current user ID
            $_SESSION['user_id'],
            // First answer
            $_POST['answer1'],
            // Second answer
            $_POST['answer2'],
            // Third answer
            $_POST['answer3']
        )) {
            // Throw error if answers don't match
            throw new Exception("One or more security answers are incorrect!");
        }
        
        // Check if new passwords match
        if ($_POST['new_password'] !== $_POST['repeat_password']) {
            // Throw error if passwords don't match
            throw new Exception("New passwords don't match!");
        }
        
        // Set new balance password
        $securityService->setBalancePassword($_SESSION['user_id'], $_POST['new_password']);
        // Set success message
        $success = "Password reset successfully! You can now view your balance. 🔓";
        // Mark balance as verified
        $_SESSION['balance_verified'] = true;
        // Close security modal
        $security_modal_type = '';
    // Catch any errors
    } catch (Exception $e) {
        // Set error message
        $error = $e->getMessage();
        // Stay on verify security questions modal
        $security_modal_type = 'verify_security_questions';
    }
}

// CHANGE CURRENCY
// Check if currency change form was submitted
if (isset($_POST['change_currency'])) {
    // Get selected currency
    $selected_currency = $_POST['currency'];
    // Store in session
    $_SESSION['selected_currency'] = $selected_currency;
    // Redirect to refresh page with new currency
    header("Location: incomes.php");
    // Stop script execution
    exit();
}

// OPEN SECURITY MODAL
// Check if security modal open request was submitted
if (isset($_POST['open_security_modal'])) {
    // Set modal type from request
    $security_modal_type = $_POST['modal_type'];
}

// CLOSE SECURITY MODAL
// Check if security modal close request was submitted
if (isset($_POST['close_security_modal'])) {
    // Clear modal type to close it
    $security_modal_type = '';
}

// FORGOT PASSWORD - SECURITY QUESTIONS VERIFICATION
// Check if forgot password request was submitted
if (isset($_POST['forgot_password_security'])) {
    // Check if user has security questions set up
    if ($securityService->hasSecurityQuestions($_SESSION['user_id'])) {
        // Show security questions verification modal
        $security_modal_type = 'verify_security_questions';
        // Set forgot password mode
        $_SESSION['forgot_password_mode'] = true;
    } else {
        // Show error if no security questions
        $error = "No security questions set up. Please set up security questions first.";
        // Redirect to security questions setup
        $security_modal_type = 'security_questions_setup';
    }
}

// CHANGE BALANCE PASSWORD
// Check if change password form was submitted
if (isset($_POST['change_balance_password'])) {
    // Get old password from form
    $old_password = $_POST['old_password'];
    // Get new password from form
    $new_password = $_POST['new_password'];
    // Get repeated password from form
    $repeat_password = $_POST['repeat_password'];
    
    // Verify current password
    if (!$securityService->verifyBalancePassword($_SESSION['user_id'], $old_password)) {
        // Set error if current password is wrong
        $error = "Current password is incorrect!";
        // Stay on change password modal
        $security_modal_type = 'change_password';
    // Check if new passwords match
    } elseif ($new_password !== $repeat_password) {
        // Set error if passwords don't match
        $error = "New passwords don't match!";
        // Stay on change password modal
        $security_modal_type = 'change_password';
    } else {
        // Try to change password
        try {
            // Set new balance password
            $securityService->setBalancePassword($_SESSION['user_id'], $new_password);
            // Set success message
            $success = "Balance password changed successfully! 🔒";
            // Require re-verification
            $_SESSION['balance_verified'] = false;
        // Catch any errors
        } catch (Exception $e) {
            // Set error message
            $error = $e->getMessage();
        }
    }
}

// BALANCE PASSWORD MODAL
// Initialize balance visibility
$balance_visible = false;
// Initialize password modal visibility
$show_password_modal = false;

// Check if balance is already verified
if (isset($_SESSION['balance_verified']) && $_SESSION['balance_verified']) {
    // Show balance if verified
    $balance_visible = true;
}

// Check if balance modal request was submitted
if (isset($_POST['show_balance_modal'])) {
    // Check if user has balance password set
    if ($securityService->hasBalancePassword($_SESSION['user_id'])) {
        // Show password modal
        $show_password_modal = true;
    } else {
        // Show balance directly if no password
        $balance_visible = true;
        // Mark as verified
        $_SESSION['balance_verified'] = true;
    }
}

// Check if balance password verification was submitted
if (isset($_POST['check_balance_password'])) {
    // Verify balance password
    if ($securityService->verifyBalancePassword($_SESSION['user_id'], $_POST['balance_password'])) {
        // Show balance if correct
        $balance_visible = true;
        // Mark as verified
        $_SESSION['balance_verified'] = true;
        // Hide password modal
        $show_password_modal = false;
        // Set success message
        $success = "Access granted!";
    } else {
        // Set error for wrong password
        $error = "Incorrect balance password!";
        // Keep modal open
        $show_password_modal = true;
    }
}

// Check if balance modal cancellation was submitted
if (isset($_POST['cancel_balance_modal'])) {
    // Hide password modal
    $show_password_modal = false;
}

// Check if balance logout was requested
if (isset($_POST['logout_balance'])) {
    // Remove balance verification
    $_SESSION['balance_verified'] = false;
    // Hide balance
    $balance_visible = false;
    // Set success message
    $success = "Logged out from balance view!";
}

// =============================================
// DATA RETRIEVAL (USING MIDDLE LAYER)
// =============================================

// Get statistics using Business Logic Layer
// Get income statistics from service
$stats = $incomeService->getIncomeStats();
// Calculate total amount in selected currency
$total_amount = ($stats['total_amount_usd'] ?? 0) * $currency_data['exchange_rate'];

// Get budgets using Business Logic Layer
// Get user budgets from service
$user_budgets = $budgetService->getUserBudgets($_SESSION['user_id']);

// Get incomes for table using Business Logic Layer
// Get filtered incomes from service
$incomes = $incomeService->searchIncomes(
    // Search query
    $search_query,
    // Start date filter
    $filter_start_date,
    // End date filter
    $filter_end_date,
    // Minimum amount filter
    $filter_min_amount,
    // Source filter
    $filter_source
);

// Security status checks using Business Logic Layer
// Check if user has balance password
$has_password = $securityService->hasBalancePassword($_SESSION['user_id']);
// Check if user has security questions
$has_security_questions = $securityService->hasSecurityQuestions($_SESSION['user_id']);

// Debts/Loans data (keep your existing code for this)
// Prepare query for user debts/loans
$debts_loans = $pdo->prepare("SELECT * FROM debts_loans WHERE user_id = ? AND status != 'paid'");
// Execute query with user ID
$debts_loans->execute([$_SESSION['user_id']]);
// Fetch all debts/loans
$user_debts_loans = $debts_loans->fetchAll();

// Check for upcoming payments (keep your existing code for this)
// Calculate date one week from now
$one_week_later = date('Y-m-d', strtotime('+1 week'));
// Prepare query for upcoming payments
$upcoming_payments = $pdo->prepare("SELECT * FROM debts_loans WHERE user_id = ? AND due_date <= ? AND due_date >= ? AND status = 'pending'");
// Execute query with date range
$upcoming_payments->execute([$_SESSION['user_id'], $one_week_later, date('Y-m-d')]);
// Fetch all notifications
$notifications = $upcoming_payments->fetchAll();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Income Management - Financial Tracker</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* =============================================
           PROFESSIONAL FINANCIAL COLOR PALETTE
        ============================================= */
        :root {
            --primary-bg: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            --card-bg: rgba(255, 255, 255, 0.95);
            --text-color: #2c3e50;
            --header-bg: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
            --accent-color: #27ae60;
            --accent-secondary: #2980b9;
            --danger-color: #e74c3c;
            --warning-color: #f39c12;
            --success-color: #27ae60;
        }

        [data-theme="dark"] {
            --primary-bg: linear-gradient(135deg, #0f1c30 0%, #1a3658 100%);
            --card-bg: rgba(44, 62, 80, 0.95);
            --text-color: #ecf0f1;
            --header-bg: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            --accent-color: #2ecc71;
            --accent-secondary: #3498db;
            --danger-color: #e74c3c;
            --warning-color: #f39c12;
            --success-color: #27ae60;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: var(--primary-bg);
            min-height: 100vh;
            color: var(--text-color);
            position: relative;
            overflow-x: hidden;
            transition: all 0.3s ease;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            position: relative;
            z-index: 1;
        }

        /* =============================================
           HEADER BAR - Fixed at top
        ============================================= */
        .header-bar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: var(--header-bg);
            color: white;
            padding: 15px 0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 80px;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .app-title {
            font-size: 1.8rem;
            font-weight: 600;
            letter-spacing: 1px;
        }

        .header-controls {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        /* =============================================
           IMPROVED SEARCH & FILTER SYSTEM
        ============================================= */
        .search-container {
            display: flex;
            align-items: center;
            gap: 10px;
            position: relative;
        }

        .search-form {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .search-box {
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 10px 45px 10px 15px;
            border-radius: 20px;
            width: 250px;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .search-box::placeholder {
            color: rgba(255, 255, 255, 0.8);
        }

        .search-box:focus {
            background: rgba(255, 255, 255, 0.25);
            outline: none;
            width: 300px;
        }

        .search-icon {
            position: absolute;
            right: 15px;
            color: rgba(255, 255, 255, 0.8);
            pointer-events: none;
        }

        .search-btn {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.4);
            color: white;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .search-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.05);
        }

        .filter-toggle {
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 8px 12px;
            border-radius: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .filter-toggle:hover {
            background: rgba(255, 255, 255, 0.25);
        }

        .filter-toggle.active {
            background: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.5);
        }

        /* =============================================
           IMPROVED FILTER PANEL (Integrated with Search)
        ============================================= */
        .filter-panel {
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 10px;
            background: var(--card-bg);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            border: 1px solid var(--accent-secondary);
            padding: 20px;
            min-width: 300px;
            z-index: 1001;
            display: none;
            backdrop-filter: blur(10px);
        }

        .filter-panel.active {
            display: block;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .filter-panel h3 {
            color: var(--accent-secondary);
            margin-bottom: 15px;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .filter-grid {
            display: grid;
            gap: 12px;
        }

        .filter-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }

        .filter-actions .btn {
            flex: 1;
            padding: 10px;
            font-size: 0.9rem;
        }

        /* SECURITY BUTTON STYLES */
        .security-btn {
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
        }

        .security-btn:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: scale(1.05);
        }

        .theme-toggle {
            background: rgba(255, 255, 255, 0.15);
            border: none;
            color: white;
            padding: 10px 15px;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .theme-toggle:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: scale(1.05);
        }

        .currency-selector {
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 8px 15px;
            border-radius: 15px;
            cursor: pointer;
        }

        .currency-selector option {
            color: #333;
        }

        .time-display {
            background: rgba(255, 255, 255, 0.1);
            padding: 10px 20px;
            border-radius: 25px;
            text-align: center;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .time-icon {
            font-size: 1.5rem;
            margin-bottom: 2px;
        }

        .time-greeting {
            font-weight: 600;
            font-size: 1rem;
        }

        .time-text {
            font-size: 0.8rem;
            opacity: 0.9;
        }

        /* =============================================
           SECURITY MODAL STYLES
        ============================================= */
        .security-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            z-index: 9999;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(5px);
        }

        .security-modal.active {
            display: flex;
        }

        .security-content {
            background: var(--card-bg);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            border: 2px solid var(--accent-secondary);
            max-width: 500px;
            width: 90%;
            position: relative;
            max-height: 90vh;
            overflow-y: auto;
        }

        .close-btn {
            position: absolute;
            top: 15px;
            right: 20px;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
            padding: 5px;
        }

        .password-strength {
            height: 4px;
            background: #ddd;
            border-radius: 2px;
            margin-top: 5px;
            overflow: hidden;
        }

        .strength-bar {
            height: 100%;
            width: 0%;
            transition: all 0.3s ease;
        }

        .strength-weak { background: #ff4757; width: 33%; }
        .strength-medium { background: #ffa502; width: 66%; }
        .strength-strong { background: #2ed573; width: 100%; }

        .security-question-item {
            margin-bottom: 20px;
            padding: 15px;
            background: var(--card-bg);
            border: 1px solid var(--accent-secondary);
            border-radius: 10px;
        }

        .security-status {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
            margin: 10px 0;
            border-radius: 8px;
            background: var(--card-bg);
        }

        .status-enabled {
            border-left: 4px solid #2ed573;
        }

        .status-disabled {
            border-left: 4px solid #ff4757;
        }

        /* =============================================
           MAIN CONTENT - Adjusted for fixed header
        ============================================= */
        .main-content {
            margin-top: 100px;
            min-height: calc(100vh - 120px);
        }

        /* =============================================
           HERO SECTION - 3:2 ratio
        ============================================= */
        .hero-section {
            display: grid;
            grid-template-columns: 3fr 2fr;
            gap: 30px;
            margin-bottom: 40px;
            height: 400px;
        }

        .welcome-card {
            background: var(--card-bg);
            padding: 40px;
            border-radius: 25px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            border: 2px solid var(--accent-secondary);
            display: flex;
            flex-direction: column;
            justify-content: center;
            backdrop-filter: blur(10px);
        }

        .welcome-card h1 {
            font-size: 2.8rem;
            color: var(--accent-secondary);
            margin-bottom: 15px;
            font-weight: 600;
            line-height: 1.2;
        }

        .welcome-card .quote {
            font-size: 1.3rem;
            color: var(--text-color);
            font-style: italic;
            margin-bottom: 25px;
            line-height: 1.6;
            opacity: 0.8;
        }

        .stats-card {
            background: var(--card-bg);
            padding: 40px;
            border-radius: 25px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            border: 2px solid var(--accent-secondary);
            backdrop-filter: blur(10px);
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .stat-item {
            text-align: center;
            padding: 25px 15px;
            background: var(--card-bg);
            border-radius: 15px;
            border: 1px solid var(--accent-secondary);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .stat-item:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 25px rgba(39, 174, 96, 0.3);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--accent-color);
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 0.9rem;
            color: var(--text-color);
            font-weight: 500;
            opacity: 0.8;
        }

        /* =============================================
           DOLL SYSTEM - Fixed at bottom right
        ============================================= */
        .doll-container {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 2000;
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 15px;
        }

        .doll-message {
            background: var(--card-bg);
            padding: 20px 25px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            border: 3px solid var(--warning-color);
            max-width: 280px;
            position: relative;
            animation: messagePop 0.5s ease-out;
        }

        @keyframes messagePop {
            0% { transform: translateY(100px) scale(0.8); opacity: 0; }
            100% { transform: translateY(0) scale(1); opacity: 1; }
        }

        .doll-message::after {
            content: "";
            position: absolute;
            bottom: -10px;
            right: 30px;
            border-width: 10px 10px 0 10px;
            border-style: solid;
            border-color: var(--warning-color) transparent transparent transparent;
        }

        .doll-text {
            font-size: 1.2rem;
            color: var(--warning-color);
            font-weight: 600;
            margin-bottom: 8px;
        }

        .doll-subtext {
            font-size: 1rem;
            color: var(--text-color);
            line-height: 1.4;
            opacity: 0.8;
        }

        .doll-character {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, var(--warning-color), #f1c40f);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: white;
            box-shadow: 0 10px 25px rgba(243, 156, 18, 0.4);
            cursor: pointer;
            transition: all 0.3s ease;
            animation: float 3s ease-in-out infinite;
        }

        .doll-character:hover {
            transform: scale(1.1);
            box-shadow: 0 15px 35px rgba(243, 156, 18, 0.6);
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-15px); }
        }

        /* =============================================
           CONTENT SECTIONS - 3:2 ratio grids
        ============================================= */
        .content-section {
            display: grid;
            grid-template-columns: 3fr 2fr;
            gap: 30px;
            margin-bottom: 40px;
        }

        .card {
            background: var(--card-bg);
            padding: 35px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            border: 1px solid var(--accent-secondary);
            backdrop-filter: blur(10px);
        }

        .card h2 {
            color: var(--accent-secondary);
            margin-bottom: 25px;
            font-weight: 600;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .card-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--accent-secondary), #3498db);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.4rem;
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
        }

        /* =============================================
           FORM STYLING
        ============================================= */
        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: var(--text-color);
            font-weight: 500;
        }

        input, textarea, select {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid var(--accent-secondary);
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: var(--card-bg);
            color: var(--text-color);
        }

        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: var(--accent-color);
            box-shadow: 0 0 0 3px rgba(39, 174, 96, 0.2);
        }

        .btn {
            background: linear-gradient(135deg, var(--accent-color), #2ecc71);
            color: white;
            padding: 14px 35px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(39, 174, 96, 0.3);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(39, 174, 96, 0.4);
        }

        .btn-secondary {
            background: linear-gradient(135deg, var(--accent-secondary), #3498db);
        }

        /* =============================================
           MESSAGE STYLING
        ============================================= */
        .message {
            padding: 18px;
            border-radius: 12px;
            margin-bottom: 25px;
            text-align: center;
            font-weight: 500;
            border: 1px solid;
        }

        .error {
            background: #ffebee;
            color: #c62828;
            border-color: #ffcdd2;
        }

        .success {
            background: #e8f5e9;
            color: #2e7d32;
            border-color: #c8e6c9;
        }

        /* =============================================
           BUDGET SECTION
        ============================================= */
        .budget-item {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 15px;
            border: 1px solid var(--accent-secondary);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .budget-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .budget-category {
            font-weight: 600;
            color: var(--accent-secondary);
        }

        .budget-amount {
            font-weight: 700;
            color: var(--text-color);
        }

        .budget-period {
            font-size: 0.9rem;
            opacity: 0.7;
        }

        /* =============================================
           MODAL STYLES
        ============================================= */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .password-protected {
            background: var(--card-bg);
            padding: 30px;
            border-radius: 15px;
            text-align: center;
            border: 2px dashed var(--accent-secondary);
            max-width: 400px;
            margin: 20px;
        }

        /* =============================================
           DEBT/LOAN STYLES
        ============================================= */
        .debt-widget {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 15px;
            border-left: 5px solid var(--warning-color);
            margin-bottom: 15px;
        }

        .debt-widget.loan {
            border-left-color: var(--accent-secondary);
        }

        .debt-widget.overdue {
            border-left-color: var(--danger-color);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(231, 76, 60, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(231, 76, 60, 0); }
            100% { box-shadow: 0 0 0 0 rgba(231, 76, 60, 0); }
        }

        /* =============================================
           TABLE STYLES
        ============================================= */
        .table-container {
            background: var(--card-bg);
            padding: 35px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            margin-bottom: 30px;
            border: 1px solid var(--accent-secondary);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 16px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }

        th {
            background: #f8f9fa;
            color: var(--accent-secondary);
            font-weight: 600;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .action-links a {
            color: var(--accent-secondary);
            text-decoration: none;
            margin: 0 8px;
            font-weight: 500;
            transition: color 0.3s ease;
            padding: 6px 12px;
            border-radius: 6px;
            border: 1px solid transparent;
        }

        .action-links a:hover {
            background: rgba(52, 152, 219, 0.1);
            border-color: var(--accent-secondary);
        }

        .action-links a[onclick] {
            color: var(--danger-color);
        }

        .action-links a[onclick]:hover {
            background: rgba(231, 76, 60, 0.1);
            border-color: var(--danger-color);
        }

        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            color: var(--accent-secondary);
            text-decoration: none;
            margin-top: 20px;
            padding: 12px 25px;
            background: var(--card-bg);
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
            border: 1px solid var(--accent-secondary);
        }

        .back-btn:hover {
            transform: translateX(-5px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.2);
        }

        @media (max-width: 768px) {
            .hero-section {
                grid-template-columns: 1fr;
                height: auto;
            }
            
            .content-section {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .header-controls {
                gap: 10px;
            }
            
            .security-btn {
                padding: 8px 15px;
                font-size: 0.8rem;
            }
            
            .search-box {
                width: 200px;
            }
            
            .search-box:focus {
                width: 250px;
            }
            
            .filter-panel {
                min-width: 280px;
                right: -50px;
            }
        }
    </style>
</head>
<body data-theme="<?php echo $current_theme; ?>">

    <!-- =============================================
         SECURITY MODALS - FIXED
    ============================================= -->
    <div class="security-modal <?php echo $security_modal_type ? 'active' : ''; ?>" id="securityModal">
        <div class="security-content">
            <form method="POST" style="display: inline;">
                <button type="submit" name="close_security_modal" class="close-btn">×</button>
            </form>
            
            <?php if($security_modal_type == 'change_password'): ?>
                <!-- Change Password Modal -->
                <h2 style="color: var(--accent-secondary); margin-bottom: 25px; text-align: center;">🔒 Change Balance Password</h2>
                <form method="POST">
                    <div class="form-group">
                        <label>Current Password</label>
                        <input type="password" name="old_password" placeholder="Enter current password" required>
                    </div>
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" id="newPassword" placeholder="Enter new password" required onkeyup="checkPasswordStrength()">
                        <div class="password-strength">
                            <div class="strength-bar" id="passwordStrength"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Repeat New Password</label>
                        <input type="password" name="repeat_password" placeholder="Repeat new password" required>
                    </div>
                    <div style="display: flex; gap: 10px; margin-top: 25px;">
                        <button type="submit" name="change_balance_password" class="btn" style="flex: 2;">Change Password</button>
                        <button type="button" onclick="switchToForgotPassword()" class="btn btn-secondary" style="flex: 1;">Forgot?</button>
                    </div>
                </form>

            <?php elseif($security_modal_type == 'security_questions_setup'): ?>
                <!-- Setup Security Questions -->
                <h2 style="color: var(--accent-secondary); margin-bottom: 25px; text-align: center;">🛡️ Setup Security Questions</h2>
                <p style="text-align: center; margin-bottom: 25px; color: var(--text-color);">
                    Set up security questions for password recovery
                </p>
                <form method="POST">
                    <?php for($i = 1; $i <= 3; $i++): ?>
                    <div class="security-question-item">
                        <div class="form-group">
                            <label>Security Question <?php echo $i; ?></label>
                            <select name="question<?php echo $i; ?>" required style="margin-bottom: 10px;">
                                <option value="">Select a question</option>
                                <?php foreach($common_security_questions as $question): ?>
                                    <option value="<?php echo htmlspecialchars($question); ?>"><?php echo $question; ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="answer<?php echo $i; ?>" placeholder="Your answer" required>
                        </div>
                    </div>
                    <?php endfor; ?>
                    <div style="display: flex; gap: 10px; margin-top: 25px;">
                        <button type="submit" name="setup_security_questions" class="btn" style="flex: 1;">Save Security Questions</button>
                        <button type="button" onclick="switchToSecurityDashboard()" class="btn btn-secondary" style="flex: 1;">Cancel</button>
                    </div>
                </form>

            <?php elseif($security_modal_type == 'verify_security_questions'): ?>
                <!-- Verify Security Questions -->
                <h2 style="color: var(--accent-secondary); margin-bottom: 25px; text-align: center;">🔐 Verify Your Identity</h2>
                <p style="text-align: center; margin-bottom: 25px; color: var(--text-color);">
                    Answer your security questions to reset password
                </p>
                
                <?php 
                $stmt = $pdo->prepare("SELECT * FROM security_questions WHERE user_id = ?");
                $stmt->execute([$_SESSION['user_id']]);
                $user_questions = $stmt->fetch();
                ?>
                
                <?php if($user_questions): ?>
                <form method="POST">
                    <div class="security-question-item">
                        <div class="form-group">
                            <label><?php echo htmlspecialchars($user_questions['question1']); ?></label>
                            <input type="text" name="answer1" placeholder="Your answer" required>
                        </div>
                    </div>
                    <div class="security-question-item">
                        <div class="form-group">
                            <label><?php echo htmlspecialchars($user_questions['question2']); ?></label>
                            <input type="text" name="answer2" placeholder="Your answer" required>
                        </div>
                    </div>
                    <div class="security-question-item">
                        <div class="form-group">
                            <label><?php echo htmlspecialchars($user_questions['question3']); ?></label>
                            <input type="text" name="answer3" placeholder="Your answer" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" placeholder="Enter new password" required>
                    </div>
                    <div class="form-group">
                        <label>Repeat New Password</label>
                        <input type="password" name="repeat_password" placeholder="Repeat new password" required>
                    </div>
                    
                    <div style="display: flex; gap: 10px; margin-top: 25px;">
                        <button type="submit" name="verify_security_and_reset" class="btn" style="flex: 1;">Reset Password</button>
                        <button type="button" onclick="switchToSecurityDashboard()" class="btn btn-secondary" style="flex: 1;">Cancel</button>
                    </div>
                </form>
                <?php endif; ?>

            <?php elseif($security_modal_type == 'security_dashboard'): ?>
                <!-- Security Dashboard -->
                <h2 style="color: var(--accent-secondary); margin-bottom: 25px; text-align: center;">🛡️ Security Center</h2>
                
                <!-- Security Questions Status -->
                <div class="security-status <?php echo $has_security_questions ? 'status-enabled' : 'status-disabled'; ?>">
                    <div style="font-size: 1.5rem;">❓</div>
                    <div style="flex: 1;">
                        <strong>Security Questions</strong>
                        <div style="font-size: 0.9rem; opacity: 0.8;">
                            <?php echo $has_security_questions ? 'Enabled - You can use these for password recovery' : 'Not set up - Click below to set up'; ?>
                        </div>
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 25px;">
                    <?php if($has_security_questions): ?>
                        <button type="button" onclick="switchToChangePassword()" class="btn" style="flex: 1;">Change Password</button>
                        <button type="button" onclick="switchToSecurityQuestions()" class="btn btn-secondary" style="flex: 1;">Update Questions</button>
                    <?php else: ?>
                        <button type="button" onclick="switchToSecurityQuestions()" class="btn" style="flex: 1;">Setup Security Questions</button>
                    <?php endif; ?>
                </div>
                
                <?php if($has_security_questions): ?>
                <div style="margin-top: 20px; text-align: center;">
                    <form method="POST">
                        <button type="submit" name="forgot_password_security" class="btn btn-secondary" style="width: 100%;">
                            Forgot Password? Reset with Security Questions
                        </button>
                    </form>
                </div>
                <?php endif; ?>

            <?php endif; ?>
        </div>
    </div>

    <!-- =============================================
         BALANCE PASSWORD MODAL (Your existing modal)
    ============================================= -->
    <?php if($show_password_modal): ?>
    <div class="modal" style="display: flex;">
        <div class="password-protected">
            <h3>🔒 Secure Balance Access</h3>
            <p>Enter your password to view total income</p>
            <form method="POST" class="password-form">
                <div class="form-group">
                    <input type="password" name="balance_password" placeholder="Enter your password" required style="width: 100%;">
                </div>
                <div style="display: flex; gap: 10px;">
                    <button type="submit" name="check_balance_password" class="btn" style="flex: 1;">View Balance</button>
                    <button type="submit" name="cancel_balance_modal" class="btn btn-secondary" style="flex: 1;">Cancel</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <!-- =============================================
         HEADER BAR - With IMPROVED Search & Filter System
    ============================================= -->
    <div class="header-bar">
        <div class="header-content">
            <div class="app-title">
                💼 Smart Income Management
            </div>
            <div class="header-controls">
            
     
           
   <!-- SIMPLE SEARCH -->

                <!-- SECURITY BUTTON -->
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="modal_type" value="security_dashboard">
                    <button type="submit" name="open_security_modal" class="security-btn">
                        🔒 Security Center
                    </button>
                </form>

                <!-- Your existing currency selector -->
                <form method="POST" style="display: inline;">
                    <select name="currency" class="currency-selector" onchange="this.form.submit()">
                        <?php foreach($currencies as $currency): ?>
                            <option value="<?php echo $currency['currency_code']; ?>" 
                                    <?php echo $selected_currency == $currency['currency_code'] ? 'selected' : ''; ?>>
                                <?php echo $currency['currency_code']; ?> (<?php echo $currency['symbol']; ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="hidden" name="change_currency" value="1">
                </form>

                <!-- Your existing theme toggle -->
                <button class="theme-toggle" onclick="toggleTheme()">
                    <?php echo $current_theme == 'light' ? '🌙 Dark' : '☀️ Light'; ?> Mode
                </button>

                <!-- Your existing time display -->
                <div class="time-display">
                    <div class="time-icon"><?php echo $time_image; ?></div>
                    <div class="time-greeting"><?php echo $greeting; ?>!</div>
                    <div class="time-text"><?php echo $current_time; ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- =============================================
         DOLL SYSTEM - Your existing doll
    ============================================= -->
    <div class="doll-container">
        <?php if($show_doll): ?>
        <div class="doll-message" id="dollMessage">
            <div class="doll-text">Hello there! 👋</div>
            <div class="doll-subtext">Income recorded in <?php echo $selected_currency; ?>!</div>
            <div class="doll-subtext">Keep building your wealth! 💰</div>
        </div>
        
        <script>
            setTimeout(function() {
                const dollMessage = document.getElementById('dollMessage');
                if (dollMessage) {
                    dollMessage.style.display = 'none';
                }
            }, 5000);
        </script>
        <?php endif; ?>
        
        <!-- Doll character always visible -->
        <div class="doll-character" onclick="showRandomMessage()">
            💼
        </div>
    </div>

    <div class="container">
        <div class="main-content">
            <!-- =============================================
                 HERO SECTION - Your existing hero section
            ============================================= -->
            <div class="hero-section">
                <div class="welcome-card">
                    <h1>Income Management<br>System</h1>
                    <p class="quote">"<?php echo $random_quote; ?>"</p>
                    <div style="display: flex; gap: 15px; margin-top: 20px;">
                        <div style="width: 60px; height: 60px; background: var(--accent-color); border-radius: 15px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: white;">💰</div>
                        <div style="width: 60px; height: 60px; background: var(--accent-secondary); border-radius: 15px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: white;">🌍</div>
                        <div style="width: 60px; height: 60px; background: var(--warning-color); border-radius: 15px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: white;">📊</div>
                    </div>
                </div>

                <div class="stats-card">
                    <div class="stats-grid">
                        <div class="stat-item">
                            <div class="stat-value"><?php echo $stats['total']; ?></div>
                            <div class="stat-label">Total Records</div>
                        </div>
                        <div class="stat-item">
                            <?php if($balance_visible): ?>
                                <div class="stat-value"><?php echo $currency_data['symbol'] . number_format($total_amount, 2); ?></div>
                                <div class="stat-label">Total Income</div>
                                <form method="POST" style="margin-top: 10px;">
                                    <button type="submit" name="logout_balance" class="btn" style="padding: 5px 10px; font-size: 0.8rem;">Logout</button>
                                </form>
                            <?php else: ?>
                                <form method="POST">
                                    <input type="hidden" name="show_balance_modal" value="1">
                                    <button type="submit" style="background: none; border: none; cursor: pointer; width: 100%; height: 100%;">
                                        <div class="stat-value">🔒</div>
                                        <div class="stat-label">Tap to see Balance</div>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value">🎯</div>
                            <div class="stat-label">Smart Budgeting</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value">🌍</div>
                            <div class="stat-label">Multi-Currency</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- =============================================
                 MESSAGE DISPLAY - Your existing messages
            ============================================= -->
            <?php if($error): ?>
                <div class="message error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if($success): ?>
                <div class="message success"><?php echo $success; ?></div>
            <?php endif; ?>

            <!-- =============================================
                 REST OF YOUR EXISTING CONTENT
            ============================================= -->
            <div class="content-section">
                <!-- ADD INCOME FORM -->
                <div class="card">
                    <h2>
                        <div class="card-icon">+</div>
                        Add New Income
                    </h2>
                    <form method="POST">
                        <div class="form-group">
                            <label>Amount</label>
                            <div style="display: flex; gap: 10px;">
                                <input type="number" name="amount" step="0.01" min="0.01" placeholder="0.00" required style="flex: 2;">
                                <select name="currency" required style="flex: 1;">
                                    <?php foreach($currencies as $currency): ?>
                                        <option value="<?php echo $currency['currency_code']; ?>" 
                                                <?php echo $selected_currency == $currency['currency_code'] ? 'selected' : ''; ?>>
                                            <?php echo $currency['currency_code']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Income Source</label>
                            <input type="text" name="source" placeholder="Salary, Freelance, Investment..." required>
                        </div>
                        
                        <div class="form-group">
                            <label>Date Received</label>
                            <input type="date" name="date_received" max="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Description (Optional)</label>
                            <textarea name="description" rows="3" placeholder="Additional notes about this income..."></textarea>
                        </div>
                        
                        <button type="submit" name="add_income" class="btn">Add Income Record</button>
                    </form>
                    
                <!-- QUICK ADD INCOMES -->
                                <!-- QUICK ADD INCOMES -->
                <div class="card" style="margin-top: 20px;">
                    <h3>⚡ Quick Add Common Incomes</h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-top: 15px;">
                        <form method="POST" style="display: contents;">
                            <input type="hidden" name="amount" value="2000.00">
                            <input type="hidden" name="source" value="Salary">
                            <input type="hidden" name="date_received" value="<?php echo date('Y-m-d'); ?>">
                            <input type="hidden" name="description" value="Monthly salary payment">
                            <input type="hidden" name="currency" value="<?php echo $selected_currency; ?>">
                            <button type="submit" name="add_income" class="btn" style="background: #27ae60;">💰 Salary $2000</button>
                        </form>
                        
                        <form method="POST" style="display: contents;">
                            <input type="hidden" name="amount" value="500.00">
                            <input type="hidden" name="source" value="Freelance">
                            <input type="hidden" name="date_received" value="<?php echo date('Y-m-d'); ?>">
                            <input type="hidden" name="description" value="Freelance project payment">
                            <input type="hidden" name="currency" value="<?php echo $selected_currency; ?>">
                            <button type="submit" name="add_income" class="btn" style="background: #2980b9;">💻 Freelance $500</button>
                        </form>
                        
                        <form method="POST" style="display: contents;">
                            <input type="hidden" name="amount" value="300.00">
                            <input type="hidden" name="source" value="Bonus">
                            <input type="hidden" name="date_received" value="<?php echo date('Y-m-d'); ?>">
                            <input type="hidden" name="description" value="Performance bonus">
                            <input type="hidden" name="currency" value="<?php echo $selected_currency; ?>">
                            <button type="submit" name="add_income" class="btn" style="background: #f39c12;">🎁 Bonus $300</button>
                        </form>
                        
                        <form method="POST" style="display: contents;">
                            <input type="hidden" name="amount" value="150.00">
                            <input type="hidden" name="source" value="Investment">
                            <input type="hidden" name="date_received" value="<?php echo date('Y-m-d'); ?>">
                            <input type="hidden" name="description" value="Investment returns">
                            <input type="hidden" name="currency" value="<?php echo $selected_currency; ?>">
                            <button type="submit" name="add_income" class="btn" style="background: #8e44ad;">📈 Investment $150</button>
                        </form>
                    </div>
                </div>
                </div>
                <!-- BUDGET MANAGEMENT -->
                <div class="card">
                    <h2>
                        <div class="card-icon">🎯</div>
                        Budget Management
                    </h2>
                    
                    <!-- Add Budget Form -->
                    <form method="POST" style="margin-bottom: 25px;">
                        <div class="form-group">
                            <label>Budget Category</label>
                            <input type="text" name="budget_category" placeholder="e.g., Monthly Income Goal" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Budget Amount (<?php echo $currency_data['symbol']; ?>)</label>
                            <input type="number" name="budget_amount" step="0.01" min="0.01" placeholder="0.00" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Budget Period</label>
                            <select name="budget_period" required>
                                <option value="weekly">Weekly</option>
                                <option value="monthly" selected>Monthly</option>
                                <option value="yearly">Yearly</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label style="display: flex; align-items: center; gap: 10px;">
                                <input type="checkbox" name="repeat_budget" id="repeat_budget" style="width: auto;">
                                Repeat Budget Automatically
                            </label>
                        </div>
                        
                        <div class="form-group" id="repeat_interval_group" style="display: none;">
                            <label>Repeat Interval</label>
                            <select name="repeat_interval">
                                <option value="daily">Daily</option>
                                <option value="weekly">Weekly</option>
                                <option value="monthly" selected>Monthly</option>
                                <option value="yearly">Yearly</option>
                            </select>
                        </div>
                        
                        <button type="submit" name="add_budget" class="btn btn-secondary">Set Budget</button>
                    </form>

                    <!-- Budget List -->
                    <h3 style="color: var(--accent-secondary); margin-bottom: 15px;">Your Budgets</h3>
                    <?php if(!empty($user_budgets)): ?>
                        <?php foreach($user_budgets as $budget): ?>
                            <div class="budget-item">
                                <div class="budget-header">
                                    <span class="budget-category"><?php echo htmlspecialchars($budget['category']); ?></span>
                                    <span class="budget-amount"><?php echo $currency_data['symbol'] . number_format($budget['amount'], 2); ?></span>
                                </div>
                                <div class="budget-period">
                                    <?php echo ucfirst($budget['period']); ?> • Until <?php echo $budget['end_date']; ?>
                                    <?php if(isset($budget['repeat_budget']) && $budget['repeat_budget']): ?>
                                        • 🔄 Auto-repeat (<?php echo isset($budget['repeat_interval']) ? $budget['repeat_interval'] : 'monthly'; ?>)
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p style="text-align: center; color: var(--text-color); opacity: 0.7; padding: 20px;">
                            No budgets set yet. Create your first budget above!
                        </p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- =============================================
                 DEBT/LOAN MANAGEMENT SECTION
            ============================================= -->
            <div class="content-section">
                <!-- ADD DEBT/LOAN -->
                <div class="card">
                    <h2>
                        <div class="card-icon">⏰</div>
                        Add Debt/Loan
                    </h2>
                    <form method="POST">
                        <div class="form-group">
                            <label>Type</label>
                            <select name="type" required>
                                <option value="debt">Debt (You Owe)</option>
                                <option value="loan">Loan (Owed to You)</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Amount (<?php echo $currency_data['symbol']; ?>)</label>
                            <input type="number" name="amount" step="0.01" min="0.01" placeholder="0.00" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Description</label>
                            <input type="text" name="description" placeholder="Credit card, Personal loan..." required>
                        </div>
                        
                        <div class="form-group">
                            <label>Due Date</label>
                            <input type="date" name="due_date" min="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        
                        <button type="submit" name="add_debt_loan" class="btn">Add Record</button>
                    </form>
                </div>

                <!-- ACTIVE DEBTS/LOANS -->
                <div class="card">
                    <h2>💳 Active Debts & Loans</h2>
                    <?php if(!empty($user_debts_loans)): ?>
                        <?php foreach($user_debts_loans as $debt): ?>
                            <?php
                            $due_date = new DateTime($debt['due_date']);
                            $today = new DateTime();
                            $days_until_due = $today->diff($due_date)->days;
                            $widget_class = $debt['type'];
                            if ($due_date < $today) $widget_class .= ' overdue';
                            ?>
                            <div class="debt-widget <?php echo $widget_class; ?>">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <h4><?php echo ucfirst($debt['type']); ?>: <?php echo htmlspecialchars($debt['description']); ?></h4>
                                        <p><?php echo $currency_data['symbol'] . number_format($debt['amount'], 2); ?></p>
                                        <small>Due: <?php echo $debt['due_date']; ?> 
                                            (<?php echo $due_date < $today ? 'OVERDUE' : $days_until_due . ' days'; ?>)</small>
                                    </div>
                                    <div style="font-size: 2rem;">
                                        <?php echo $debt['type'] == 'debt' ? '💳' : '🏦'; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p style="text-align: center; color: var(--text-color); opacity: 0.7; padding: 20px;">
                            No active debts or loans. Great job! 🎉
                        </p>
                    <?php endif; ?>
                </div>
            </div>
<!-- =============================================
     SIMPLE SEARCH & FILTER - LIKE EXPENSES
============================================= -->
<div class="table-container">
    <h2 style="color: var(--accent-secondary); margin-bottom: 25px; display: flex; align-items: center; gap: 15px;">
        <div class="card-icon">🔍</div>
        Search & Filter Income Records
    </h2>
    
    <!-- Simple Search Box -->
    <form method="GET" style="margin-bottom: 20px;">
        <input type="text" 
               name="search_query" 
               placeholder="Search income records..." 
               value="<?php echo htmlspecialchars($search_query); ?>"
               style="width: 100%; padding: 12px; border: 2px solid var(--accent-secondary); border-radius: 8px;">
    </form>
    
    <!-- Simple Filter Form -->
    <form method="GET" class="filter-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 20px;">
        <input type="hidden" name="search_query" value="<?php echo htmlspecialchars($search_query); ?>">
        
        <div class="form-group">
            <label>From Date</label>
            <input type="date" name="start_date" value="<?php echo htmlspecialchars($filter_start_date); ?>"
                   style="width: 100%; padding: 10px; border: 2px solid var(--accent-secondary); border-radius: 8px;">
        </div>
        
        <div class="form-group">
            <label>To Date</label>
            <input type="date" name="end_date" value="<?php echo htmlspecialchars($filter_end_date); ?>"
                   style="width: 100%; padding: 10px; border: 2px solid var(--accent-secondary); border-radius: 8px;">
        </div>
        
        <div class="form-group">
            <label>Minimum Amount (<?php echo $currency_data['symbol']; ?>)</label>
            <input type="number" name="min_amount" step="0.01" value="<?php echo htmlspecialchars($filter_min_amount); ?>" placeholder="0.00"
                   style="width: 100%; padding: 10px; border: 2px solid var(--accent-secondary); border-radius: 8px;">
        </div>
        
        <div class="form-group">
            <label>Search Source</label>
            <input type="text" name="source_search" value="<?php echo htmlspecialchars($filter_source); ?>" placeholder="Salary, Bonus, etc..."
                   style="width: 100%; padding: 10px; border: 2px solid var(--accent-secondary); border-radius: 8px;">
        </div>
        
        <div class="form-group" style="display: flex; flex-direction: column; gap: 10px;">
            <button type="submit" class="btn" style="width: 100%">Apply Filters</button>
            <a href="incomes.php" style="display: block; text-align: center; color: var(--accent-secondary); text-decoration: none; font-weight: 500;">Clear All</a>
        </div>
    </form>
</div>
            <!-- =============================================
                 INCOME HISTORY TABLE WITH EDIT/DELETE BUTTONS
            ============================================= -->
         <!-- INCOME HISTORY TABLE -->
<div class="table-container">
    <h2 style="color: var(--accent-secondary); margin-bottom: 25px; display: flex; align-items: center; gap: 15px;">
        <div class="card-icon">📋</div>
        Income History
    </h2>
    
    <!-- EXPORT BUTTON -->
    <div style="text-align: right; margin-bottom: 20px;">
        <a href="export_incomes.php" class="btn" style="background: linear-gradient(135deg, #27ae60, #2ecc71); text-decoration: none;">
            📥 Export to CSV
        </a>
    </div>
    
    <?php
    
// Display incomes with search/filter - FIXED VERSION
try {
    // Use your IncomeService for filtering
    $incomes = $incomeService->searchIncomes(
        $search_query,
        $filter_start_date,
        $filter_end_date,
        $filter_min_amount,
        $filter_source
    );
    
    if(count($incomes) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Amount</th>
                    <th>Source</th>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($incomes as $income): ?>
                <tr>
                    <td style="font-weight: 600; color: var(--accent-color);">
                        $<?php echo number_format($income['Amount'], 2); ?>
                    </td>
                    <td><?php echo htmlspecialchars($income['Source']); ?></td>
                    <td><?php echo $income['DateReceived']; ?></td>
                    <td><?php echo htmlspecialchars($income['Description']); ?></td>
                    <td class="action-links">
                        <a href="edit_income.php?id=<?php echo $income['IncomeID']; ?>">✏️ Edit</a>
                        <a href="delete_income.php?id=<?php echo $income['IncomeID']; ?>" 
                           onclick="return confirm('Are you sure you want to delete this income record?')">🗑️ Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="text-align: center; color: var(--text-color); opacity: 0.7; padding: 60px 20px; font-style: italic; font-size: 1.1rem;">
            No income records found. <?php echo ($show_filters) ? 'Try adjusting your search filters.' : 'Start tracking by adding your first income above.'; ?>
        </p>
    <?php endif;
} catch (Exception $e) {
    echo "<p style='text-align: center; color: red; padding: 20px;'>Error loading data: " . $e->getMessage() . "</p>";
}
?>
</div>

<!-- =============================================
     SIMPLE CHART - "Above and Beyond" Feature
     ADD THIS AS A SEPARATE CONTAINER AFTER THE TABLE
============================================= -->
<div class="table-container">
    <h2 style="color: var(--accent-secondary); margin-bottom: 25px; display: flex; align-items: center; gap: 15px;">
        <div class="card-icon">📊</div>
        Income Statistics Chart
    </h2>
    
    <div style="height: 300px; background: var(--card-bg); border-radius: 15px; padding: 20px;">
        <canvas id="incomeChart"></canvas>
    </div>
    
    <script>
        // Simple chart showing income distribution
        const ctx = document.getElementById('incomeChart').getContext('2d');
        const incomeChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Total Income', 'Average Income', 'Records Count'],
                datasets: [{
                    label: 'Income Statistics',
                    data: [
                        <?php echo $stats['total_amount_usd'] ?? 0; ?>,
                        <?php echo $stats['total'] > 0 ? ($stats['total_amount_usd'] / $stats['total']) : 0; ?>,
                        <?php echo $stats['total'] ?? 0; ?>
                    ],
                    backgroundColor: [
                        'rgba(39, 174, 96, 0.8)',
                        'rgba(52, 152, 219, 0.8)', 
                        'rgba(155, 89, 182, 0.8)'
                    ],
                    borderColor: [
                        'rgba(39, 174, 96, 1)',
                        'rgba(52, 152, 219, 1)',
                        'rgba(155, 89, 182, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</div>

<!-- =============================================
     NAVIGATION - Back to Zeeshan Dashboard
============================================= -->
<div style="background: #333; padding: 15px; text-align: center;">
    <a href="../dashboard-finance2/index.php" 
       style="color: white; text-decoration: none; padding: 12px 25px; background: #007bff; border-radius: 6px; font-weight: bold; display: inline-block;">
        ← Back to Zeeshan Dashboard
    </a>
      <a href="expenses.php" 
       style="color: white; text-decoration: none; padding: 12px 25px; background: #e74c3c; border-radius: 6px; font-weight: bold; display: inline-block; margin: 0 10px;">
        💸 Go to Expense Page
    </a>
</div>

<script>
    // =============================================
    // THEME MANAGEMENT FUNCTIONS
    // =============================================
    
    /**
     * Toggle between light and dark themes
     * Saves preference to localStorage and sends to server
     */
    function toggleTheme() {
        const body = document.body;
        const currentTheme = body.getAttribute('data-theme') || 'light';
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        
        // Apply new theme to body
        body.setAttribute('data-theme', newTheme);
        
        // Save to localStorage for persistence
        localStorage.setItem('theme', newTheme);
        
        // Update theme button text
        const themeButton = document.querySelector('.theme-toggle');
        if (themeButton) {
            themeButton.textContent = newTheme === 'light' ? '🌙 Dark Mode' : '☀️ Light Mode';
        }
        
        // Send theme preference to server for session persistence
        fetch('update_theme.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'theme=' + newTheme
        }).catch(err => console.log('Theme update error:', err));
    }

    // =============================================
    // DOLL CHARACTER FUNCTIONS
    // =============================================
    
    /**
     * Show random financial tip message from doll character
     */
    function showRandomMessage() {
        const messages = [
            "Smart income tracking leads to financial freedom! 🌟",
            "Every income source brings you closer to your goals! 🎯",
            "Multi-currency tracking = Global financial awareness! 🌍",
            "You're building a prosperous future! 💪",
            "Budgeting + Income tracking = Financial success! 📊",
            "Your financial journey is unique and amazing! ✨"
        ];
        
        const randomMessage = messages[Math.floor(Math.random() * messages.length)];
        
        const messageDiv = document.createElement('div');
        messageDiv.className = 'doll-message';
        messageDiv.innerHTML = `
            <div class="doll-text">Financial Tip! 💡</div>
            <div class="doll-subtext">${randomMessage}</div>
        `;
        
        const dollContainer = document.querySelector('.doll-container');
        if (dollContainer) {
            dollContainer.insertBefore(messageDiv, document.querySelector('.doll-character'));
            
            // Auto-remove message after 5 seconds
            setTimeout(() => {
                if (messageDiv.parentNode) {
                    messageDiv.remove();
                }
            }, 5000);
        }
    }

    // =============================================
    // QUICK EXPENSE/INCOME FUNCTIONS
    // =============================================
    
    /**
     * Quick expense function for common expenses
     * Fills form fields with predefined values
     */
    function quickExpense(vendor, amount) {
        // Use IDs for reliable targeting of form fields
        document.getElementById('vendorInput').value = vendor;
        document.getElementById('amountInput').value = amount;
        document.getElementById('dateInput').value = '<?php echo date('Y-m-d'); ?>';
        document.getElementById('descriptionInput').value = 'Quick add: ' + vendor;
        
        // Scroll to the form so user sees it's filled
        document.getElementById('vendorInput').scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Show confirmation message
        alert('🚀 Quick expense filled: ' + vendor + ' for $' + amount + '. Click "Add Expense Record" to save!');
    }

   
  
    // =============================================
    // BUDGET REPEAT FUNCTIONALITY
    // =============================================
    
    /**
     * Toggle repeat interval visibility based on checkbox state
     */
    function setupBudgetRepeatToggle() {
        const repeatBudgetCheckbox = document.getElementById('repeat_budget');
        if (repeatBudgetCheckbox) {
            repeatBudgetCheckbox.addEventListener('change', function() {
                const repeatIntervalGroup = document.getElementById('repeat_interval_group');
                if (repeatIntervalGroup) {
                    repeatIntervalGroup.style.display = this.checked ? 'block' : 'none';
                }
            });
        }
    }

    // =============================================
    // SECURITY MODAL FUNCTIONS
    // =============================================
    
    /**
     * Close security modal by submitting form
     */
    function closeSecurityModal() {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = '<input type="hidden" name="close_security_modal" value="1">';
        document.body.appendChild(form);
        form.submit();
    }

    /**
     * Switch to change password section in security modal
     */
    function switchToChangePassword() {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="modal_type" value="change_password">
            <input type="hidden" name="open_security_modal" value="1">
        `;
        document.body.appendChild(form);
        form.submit();
    }

    /**
     * Switch to security questions section in security modal
     */
    function switchToSecurityQuestions() {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="modal_type" value="security_questions_setup">
            <input type="hidden" name="open_security_modal" value="1">
        `;
        document.body.appendChild(form);
        form.submit();
    }

    /**
     * Switch to security dashboard section in security modal
     */
    function switchToSecurityDashboard() {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="modal_type" value="security_dashboard">
            <input type="hidden" name="open_security_modal" value="1">
        `;
        document.body.appendChild(form);
        form.submit();
    }

    /**
     * Switch to forgot password section in security modal
     */
    function switchToForgotPassword() {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="forgot_password_security" value="1">
        `;
        document.body.appendChild(form);
        form.submit();
    }

    /**
     * Check and display password strength in real-time
     */
    function checkPasswordStrength() {
        const password = document.getElementById('newPassword');
        const strengthBar = document.getElementById('passwordStrength');
        
        if (!password || !strengthBar) return;
        
        const passwordValue = password.value;
        let strength = 0;
        
        // Strength criteria
        if (passwordValue.length >= 6) strength += 1;
        if (passwordValue.match(/[a-z]/) && passwordValue.match(/[A-Z]/)) strength += 1;
        if (passwordValue.match(/\d/)) strength += 1;
        if (passwordValue.match(/[^a-zA-Z\d]/)) strength += 1;
        
        // Update strength bar
        strengthBar.className = 'strength-bar';
        if (passwordValue.length === 0) {
            strengthBar.style.width = '0%';
        } else if (strength <= 1) {
            strengthBar.classList.add('strength-weak');
            strengthBar.style.width = '25%';
        } else if (strength <= 2) {
            strengthBar.classList.add('strength-medium');
            strengthBar.style.width = '50%';
        } else if (strength <= 3) {
            strengthBar.classList.add('strength-strong');
            strengthBar.style.width = '75%';
        } else {
            strengthBar.classList.add('strength-very-strong');
            strengthBar.style.width = '100%';
        }
    }

    // =============================================
    // AUTO-SCROLL TO RESULTS AFTER SEARCH/FILTER
    // =============================================
    
    /**
     * Automatically scroll to search results when filters are applied
     */
    function autoScrollToResults() {
        const urlParams = new URLSearchParams(window.location.search);
        const hasSearch = urlParams.has('search_query') || urlParams.has('start_date') || 
                         urlParams.has('end_date') || urlParams.has('min_amount') || 
                         urlParams.has('vendor_search') || urlParams.has('source_search');
        
        if (hasSearch) {
            console.log('Search detected, scrolling to results...');
            
            // Wait for page to fully load
            setTimeout(() => {
                const tableContainers = document.querySelectorAll('.table-container');
                let resultsSection = null;
                
                // Look for the table container with expense/income history
                tableContainers.forEach(container => {
                    if (container.innerHTML.includes('Expense History') || 
                        container.innerHTML.includes('Income History') || 
                        container.innerHTML.includes('expense records') || 
                        container.innerHTML.includes('income records')) {
                        resultsSection = container;
                    }
                });
                
                // If not found, use first table container
                if (!resultsSection && tableContainers.length > 0) {
                    resultsSection = tableContainers[0];
                }
                
                // Scroll to results section if found
                if (resultsSection) {
                    console.log('Scrolling to results section');
                    resultsSection.scrollIntoView({ 
                        behavior: 'smooth',
                        block: 'start'
                    });
                    
                    // Add highlight effect to draw attention
                    resultsSection.style.transition = 'all 0.5s ease';
                    resultsSection.style.boxShadow = '0 0 0 3px var(--accent-color)';
                    setTimeout(() => {
                        resultsSection.style.boxShadow = '';
                    }, 2000);
                }
            }, 300);
        }
    }

    // =============================================
    // EVENT LISTENERS AND INITIALIZATION
    // =============================================
    
    document.addEventListener('DOMContentLoaded', function() {
        // Theme initialization
        const savedTheme = localStorage.getItem('theme') || 'light';
        document.body.setAttribute('data-theme', savedTheme);
        
        const themeButton = document.querySelector('.theme-toggle');
        if (themeButton) {
            themeButton.textContent = savedTheme === 'light' ? '🌙 Dark Mode' : '☀️ Light Mode';
        }
        
        // Initialize budget repeat toggle
        setupBudgetRepeatToggle();
        
        // Auto-scroll to search results if needed
        autoScrollToResults();
        
        // Close security modal when clicking outside
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('security-modal')) {
                closeSecurityModal();
            }
        });

        // Close security modal with Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeSecurityModal();
            }
        });
        
        // Initialize password strength checker if on password change page
        const newPasswordInput = document.getElementById('newPassword');
        if (newPasswordInput) {
            newPasswordInput.addEventListener('input', checkPasswordStrength);
        }
    });

    // =============================================
    // UTILITY FUNCTIONS
    // =============================================
    
    /**
     * Format currency values with proper symbols and decimals
     */
    function formatCurrency(amount, currency = 'USD') {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: currency
        }).format(amount);
    }
    
    /**
     * Validate email format
     */
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    /**
     * Show notification message to user
     */
    function showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <span>${message}</span>
            <button onclick="this.parentElement.remove()">×</button>
        `;
        
        // Add styles if not already added
        if (!document.querySelector('#notification-styles')) {
            const styles = document.createElement('style');
            styles.id = 'notification-styles';
            styles.textContent = `
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 15px 20px;
                    border-radius: 8px;
                    color: white;
                    z-index: 10000;
                    max-width: 300px;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                    animation: slideIn 0.3s ease;
                }
                .notification-info { background: #3498db; }
                .notification-success { background: #27ae60; }
                .notification-warning { background: #f39c12; }
                .notification-error { background: #e74c3c; }
                .notification button {
                    background: none;
                    border: none;
                    color: white;
                    font-size: 18px;
                    cursor: pointer;
                    margin-left: 10px;
                }
                @keyframes slideIn {
                    from { transform: translateX(100%); }
                    to { transform: translateX(0); }
                }
            `;
            document.head.appendChild(styles);
        }
        
        document.body.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 5000);
    }

</script>
</body>
</html>