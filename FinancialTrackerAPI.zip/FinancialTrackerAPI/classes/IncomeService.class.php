<?php
/**
 * IncomeService - Handles all income-related business logic and operations
 * Manages income CRUD operations, validation, currency conversion, and reporting
 */
class IncomeService {
    private $pdo; // Database connection object
    
    /**
     * Constructor - Dependency injection for database connection
     * @param PDO $pdo - Database connection instance
     */
    public function __construct($pdo) {
        $this->pdo = $pdo; // Store database connection for all methods to use
    }
    
    /**
     * Adds a new income record with comprehensive validation and currency conversion
     * Converts foreign currencies to USD for consistent reporting
     * 
     * @param float $amount - Income amount (must be positive)
     * @param string $source - Source of income (e.g., 'Salary', 'Freelance')
     * @param string $date_received - Date when income was received (YYYY-MM-DD)
     * @param string $description - Optional description of the income
     * @param string $currency - Currency code (default: 'USD')
     * @return bool - Success status of the database operation
     * @throws Exception - If validation fails or invalid parameters provided
     */
    public function addIncome($amount, $source, $date_received, $description = '', $currency = 'USD') {
        // Business validation rules - ensures data integrity
        // These are BUSINESS RULES that prevent invalid income records
        if ($amount <= 0) {
            throw new Exception("Amount must be greater than 0"); // Business rule: income must be positive
        }
        if (strlen($source) < 2) {
            throw new Exception("Source must be at least 2 characters"); // Business rule: source must be descriptive
        }
        // Prevent future-dated income entries for accurate financial tracking
        // This is a BUSINESS RULE: you can't record income you haven't received yet
        if ($date_received > date('Y-m-d')) {
            throw new Exception("Date cannot be in the future");
        }
        
        // Currency conversion business logic - standardize to USD for reporting
        // This is CORE BUSINESS LOGIC for multi-currency support
        $exchange_rate = 1.0; // Default to USD (no conversion needed)
        if ($currency != 'USD') {
            // Fetch current exchange rate from currencies table
            // This allows the system to handle multiple currencies
            $stmt = $this->pdo->prepare("SELECT exchange_rate FROM currencies WHERE currency_code = ?");
            $stmt->execute([$currency]);
            $rate = $stmt->fetchColumn();
            $exchange_rate = $rate ?: 1.0; // Fallback to 1.0 if rate not found (graceful degradation)
        }
        $amount_in_usd = $amount / $exchange_rate; // Convert to USD equivalent for consistent reporting
        
        // Call stored procedure for database operation
        // Using stored procedures can enhance security and performance
        // Stored procedures keep complex SQL logic in the database
        $stmt = $this->pdo->prepare("CALL sp_AddIncome(?, ?, ?, ?, ?, ?)");
        return $stmt->execute([$amount, $source, $date_received, $description, $currency, $amount_in_usd]);
    }
    
    /**
     * Retrieves all income records from the database
     * Useful for reporting and dashboard displays
     * 
     * @return array - Array of all income records
     */
    public function getAllIncomes() {
        $stmt = $this->pdo->prepare("CALL sp_GetAllIncomes()");
        $stmt->execute();
        return $stmt->fetchAll(); // Get all income records as array
    }
    
    /**
     * Retrieves a specific income record by its ID
     * 
     * @param int $id - The unique identifier of the income record
     * @return array|false - Income record or false if not found
     */
    public function getIncomeById($id) {
        $stmt = $this->pdo->prepare("CALL sp_GetIncomeById(?)");
        $stmt->execute([$id]);
        return $stmt->fetch(); // fetch() for single record (instead of fetchAll for multiple)
    }
    
    /**
     * Updates an existing income record with validation
     * 
     * @param int $id - The ID of the income record to update
     * @param float $amount - New amount (must be positive)
     * @param string $source - New source
     * @param string $date_received - New date received
     * @param string $description - New description
     * @return bool - Success status of the update operation
     * @throws Exception - If validation fails
     */
    public function updateIncome($id, $amount, $source, $date_received, $description) {
        // Reuse validation logic from addIncome for consistency
        // This ensures the same business rules apply to updates as to new records
        if ($amount <= 0) {
            throw new Exception("Amount must be greater than 0");
        }
        if (strlen($source) < 2) {
            throw new Exception("Source must be at least 2 characters");
        }
        
        $stmt = $this->pdo->prepare("CALL sp_UpdateIncome(?, ?, ?, ?, ?)");
        return $stmt->execute([$id, $amount, $source, $date_received, $description]);
    }
    
    /**
     * Deletes an income record from the database
     * 
     * @param int $id - The ID of the income record to delete
     * @return bool - Success status of the delete operation
     */
    public function deleteIncome($id) {
        $stmt = $this->pdo->prepare("CALL sp_DeleteIncome(?)");
        return $stmt->execute([$id]); // Execute deletion
    }
    
    /**
     * Searches income records with multiple filter criteria
     * Supports text search, date ranges, amount filtering, and source filtering
     * 
     * @param string $search_query - Text to search in descriptions
     * @param string $start_date - Start date for date range filter (YYYY-MM-DD)
     * @param string $end_date - End date for date range filter (YYYY-MM-DD)
     * @param float $min_amount - Minimum amount to filter by
     * @param string $source_search - Specific source to filter by
     * @return array - Array of matching income records
     */
    public function searchIncomes($search_query = '', $start_date = '', $end_date = '', $min_amount = '', $source_search = '') {
        // This provides powerful search capabilities for users
        // Users can find specific income records without scanning through everything
        $stmt = $this->pdo->prepare("CALL sp_SearchIncomes(?, ?, ?, ?, ?)");
        $stmt->execute([$search_query, $start_date, $end_date, $min_amount, $source_search]);
        return $stmt->fetchAll(); // Return all matching records
    }
    
    /**
     * Retrieves income statistics and aggregates
     * Typically used for dashboard metrics and reporting
     * 
     * @return array - Statistical data (totals, averages, etc.)
     */
    public function getIncomeStats() {
        // This is for REPORTING and DASHBOARDS
        // Provides summarized data like total income, average income, etc.
        $stmt = $this->pdo->prepare("CALL sp_GetIncomeStats()");
        $stmt->execute();
        return $stmt->fetch(); // Single row with aggregated statistics (totals, averages, etc.)
    }
}
?>