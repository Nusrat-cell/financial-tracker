<?php
/**
 * SecurityService - Handles security-related operations including:
 * - Security questions setup and verification
 * - Balance password management
 * - Security preferences checking
 */
class SecurityService {
    private $pdo; // Database connection object
    
    /**
     * Constructor - Dependency injection for database connection
     * @param PDO $pdo - Database connection instance
     */
    public function __construct($pdo) {
        $this->pdo = $pdo; // Store database connection for all methods to use
    }
    
    /**
     * Sets up or updates security questions for a user
     * Answers are hashed before storage for security
     * 
     * @param int $user_id - The user ID to associate with security questions
     * @param string $question1 - First security question
     * @param string $answer1 - Answer to first question
     * @param string $question2 - Second security question
     * @param string $answer2 - Answer to second question
     * @param string $question3 - Third security question
     * @param string $answer3 - Answer to third question
     * @return bool - Success status of the operation
     * @throws Exception - If any answer is empty
     */
    public function setupSecurityQuestions($user_id, $question1, $answer1, $question2, $answer2, $question3, $answer3) {
        // Validate that all answers are provided (trim to handle whitespace-only answers)
        // This ensures users provide meaningful security answers
        if (empty(trim($answer1)) || empty(trim($answer2)) || empty(trim($answer3))) {
            throw new Exception("All security answers are required"); // Business rule: all answers must be provided
        }
        
        // Hash answers - NEVER store security answers in plain text
        // This is CRITICAL FOR SECURITY - prevents exposure if database is compromised
        $answer1_hash = password_hash(trim($answer1), PASSWORD_DEFAULT); // Create secure hash of answer
        $answer2_hash = password_hash(trim($answer2), PASSWORD_DEFAULT);
        $answer3_hash = password_hash(trim($answer3), PASSWORD_DEFAULT);
        
        // UPSERT operation: INSERT or UPDATE if user already has questions
        // This handles both initial setup and updates to existing questions
        $sql = "INSERT INTO security_questions (user_id, question1, answer1_hash, question2, answer2_hash, question3, answer3_hash) 
                VALUES (?, ?, ?, ?, ?, ?, ?) 
                ON DUPLICATE KEY UPDATE question1 = ?, answer1_hash = ?, question2 = ?, answer2_hash = ?, question3 = ?, answer3_hash = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            $user_id, $question1, $answer1_hash, $question2, $answer2_hash, $question3, $answer3_hash,
            $question1, $answer1_hash, $question2, $answer2_hash, $question3, $answer3_hash
        ]);
    }
    
    /**
     * Verifies user's security question answers
     * Uses password_verify for secure hash comparison
     * 
     * @param int $user_id - The user ID to verify
     * @param string $answer1 - Answer to first question
     * @param string $answer2 - Answer to second question
     * @param string $answer3 - Answer to third question
     * @return bool - True if all answers match, false otherwise
     */
    public function verifySecurityQuestions($user_id, $answer1, $answer2, $answer3) {
        $sql = "SELECT * FROM security_questions WHERE user_id = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$user_id]);
        $questions = $stmt->fetch(); // Get the stored security questions and hashes
        
        // User doesn't have security questions set up
        if (!$questions) return false; // Can't verify if questions aren't set up
        
        // Verify all three answers - all must match
        // password_verify securely compares the provided answer with the stored hash
        // This is SECURE because we never compare plain text answers
        return password_verify(trim($answer1), $questions['answer1_hash']) &&
               password_verify(trim($answer2), $questions['answer2_hash']) &&
               password_verify(trim($answer3), $questions['answer3_hash']);
    }
    
    /**
     * Sets or updates the balance viewing password
     * Provides an additional layer of security for sensitive financial data
     * 
     * @param int $user_id - The user ID
     * @param string $password - The password to set (min 6 characters)
     * @return bool - Success status of the operation
     * @throws Exception - If password doesn't meet minimum length requirement
     */
    public function setBalancePassword($user_id, $password) {
        // Minimum password length requirement
        // This is a SECURITY POLICY to ensure strong passwords
        if (strlen($password) < 6) {
            throw new Exception("Password must be at least 6 characters");
        }
        
        $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash the password for secure storage
        // UPSERT operation for user preferences
        // Handles both creating new preference and updating existing one
        $sql = "INSERT INTO user_preferences (user_id, balance_password) VALUES (?, ?) 
                ON DUPLICATE KEY UPDATE balance_password = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$user_id, $hashed_password, $hashed_password]);
    }
    
    /**
     * Verifies the balance viewing password
     * 
     * @param int $user_id - The user ID
     * @param string $password - The password to verify
     * @return bool - True if password matches, false otherwise
     */
    public function verifyBalancePassword($user_id, $password) {
        $sql = "SELECT balance_password FROM user_preferences WHERE user_id = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$user_id]);
        $prefs = $stmt->fetch(); // Get the stored password hash
        
        // Verify password against stored hash
        // password_verify is secure against timing attacks
        return $prefs && password_verify($password, $prefs['balance_password']);
    }
    
    /**
     * Checks if a user has security questions configured
     * 
     * @param int $user_id - The user ID to check
     * @return array|false - Security questions record or false if not set
     */
    public function hasSecurityQuestions($user_id) {
        // Used to determine if user needs to set up security questions
        $sql = "SELECT * FROM security_questions WHERE user_id = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$user_id]);
        return $stmt->fetch(); // Returns record if exists, false if not
    }
    
    /**
     * Checks if a user has a balance password configured
     * 
     * @param int $user_id - The user ID to check
     * @return bool - True if balance password is set, false otherwise
     */
    public function hasBalancePassword($user_id) {
        // Used to determine if extra authentication is needed for balance viewing
        $sql = "SELECT balance_password FROM user_preferences WHERE user_id = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$user_id]);
        $prefs = $stmt->fetch();
        return ($prefs && !empty($prefs['balance_password'])); // Check if password exists and is not empty
    }
}
?>