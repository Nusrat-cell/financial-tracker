<?php
// Start session to check if user is logged in
session_start();

// Redirect to login page if user is not authenticated
// This prevents unauthorized access to the edit income page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection configuration
$host = 'localhost'; // Database server
$dbname = 'financialtracker'; // Database name
$username = 'root'; // Database username
$password = ''; // Database password

try {
    // Create secure database connection using PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set error mode to exceptions for better error handling
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    // Display error and stop execution if database connection fails
    die("❌ Connection failed: " . $e->getMessage());
}

// Get existing income data for editing
$income = null;
if(isset($_GET['id'])) {
    // Prepare SELECT statement to get the specific income by ID
    $stmt = $pdo->prepare("SELECT * FROM incomes WHERE IncomeID = ?");
    $stmt->execute([$_GET['id']]);
    $income = $stmt->fetch(); // Get single income record
}

// Show error if income not found
if(!$income) {
    die("❌ Income not found!");
}

// Update income when form is submitted
$error = ''; // Variable to store error messages
if(isset($_POST['update_income'])) {
    // Get form data and sanitize
    $amount = $_POST['amount'];
    $source = trim($_POST['source']);
    $date = $_POST['date_received'];
    $description = trim($_POST['description']);
    
    // Enhanced validation - check all required fields
    if(empty($amount) || empty($source) || empty($date)) {
        $error = "❌ Please fill all required fields!";
    } elseif($amount <= 0) {
        $error = "❌ Amount must be greater than 0!";
    } elseif(strlen($source) < 2) {
        $error = "❌ Source must be at least 2 characters!";
    } elseif($date > date('Y-m-d')) {
        $error = "❌ Date cannot be in the future!";
    } else {
        // If validation passes, try to update the income
        try {
            // Use your IncomeService class for business logic
            // This follows the service pattern used in your other files
            require_once 'classes/IncomeService.class.php';
            $incomeService = new IncomeService($pdo);
            
            // Call the update method from IncomeService
            // This uses the business logic layer instead of direct database access
            $incomeService->updateIncome($_GET['id'], $amount, $source, $date, $description);
            
            // Redirect to incomes page with success message
            header("Location: incomes.php?message=updated");
            exit();
        } catch (Exception $e) {
            $error = "❌ Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Income - Financial Tracker</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(135, 195, 143, 0.3);
            backdrop-filter: blur(10px);
            max-width: 600px;
            width: 100%;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h1 {
            color: #87c38f;
            font-size: 2.2rem;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }

        .header-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #87c38f, #6aab73);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }

        .error {
            background: #ffebee;
            color: #c62828;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 25px;
            text-align: center;
            border: 1px solid #ffcdd2;
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #5d5d5d;
            font-weight: 500;
            font-size: 1rem;
        }

        input, textarea, select {
            width: 100%;
            padding: 15px 18px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }

        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: #87c38f;
            background: white;
            box-shadow: 0 0 0 3px rgba(135, 195, 143, 0.2);
        }

        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            padding: 15px 25px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
            transition: all 0.3s ease;
            text-align: center;
            text-decoration: none;
        }

        .btn-primary {
            background: linear-gradient(135deg, #87c38f, #6aab73);
            color: white;
            box-shadow: 0 4px 15px rgba(135, 195, 143, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(135, 195, 143, 0.4);
        }

        .btn-secondary {
            background: linear-gradient(135deg, #6c757d, #5a6268);
            color: white;
            box-shadow: 0 4px 15px rgba(108, 117, 125, 0.3);
        }

        .btn-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(108, 117, 125, 0.4);
        }

        .form-note {
            text-align: center;
            color: #666;
            font-style: italic;
            margin-top: 20px;
            font-size: 0.9rem;
        }

        @media (max-width: 768px) {
            .container {
                padding: 30px 20px;
            }
            
            .btn-group {
                flex-direction: column;
            }
            
            .header h1 {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>
                <div class="header-icon">✏️</div>
                Edit Income
            </h1>
            <p style="color: #666; margin-top: 10px;">Update your income record below</p>
        </div>
        
        <?php if($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <!-- Amount field with validation -->
            <div class="form-group">
                <label>Amount ($)</label>
                <input type="number" name="amount" step="0.01" min="0.01" value="<?php echo $income['Amount']; ?>" required>
            </div>
            
            <!-- Source field with character validation -->
            <div class="form-group">
                <label>Source</label>
                <input type="text" name="source" value="<?php echo htmlspecialchars($income['Source']); ?>" required>
            </div>
            
            <!-- Date field with future date prevention -->
            <div class="form-group">
                <label>Date Received</label>
                <input type="date" name="date_received" value="<?php echo $income['DateReceived']; ?>" required>
            </div>
            
            <!-- Optional description field -->
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" rows="4" placeholder="Additional notes about this income..."><?php echo htmlspecialchars($income['Description']); ?></textarea>
            </div>
            
            <!-- Action buttons -->
            <div class="btn-group">
                <button type="submit" name="update_income" class="btn btn-primary">Update Income</button>
                <a href="incomes.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
        
        <div class="form-note">
            Make your changes and click "Update Income" to save
        </div>
    </div>
</body>
</html>