<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1;
}

// Database connection
$host = 'localhost';
$dbname = 'financialtracker';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get search filters from URL (same as in incomes.php)
$search_query = $_GET['search_query'] ?? '';
$filter_start_date = $_GET['start_date'] ?? '';
$filter_end_date = $_GET['end_date'] ?? '';
$filter_min_amount = $_GET['min_amount'] ?? '';
$filter_source = $_GET['source_search'] ?? '';

// Build the same query as in incomes.php
$sql = "SELECT * FROM incomes WHERE 1=1";
$params = [];

if(!empty($filter_start_date)) {
    $sql .= " AND DateReceived >= ?";
    $params[] = $filter_start_date;
}

if(!empty($filter_end_date)) {
    $sql .= " AND DateReceived <= ?";
    $params[] = $filter_end_date;
}

if(!empty($filter_min_amount)) {
    $sql .= " AND Amount >= ?";
    $params[] = $filter_min_amount;
}

if(!empty($filter_source)) {
    $sql .= " AND Source LIKE ?";
    $params[] = '%' . $filter_source . '%';
}

$sql .= " ORDER BY DateReceived DESC";

// Fetch filtered incomes
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$incomes = $stmt->fetchAll();

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=incomes_export_' . date('Y-m-d_H-i-s') . '.csv');

// Create output stream
$output = fopen('php://output', 'w');

// Add BOM for UTF-8
fputs($output, "\xEF\xBB\xBF");

// Add CSV headers
fputcsv($output, ['Amount', 'Source', 'Date', 'Description']);

// Add data rows
foreach ($incomes as $income) {
    fputcsv($output, [
        '$' . number_format($income['Amount'], 2),
        $income['Source'],
        $income['DateReceived'],
        $income['Description']
    ]);
}

fclose($output);
exit;
?>