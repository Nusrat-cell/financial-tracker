<?php
// export_csv.php

// Include database connection file
require_once __DIR__ . '/api/db.php';

// Get filter values from URL (same as dashboard)
$start_date = $_GET['start_date'] ?? '';   // Start date filter
$end_date = $_GET['end_date'] ?? '';       // End date filter
$search = $_GET['search'] ?? '';           // Search filter

try {
    // Build WHERE clause for filters (same logic as dashboard)
    $whereClause = "";      // Will store SQL conditions dynamically
    $params = [];           // Parameters for prepared statements
    
    // If both start and end dates are provided
    if (!empty($start_date) && !empty($end_date)) {
        $whereClause = "WHERE date BETWEEN ? AND ?";
        $params = [$start_date, $end_date];

    // Only start date provided
    } elseif (!empty($start_date)) {
        $whereClause = "WHERE date >= ?";
        $params = [$start_date];

    // Only end date provided
    } elseif (!empty($end_date)) {
        $whereClause = "WHERE date <= ?";
        $params = [$end_date];
    }

    // Add search filter condition
    if (!empty($search)) {
        // If no existing WHERE clause, create a new one
        if (empty($whereClause)) {
            $whereClause = "WHERE (description LIKE ? OR category LIKE ?)";
            $params = ["%$search%", "%$search%"];
        } else {
            // Append to existing WHERE clause
            $whereClause .= " AND (description LIKE ? OR category LIKE ?)";
            $params = array_merge($params, ["%$search%", "%$search%"]);
        }
    }

    // Query to fetch filtered transactions
    $txQuery = "SELECT description, amount, type, category, date, note 
                FROM transactions 
                $whereClause 
                ORDER BY date DESC, id DESC";
    
    // Prepare and execute transaction query
    $txStmt = $pdo->prepare($txQuery);
    $txStmt->execute($params);
    $transactions = $txStmt->fetchAll();   // Fetch all records

    // Query to get summary totals (income & expense)
    $summaryQuery = "
        SELECT 
            SUM(CASE WHEN `type` = 'Income' THEN amount ELSE 0 END) AS income,
            SUM(CASE WHEN `type` = 'Expense' THEN amount ELSE 0 END) AS expense
        FROM transactions
        $whereClause
    ";

    // Execute summary query
    $summaryStmt = $pdo->prepare($summaryQuery);
    $summaryStmt->execute($params);
    $summary = $summaryStmt->fetch();
    
    // Extract totals with fallback to 0
    $income = $summary['income'] ?? 0;
    $expense = $summary['expense'] ?? 0;
    $balance = $income - $expense;  // Calculate balance

    // Set headers so browser downloads a CSV file
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="financial_report_' . date('Y-m-d') . '.csv"');

    // Open output buffer for writing CSV data
    $output = fopen('php://output', 'w');

    // Add UTF-8 BOM to avoid encoding issues in Excel
    fputs($output, $bom = (chr(0xEF) . chr(0xBB) . chr(0xBF)));

    // Write section: summary header
    fputcsv($output, ['FINANCIAL REPORT SUMMARY']);
    fputcsv($output, ['Generated:', date('Y-m-d H:i:s')]);
    fputcsv($output, ['']);  // Empty row
    fputcsv($output, ['Total Income:', '$' . number_format($income, 2)]);
    fputcsv($output, ['Total Expenses:', '$' . number_format($expense, 2)]);
    fputcsv($output, ['Balance:', '$' . number_format($balance, 2)]);
    fputcsv($output, ['']);  // Empty row
    fputcsv($output, ['']);  // Empty row

    // Write transactions table header
    fputcsv($output, ['TRANSACTIONS']);
    fputcsv($output, ['Date', 'Description', 'Category', 'Type', 'Amount', 'Note']);

    // Loop through transactions and write each one into CSV
    foreach ($transactions as $tx) {
        fputcsv($output, [
            $tx['date'],                                // Transaction date
            $tx['description'],                         // Description
            $tx['category'] ?? '',                      // Category (if any)
            $tx['type'],                                 // Income / Expense
            '$' . number_format($tx['amount'], 2),       // Formatted amount
            $tx['note'] ?? ''                            // Optional note
        ]);
    }

    // Close file stream
    fclose($output);
    exit;    // Stop script after output

} catch (Exception $e) {
    // If anything fails, return user to dashboard with error flag
    header('Location: index.php?error=export_failed');
    exit;
}
