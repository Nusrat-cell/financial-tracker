<?php // PHP opening tag - start of server-side script
// add_transaction.php
require_once __DIR__ . '/api/db.php'; // include database connection (assumes $pdo is provided by db.php)

$message = ''; // initialize message variable for user feedback
$message_type = ''; // initialize message type ('success' or 'error')

if ($_SERVER['REQUEST_METHOD'] === 'POST') { // check if form was submitted via POST
    try { // start try/catch to handle validation or DB errors
        $description = $_POST['description'] ?? ''; // get description from POST or empty string
        $amount = $_POST['amount'] ?? ''; // get amount from POST or empty string
        $type = $_POST['type'] ?? ''; // get type (Income/Expense) from POST or empty string
        $category = $_POST['category'] ?? ''; // get category from POST or empty string
        $date = $_POST['date'] ?? ''; // get date from POST or empty string
        $note = $_POST['note'] ?? ''; // get note from POST or empty string

        // Basic validation
        if (empty($description) || empty($amount) || empty($type) || empty($date)) { // required fields check
            throw new Exception('Please fill in all required fields'); // throw exception if missing required fields
        }

        if (!is_numeric($amount) || $amount <= 0) { // ensure amount is numeric and positive
            throw new Exception('Amount must be a positive number'); // throw exception for invalid amount
        }

        // Insert into database
        $stmt = $pdo->prepare("
            INSERT INTO transactions (description, amount, type, category, date, note) 
            VALUES (?, ?, ?, ?, ?, ?)
        "); // prepare parameterized SQL to prevent SQL injection
        
        $stmt->execute([$description, $amount, $type, $category, $date, $note]); // execute prepared statement with values
        
        $message = 'Transaction added successfully!'; // set success message
        $message_type = 'success'; // set message type to success
        
    } catch (Exception $e) { // catch any exceptions thrown above
        $message = 'Error: ' . $e->getMessage(); // set error message text
        $message_type = 'error'; // set message type to error
    }
} // end POST handling
?> <!-- end of PHP section and switch to HTML -->

<!DOCTYPE html> <!-- HTML5 doctype -->
<html> <!-- start html element -->
<head> <!-- head section start -->
    <meta charset="utf-8" /> <!-- document character set -->
    <title>Add Transaction - Financial Dashboard</title> <!-- page title shown in browser tab -->
    <meta name="viewport" content="width=device-width,initial-scale=1" /> <!-- responsive viewport meta -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/modern-css-reset/dist/reset.min.css"> <!-- reset CSS to normalize styles across browsers -->
    <style> /* inline CSS styles */
        body { font-family: Arial, sans-serif; background:#f4f6f8; padding:20px; } /* base body styles */
        .container { max-width: 600px; margin: 0 auto; } /* center container with max width */
        .form-card { background: white; padding: 25px; border-radius: 10px; box-shadow: 0 6px 18px rgba(0,0,0,0.06); } /* card styles */
        .form-group { margin-bottom: 20px; } /* spacing between form groups */
        label { display: block; margin-bottom: 5px; font-weight: bold; color: #333; } /* label styling */
        input, select, textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; } /* form control base styles */
        .required { color: red; } /* required field marker color */
        .btn { padding: 12px 25px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; text-decoration: none; display: inline-block; } /* button base styles */
        .btn-primary { background: #0072ff; color: white; } /* primary button color */
        .btn-secondary { background: #6c757d; color: white; margin-right: 10px; } /* secondary button color */
        .message { padding: 15px; margin-bottom: 20px; border-radius: 5px; } /* message box base */
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; } /* success message styles */
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; } /* error message styles */
    </style> <!-- end inline CSS -->
</head> <!-- end head -->
<body> <!-- start body -->
    <div class="container"> <!-- main centered container -->
        <h1>Add New Transaction</h1> <!-- page heading -->
        
        <?php if ($message): ?> <!-- if there's a message to show, render it -->
            <div class="message <?= $message_type ?>"><?= htmlspecialchars($message) ?></div> <!-- output message safely -->
        <?php endif; ?> <!-- end conditional message output -->

        <div class="form-card"> <!-- card wrapper for the form -->
            <form method="POST" action=""> <!-- form posts back to same page -->
                <div class="form-group"> <!-- form group for description -->
                    <label for="description">Description <span class="required">*</span></label> <!-- label for description -->
                    <input type="text" id="description" name="description" required 
                           value="<?= htmlspecialchars($_POST['description'] ?? '') ?>"> <!-- text input with sticky value -->
                </div> <!-- end description group -->

                <div class="form-group"> <!-- form group for amount -->
                    <label for="amount">Amount <span class="required">*</span></label> <!-- label for amount -->
                    <input type="number" id="amount" name="amount" step="0.01" min="0.01" required 
                           value="<?= htmlspecialchars($_POST['amount'] ?? '') ?>"> <!-- numeric input with step and min and sticky value -->
                </div> <!-- end amount group -->

                <div class="form-group"> <!-- form group for type -->
                    <label for="type">Type <span class="required">*</span></label> <!-- label for type -->
                    <select id="type" name="type" required> <!-- select for Income/Expense -->
                        <option value="">Select Type</option> <!-- default placeholder option -->
                        <option value="Income" <?= ($_POST['type'] ?? '') === 'Income' ? 'selected' : '' ?>>Income</option> <!-- income option with sticky selection -->
                        <option value="Expense" <?= ($_POST['type'] ?? '') === 'Expense' ? 'selected' : '' ?>>Expense</option> <!-- expense option with sticky selection -->
                    </select>
                </div> <!-- end type group -->

                <div class="form-group"> <!-- form group for category -->
                    <label for="category">Category</label> <!-- label for category -->
                    <input type="text" id="category" name="category" 
                           value="<?= htmlspecialchars($_POST['category'] ?? '') ?>"> <!-- category input with sticky value -->
                </div> <!-- end category group -->

                <div class="form-group"> <!-- form group for date -->
                    <label for="date">Date <span class="required">*</span></label> <!-- label for date -->
                    <input type="date" id="date" name="date" required 
                           value="<?= htmlspecialchars($_POST['date'] ?? date('Y-m-d')) ?>"> <!-- date input with default to today and sticky value -->
                </div> <!-- end date group -->

                <div class="form-group"> <!-- form group for note -->
                    <label for="note">Note</label> <!-- label for note -->
                    <textarea id="note" name="note" rows="3"><?= htmlspecialchars($_POST['note'] ?? '') ?></textarea> <!-- textarea with sticky content -->
                </div> <!-- end note group -->

                <div> <!-- action buttons container -->
                    <a href="index.php" class="btn btn-secondary">Back to Dashboard</a> <!-- link back to dashboard -->
                    <button type="submit" class="btn btn-primary">Add Transaction</button> <!-- submit button to add transaction -->
                </div> <!-- end action buttons -->
            </form> <!-- end form -->
        </div> <!-- end form-card -->
    </div> <!-- end container -->
</body> <!-- end body -->
</html> <!-- end html document -->