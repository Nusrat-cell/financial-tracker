<?php // PHP opening tag - begins the server-side script
// delete_transaction.php
require_once __DIR__ . '/api/db.php'; // include the database connection file (provides $pdo)

$id = $_GET['id'] ?? 0; // get the transaction ID from the query string, default to 0 if missing

if ($id) { // proceed only if a valid ID exists (non-zero)
    try { // try/catch block to safely handle database operations
        $stmt = $pdo->prepare("DELETE FROM transactions WHERE id = ?"); // prepare SQL statement to delete a record by ID
        $stmt->execute([$id]); // execute delete query with the provided ID
    } catch (Exception $e) { // catch any exceptions thrown while executing query
        // Handle error if needed (currently left empty to avoid breaking redirect)
    }
}

// Redirect back to dashboard
header('Location: index.php'); // send user back to index page after deletion
exit; // terminate script execution to ensure redirect happens cleanly