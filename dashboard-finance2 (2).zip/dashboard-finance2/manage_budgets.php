<?php
// manage_budgets.php // File name comment

require_once __DIR__ . '/api/db.php'; // Include database connection using absolute path

$message = ''; // Variable to hold status message text
$message_type = ''; // Variable to hold status message CSS class (success or error)

// Handle form submissions // Check if form was submitted using POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Check if add budget form was submitted
    if (isset($_POST['add_budget'])) {
        $category = $_POST['category'] ?? ''; // Get selected category or default empty
        $monthly_budget = $_POST['monthly_budget'] ?? ''; // Get monthly budget or default empty
        
        // Validate category and ensure budget is a positive number
        if (!empty($category) && is_numeric($monthly_budget) && $monthly_budget > 0) {
            try {
                // Prepare SQL to insert a new budget row
                $stmt = $pdo->prepare("INSERT INTO budgets (user_id, category, monthly_budget) VALUES (1, ?, ?)");
                $stmt->execute([$category, $monthly_budget]); // Execute SQL query with values
                $message = 'Budget added successfully!'; // Success message text
                $message_type = 'success'; // Success message style
            } catch (Exception $e) { // Catch any database error
                $message = 'Error adding budget: ' . $e->getMessage(); // Store error message
                $message_type = 'error'; // Error message style
            }
        }
    }
    
    // Check if update budget form was submitted
    if (isset($_POST['update_budget'])) {
        $budget_id = $_POST['budget_id'] ?? ''; // Get budget ID to update
        $monthly_budget = $_POST['monthly_budget'] ?? ''; // Get new monthly budget
        
        // Validate ID and new budget value
        if (!empty($budget_id) && is_numeric($monthly_budget) && $monthly_budget > 0) {
            try {
                // Prepare update SQL query
                $stmt = $pdo->prepare("UPDATE budgets SET monthly_budget = ? WHERE id = ?");
                $stmt->execute([$monthly_budget, $budget_id]); // Execute update query
                $message = 'Budget updated successfully!'; // Success message
                $message_type = 'success'; // Success style
            } catch (Exception $e) { // Catch any update error
                $message = 'Error updating budget: ' . $e->getMessage(); // Store error message
                $message_type = 'error'; // Error style
            }
        }
    }
    
    // Check if delete budget form was submitted
    if (isset($_POST['delete_budget'])) {
        $budget_id = $_POST['budget_id'] ?? ''; // Get ID of budget to delete
        
        if (!empty($budget_id)) { // Ensure ID is provided
            try {
                // Prepare delete SQL query
                $stmt = $pdo->prepare("DELETE FROM budgets WHERE id = ?");
                $stmt->execute([$budget_id]); // Execute delete query
                $message = 'Budget deleted successfully!'; // Success message
                $message_type = 'success'; // Success class
            } catch (Exception $e) { // Catch any delete error
                $message = 'Error deleting budget: ' . $e->getMessage(); // Error text
                $message_type = 'error'; // Error class
            }
        }
    }
}

// Get all existing budgets for the user
$budgetsStmt = $pdo->query("SELECT * FROM budgets WHERE user_id = 1 ORDER BY category"); // Fetch budgets sorted by category
$budgets = $budgetsStmt->fetchAll(); // Get all budgets into array

// Query to calculate current month's spending for each category
$spendingStmt = $pdo->query("
    SELECT category, SUM(amount) as total_spent 
    FROM transactions 
    WHERE type = 'Expense' 
    AND user_id = 1 
    AND MONTH(date) = MONTH(CURRENT_DATE()) 
    AND YEAR(date) = YEAR(CURRENT_DATE())
    GROUP BY category
"); // SQL calculates total spending by category for current month

$spending = $spendingStmt->fetchAll(); // Fetch spending results into array

// Create an associative array mapping category => spent amount
$spendingMap = []; // Initialize empty array
foreach ($spending as $spend) { // Loop through spending results
    $spendingMap[$spend['category']] = $spend['total_spent']; // Store spent amount for each category
}
?>

<!DOCTYPE html> <!-- HTML5 Document Type -->
<html>
<head>
    <meta charset="utf-8" /> <!-- Set character encoding to UTF-8 -->
    <title>Manage Budgets - Financial Dashboard</title> <!-- Page title -->
    <meta name="viewport" content="width=device-width,initial-scale=1" /> <!-- Mobile responsive meta tag -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/modern-css-reset/dist/reset.min.css"> <!-- Include CSS reset -->

    <style>
        /* Inline CSS styles for the page layout and elements */
        body { font-family: Arial, sans-serif; background:#f4f6f8; padding:20px; }
        .container { max-width: 800px; margin: 0 auto; }
        .card { background: white; padding: 25px; border-radius: 10px; box-shadow: 0 6px 18px rgba(0,0,0,0.06); margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; color: #333; }
        input, select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; }
        .btn { padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; text-decoration: none; display: inline-block; }
        .btn-primary { background: #0072ff; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-secondary { background: #6c757d; color: white; margin-right: 10px; }
        .message { padding: 15px; margin-bottom: 20px; border-radius: 5px; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .budget-item { border: 1px solid #eee; padding: 15px; margin-bottom: 10px; border-radius: 5px; }
        .progress-bar { background: #e9ecef; border-radius: 10px; height: 20px; margin: 10px 0; overflow: hidden; }
        .progress-fill { height: 100%; border-radius: 10px; transition: width 0.3s ease; }
        .safe { background: #28a745; }
        .warning { background: #ffc107; }
        .danger { background: #dc3545; }
        .budget-stats { display: flex; justify-content: space-between; font-size: 14px; color: #666; }
    </style>
</head>
<body>
    <div class="container"> <!-- Wrapper container -->
        <h1>Manage Budgets</h1> <!-- Page heading -->
        
        <?php if ($message): ?> <!-- Check if message exists -->
            <div class="message <?= $message_type ?>"><?= htmlspecialchars($message) ?></div> <!-- Show message box with type styling -->
        <?php endif; ?>

        <div class="card"> <!-- Card for adding budget -->
            <h2>Add New Budget</h2>
            <form method="POST" action=""> <!-- POST submit form -->
                <div class="form-group">
                    <label for="category">Category</label> <!-- Label for category dropdown -->
                    <select id="category" name="category" required> <!-- Category dropdown list -->
                        <option value="">Select Category</option> <!-- Default option -->
                        <?php
                        $categoryStmt = $pdo->query("SELECT DISTINCT category FROM transactions WHERE category IS NOT NULL AND category != '' AND type = 'Expense' ORDER BY category"); // Fetch unique categories
                        $categories = $categoryStmt->fetchAll(); // Fetch category rows
                        foreach ($categories as $cat) { // Loop through categories
                            echo "<option value=\"" . htmlspecialchars($cat['category']) . "\">" . htmlspecialchars($cat['category']) . "</option>"; // Print option element
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="monthly_budget">Monthly Budget ($)</label> <!-- Label for budget input -->
                    <input type="number" id="monthly_budget" name="monthly_budget" step="0.01" min="0.01" required> <!-- Number input field -->
                </div>
                <button type="submit" name="add_budget" class="btn btn-primary">Add Budget</button> <!-- Submit button -->
                <a href="index.php" class="btn btn-secondary">Back to Dashboard</a> <!-- Button linking to dashboard -->
            </form>
        </div>

        <div class="card"> <!-- Card to display current budgets -->
            <h2>Current Budgets</h2>
            <?php if (empty($budgets)): ?> <!-- If no budgets exist -->
                <p>No budgets set yet. Add your first budget above!</p> <!-- Show message -->
            <?php else: ?> <!-- If budgets exist -->
                <?php foreach ($budgets as $budget): // Loop through all budgets 
                    $spent = $spendingMap[$budget['category']] ?? 0; // Get how much user spent in this category
                    $percentage = $budget['monthly_budget'] > 0 ? min(100, ($spent / $budget['monthly_budget']) * 100) : 0; // Calculate percentage of used budget
                    $progressClass = $percentage < 70 ? 'safe' : ($percentage < 90 ? 'warning' : 'danger'); // Determine color
                ?>
                    <div class="budget-item"> <!-- Budget display box -->
                        <h3><?= htmlspecialchars($budget['category']) ?></h3> <!-- Show category name -->
                        <div class="budget-stats"> <!-- Stats row -->
                            <span>Spent: $<?= number_format($spent, 2) ?></span> <!-- Show amount spent -->
                            <span>Budget: $<?= number_format($budget['monthly_budget'], 2) ?></span> <!-- Show total budget -->
                            <span>Remaining: $<?= number_format($budget['monthly_budget'] - $spent, 2) ?></span> <!-- Show remaining -->
                        </div>
                        <div class="progress-bar"> <!-- Progress bar wrapper -->
                            <div class="progress-fill <?= $progressClass ?>" style="width: <?= $percentage ?>%"></div> <!-- Fill bar based on percentage -->
                        </div>
                        <form method="POST" action="" style="display: inline-block;"> <!-- Form to update budget -->
                            <input type="hidden" name="budget_id" value="<?= $budget['id'] ?>"> <!-- Hidden input for budget ID -->
                            <input type="number" name="monthly_budget" value="<?= $budget['monthly_budget'] ?>" step="0.01" min="0.01" style="width: 120px; display: inline-block;"> <!-- Input for new budget -->
                            <button type="submit" name="update_budget" class="btn btn-primary">Update</button> <!-- Update button -->
                        </form>
                        <form method="POST" action="" style="display: inline-block; margin-left: 10px;"> <!-- Form to delete budget -->
                            <input type="hidden" name="budget_id" value="<?= $budget['id'] ?>"> <!-- Hidden budget ID -->
                            <button type="submit" name="delete_budget" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this budget?')">Delete</button> <!-- Delete button with confirmation -->
                        </form>
                    </div>
                <?php endforeach; ?> <!-- End foreach -->
            <?php endif; ?> <!-- End else -->
        </div>
    </div>
</body>
</html>