<?php // PHP start tag
// edit_transaction.php
require_once __DIR__ . '/api/db.php'; // include database connection file

$message = ''; // message text for success/error
$message_type = ''; // CSS class for message type (success/error)

// Get transaction ID from URL
$id = $_GET['id'] ?? 0; // get 'id' from the query string or set to 0 if missing

// Fetch existing transaction data
if ($id) { // only run when ID is valid (non-zero)
    $stmt = $pdo->prepare("SELECT * FROM transactions WHERE id = ?"); // prepare statement to fetch transaction
    $stmt->execute([$id]); // execute query with ID
    $transaction = $stmt->fetch(); // fetch the transaction record
    
    if (!$transaction) { // if no record is found
        die('Transaction not found'); // terminate script with message
    }
} else { // if ID was missing
    die('Invalid transaction ID'); // stop execution
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') { // check if form submitted via POST
    try { // try/catch block for validation + update
        $description = $_POST['description'] ?? ''; // get description input
        $amount = $_POST['amount'] ?? ''; // get amount input
        $type = $_POST['type'] ?? ''; // get type input
        $category = $_POST['category'] ?? ''; // get category input
        $date = $_POST['date'] ?? ''; // get date input
        $note = $_POST['note'] ?? ''; // get note input

        // Basic validation
        if (empty($description) || empty($amount) || empty($type) || empty($date)) { // required fields check
            throw new Exception('Please fill in all required fields'); // validation error
        }

        if (!is_numeric($amount) || $amount <= 0) { // validate amount number
            throw new Exception('Amount must be a positive number'); // invalid number error
        }

        // Update in database
        $stmt = $pdo->prepare("
            UPDATE transactions 
            SET description = ?, amount = ?, type = ?, category = ?, date = ?, note = ?
            WHERE id = ?
        "); // prepare update query
        
        $stmt->execute([$description, $amount, $type, $category, $date, $note, $id]); // execute update query
        
        $message = 'Transaction updated successfully!'; // success text
        $message_type = 'success'; // mark success
    } catch (Exception $e) { // handle any errors
        $message = 'Error: ' . $e->getMessage(); // store error text
        $message_type = 'error'; // mark error
    }
    
    // Refresh transaction data after update
    $stmt = $pdo->prepare("SELECT * FROM transactions WHERE id = ?"); // re-fetch updated data
    $stmt->execute([$id]);
    $transaction = $stmt->fetch(); // overwrite old data
}
?> <!-- end PHP, start HTML -->

<!DOCTYPE html> <!-- HTML5 document declaration -->
<html>
<head>
    <meta charset="utf-8" /> <!-- character encoding -->
    <title>Edit Transaction - Financial Dashboard</title> <!-- browser title -->
    <meta name="viewport" content="width=device-width,initial-scale=1" /> <!-- responsive meta -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/modern-css-reset/dist/reset.min.css"> <!-- CSS reset -->
    <style> /* Inline CSS styles */
        body { font-family: Arial, sans-serif; background:#f4f6f8; padding:20px; } /* page base style */
        .container { max-width: 600px; margin: 0 auto; } /* content centered */
        .form-card { background: white; padding: 25px; border-radius: 10px; box-shadow: 0 6px 18px rgba(0,0,0,0.06); } /* card UI */
        .form-group { margin-bottom: 20px; } /* spacing */
        label { display: block; margin-bottom: 5px; font-weight: bold; color: #333; } /* form labels */
        input, select, textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; } /* inputs */
        .required { color: red; } /* asterisk styling */
        .btn { padding: 12px 25px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; text-decoration: none; display: inline-block; } /* buttons */
        .btn-primary { background: #0072ff; color: white; } /* primary button */
        .btn-secondary { background: #6c757d; color: white; margin-right: 10px; } /* secondary button */
        .message { padding: 15px; margin-bottom: 20px; border-radius: 5px; } /* alert message box */
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; } /* success styling */
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; } /* error styling */
    </style>
</head>
<body>
    <div class="container"> <!-- main wrapper -->
        <h1>Edit Transaction</h1> <!-- page heading -->
        
        <?php if ($message): ?> <!-- show message if exists -->
            <div class="message <?= $message_type ?>"><?= htmlspecialchars($message) ?></div> <!-- output safe message -->
        <?php endif; ?> <!-- end message check -->

        <div class="form-card"> <!-- UI card -->
            <form method="POST" action=""> <!-- form for updating transaction -->
                <div class="form-group"> <!-- description group -->
                    <label for="description">Description <span class="required">*</span></label> <!-- label -->
                    <input type="text" id="description" name="description" required 
                           value="<?= htmlspecialchars($transaction['description']) ?>"> <!-- value from db -->
                </div>

                <div class="form-group"> <!-- amount group -->
                    <label for="amount">Amount <span class="required">*</span></label> <!-- label -->
                    <input type="number" id="amount" name="amount" step="0.01" min="0.01" required 
                           value="<?= htmlspecialchars($transaction['amount']) ?>"> <!-- numeric value -->
                </div>

                <div class="form-group"> <!-- type group -->
                    <label for="type">Type <span class="required">*</span></label> <!-- label -->
                    <select id="type" name="type" required> <!-- dropdown -->
                        <option value="">Select Type</option> <!-- placeholder -->
                        <option value="Income" <?= $transaction['type'] === 'Income' ? 'selected' : '' ?>>Income</option> <!-- income -->
                        <option value="Expense" <?= $transaction['type'] === 'Expense' ? 'selected' : '' ?>>Expense</option> <!-- expense -->
                    </select>
                </div>

                <div class="form-group"> <!-- category group -->
                    <label for="category">Category</label> <!-- label -->
                    <input type="text" id="category" name="category" 
                           value="<?= htmlspecialchars($transaction['category'] ?? '') ?>"> <!-- category soft optional -->
                </div>

                <div class="form-group"> <!-- date group -->
                    <label for="date">Date <span class="required">*</span></label> <!-- label -->
                    <input type="date" id="date" name="date" required 
                           value="<?= htmlspecialchars($transaction['date']) ?>"> <!-- date value -->
                </div>

                <div class="form-group"> <!-- note group -->
                    <label for="note">Note</label> <!-- label -->
                    <textarea id="note" name="note" rows="3"><?= htmlspecialchars($transaction['note'] ?? '') ?></textarea> <!-- text area -->
                </div>

                <div> <!-- buttons container -->
                    <a href="index.php" class="btn btn-secondary">Back to Dashboard</a> <!-- link back -->
                    <button type="submit" class="btn btn-primary">Update Transaction</button> <!-- submit button -->
                </div>
            </form> <!-- end form -->
        </div> <!-- end card -->
    </div> <!-- end container -->
</body>
</html> <!-- end HTML -->