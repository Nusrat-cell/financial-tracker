<?php
// Full categories.php content here
?>