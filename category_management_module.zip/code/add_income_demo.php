<?php
// Full add_income_demo.php content here
?>