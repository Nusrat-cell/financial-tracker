<?php
// get categories by type API
?>