<?php
// delete category API
?>