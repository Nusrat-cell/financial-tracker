<?php
// ===========================================================================
// FILE: dashboard-finance-tests/tests.php
// PURPOSE: Automated boundary testing for Financial Dashboard database validation
// AUTHOR: Zeeshan Zafar
// DATE: 03-12-25
// TESTING ENVIRONMENT: XAMPP/PHP 8.x
// ===========================================================================

// Usage in VS Code Terminal: 
// 1. cd D:\xampp\htdocs\dashboard-finance-tests
// 2. php tests.php
// Or visit in browser: http://localhost/dashboard-finance-tests/tests.php

echo "=============================================\n";
echo "     FINANCIAL DASHBOARD VALIDATION TESTS    \n";
echo "=============================================\n\n";

// ===========================================================================
// TEST 1: BUDGET CATEGORY FIELD (VARCHAR 100)
// Tests database constraint: VARCHAR(100), NOT NULL
// ===========================================================================
echo "TEST 1: BUDGET CATEGORY FIELD (VARCHAR 100)\n";
echo "===========================================\n\n";

/**
 * Validates budget category field according to database constraints
 * Database: VARCHAR(100), NOT NULL
 * Business Rule: Category cannot be empty
 * @param mixed $category The category value to validate
 * @return bool True if valid, False if invalid
 */
function testCategory($category) {
    // Check 1: NULL values are invalid (NOT NULL constraint)
    if ($category === null) return false;
    
    // Check 2: Empty or whitespace-only strings are invalid (business rule)
    if (trim($category) === '') return false;
    
    // Check 3: Length must not exceed 100 characters (VARCHAR 100 constraint)
    return strlen($category) <= 100;
}

// Test cases for boundary testing of category field
$categoryTests = [
    // Extreme Min: Empty string (should fail - NOT NULL constraint)
    ['data' => '', 'expected' => false, 'desc' => 'Empty string'],
    
    // Min Boundary: 1 character (minimum valid length, should pass)
    ['data' => 'A', 'expected' => true, 'desc' => '1 character (Min)'],
    
    // Min+1: 2 characters (just above minimum, should pass)
    ['data' => 'AB', 'expected' => true, 'desc' => '2 characters (Min+1)'],
    
    // Max-1: 99 characters (just below maximum, should pass)
    ['data' => str_repeat('A', 99), 'expected' => true, 'desc' => '99 chars (Max-1)'],
    
    // Max Boundary: 100 characters (maximum valid, should pass)
    ['data' => str_repeat('A', 100), 'expected' => true, 'desc' => '100 chars (Max)'],
    
    // Max+1: 101 characters (exceeds maximum, should fail)
    ['data' => str_repeat('A', 101), 'expected' => false, 'desc' => '101 chars (Max+1)'],
    
    // Mid: 50 characters (normal mid-range value, should pass)
    ['data' => str_repeat('A', 50), 'expected' => true, 'desc' => '50 chars (Mid)'],
    
    // Extreme Max: 1000 characters (far exceeds maximum, should fail)
    ['data' => str_repeat('A', 1000), 'expected' => false, 'desc' => '1000 chars (Extreme Max)'],
    
    // Invalid Data Type: Numeric (should pass as string conversion is allowed)
    ['data' => 12345, 'expected' => true, 'desc' => 'Numeric 12345'],
    
    // NULL Test: Explicit NULL (should fail - NOT NULL constraint)
    ['data' => null, 'expected' => false, 'desc' => 'NULL'],
    
    // Whitespace Handling: Should trim and pass if content exists
    ['data' => '   Food   ', 'expected' => true, 'desc' => 'With whitespace'],
];

// Execute all category tests and display results
foreach ($categoryTests as $test) {
    $actual = testCategory($test['data']);
    $status = ($actual === $test['expected']) ? 'PASS' : 'FAIL';
    
    echo "Test: {$test['desc']}\n";
    echo "Expected: " . ($test['expected'] ? 'PASS' : 'FAIL') . "\n";
    echo "Actual: " . ($actual ? 'PASS' : 'FAIL') . "\n";
    echo "Status: {$status}\n";
    echo "---\n";
}

// ===========================================================================
// TEST 2: MONTHLY BUDGET FIELD (DECIMAL 10,2)
// Tests database constraint: DECIMAL(10,2), NOT NULL
// Range: -99,999,999.99 to 99,999,999.99
// ===========================================================================
echo "\n\nTEST 2: MONTHLY BUDGET FIELD (DECIMAL 10,2)\n";
echo "============================================\n\n";

/**
 * Validates monthly budget field according to database constraints
 * Database: DECIMAL(10,2), NOT NULL
 * 10 total digits = 8 before decimal + 2 after decimal
 * @param mixed $amount The budget amount to validate
 * @return bool True if valid, False if invalid
 */
function testBudget($amount) {
    // Check 1: NULL or empty values are invalid (NOT NULL constraint)
    if ($amount === null || $amount === '') return false;
    
    // Check 2: Must be numeric (DECIMAL field requirement)
    if (!is_numeric($amount)) return false;
    
    $amount = (float)$amount;
    
    // Check 3: Must be within DECIMAL(10,2) range
    if ($amount < -99999999.99 || $amount > 99999999.99) return false;
    
    // Check 4: Must have maximum 2 decimal places
    if (round($amount, 2) != $amount) return false;
    
    return true;
}

// Test cases for boundary testing of budget field
$budgetTests = [
    // Extreme Min: Minimum possible value (should pass)
    ['data' => -99999999.99, 'expected' => true, 'desc' => 'Extreme Min (-99,999,999.99)'],
    
    // Min-1: Just below zero (should pass - negative budgets allowed)
    ['data' => -0.01, 'expected' => true, 'desc' => 'Min-1 (-0.01)'],
    
    // Min Boundary: Zero value (should pass)
    ['data' => 0.00, 'expected' => true, 'desc' => 'Min (0.00)'],
    
    // Min+1: Just above zero (should pass)
    ['data' => 0.01, 'expected' => true, 'desc' => 'Min+1 (0.01)'],
    
    // Max-1: Just below maximum (should pass)
    ['data' => 99999999.98, 'expected' => true, 'desc' => 'Max-1 (99,999,999.98)'],
    
    // Max Boundary: Maximum possible value (should pass)
    ['data' => 99999999.99, 'expected' => true, 'desc' => 'Max (99,999,999.99)'],
    
    // Max+1: Just above maximum (should fail - exceeds DECIMAL(10,2))
    ['data' => 100000000.00, 'expected' => false, 'desc' => 'Max+1 (100,000,000.00)'],
    
    // Mid: Normal budget amount (should pass)
    ['data' => 50000.50, 'expected' => true, 'desc' => 'Mid (50,000.50)'],
    
    // Extreme Max: Far exceeds maximum (should fail)
    ['data' => 999999999.99, 'expected' => false, 'desc' => 'Extreme Max (999,999,999.99)'],
    
    // Invalid Data Type: Non-numeric string (should fail)
    ['data' => 'abc', 'expected' => false, 'desc' => 'Invalid: String "abc"'],
    
    // NULL Test: Explicit NULL (should fail - NOT NULL constraint)
    ['data' => null, 'expected' => false, 'desc' => 'Invalid: NULL'],
    
    // Decimal Test: Too many decimal places (should fail)
    ['data' => 100.555, 'expected' => false, 'desc' => 'Invalid: 3 decimals'],
    
    // Valid Case: Integer without decimals (should pass)
    ['data' => 1000000, 'expected' => true, 'desc' => 'Valid: 1,000,000 (no decimal)'],
];

// Execute all budget tests
foreach ($budgetTests as $test) {
    $actual = testBudget($test['data']);
    $status = ($actual === $test['expected']) ? 'PASS' : 'FAIL';
    
    echo "Test: {$test['desc']}\n";
    echo "Data: {$test['data']}\n";
    echo "Expected: " . ($test['expected'] ? 'PASS' : 'FAIL') . "\n";
    echo "Actual: " . ($actual ? 'PASS' : 'FAIL') . "\n";
    echo "Status: {$status}\n";
    echo "---\n";
}

// ===========================================================================
// TEST 3: TRANSACTION AMOUNT FIELD (DECIMAL 12,2)
// Tests database constraint: DECIMAL(12,2), NOT NULL
// Range: -9,999,999,999.99 to 9,999,999,999.99
// Used for larger financial transactions
// ===========================================================================
echo "\n\nTEST 3: TRANSACTION AMOUNT FIELD (DECIMAL 12,2)\n";
echo "=================================================\n\n";

/**
 * Validates transaction amount field according to database constraints
 * Database: DECIMAL(12,2), NOT NULL
 * 12 total digits = 10 before decimal + 2 after decimal
 * @param mixed $amount The transaction amount to validate
 * @return bool True if valid, False if invalid
 */
function testTransactionAmount($amount) {
    if ($amount === null || $amount === '') return false;
    if (!is_numeric($amount)) return false;
    
    $amount = (float)$amount;
    if ($amount < -9999999999.99 || $amount > 9999999999.99) return false;
    if (round($amount, 2) != $amount) return false;
    
    return true;
}

$amountTests = [
    ['data' => -9999999999.99, 'expected' => true, 'desc' => 'Extreme Min'],
    ['data' => -0.01, 'expected' => true, 'desc' => 'Min-1'],
    ['data' => 0.00, 'expected' => true, 'desc' => 'Min'],
    ['data' => 0.01, 'expected' => true, 'desc' => 'Min+1'],
    ['data' => 9999999999.98, 'expected' => true, 'desc' => 'Max-1'],
    ['data' => 9999999999.99, 'expected' => true, 'desc' => 'Max'],
    ['data' => 10000000000.00, 'expected' => false, 'desc' => 'Max+1'],
    ['data' => 5000000000.00, 'expected' => true, 'desc' => 'Mid'],
    ['data' => 99999999999.99, 'expected' => false, 'desc' => 'Extreme Max'],
    ['data' => 'amount', 'expected' => false, 'desc' => 'Invalid: String'],
    ['data' => null, 'expected' => false, 'desc' => 'Invalid: NULL'],
    ['data' => 100.123, 'expected' => false, 'desc' => 'Invalid: 3 decimals'],
    ['data' => -150.75, 'expected' => true, 'desc' => 'Valid: Negative'],
    ['data' => 3000.00, 'expected' => true, 'desc' => 'Valid: Positive'],
];

foreach ($amountTests as $test) {
    $actual = testTransactionAmount($test['data']);
    $status = ($actual === $test['expected']) ? 'PASS' : 'FAIL';
    
    echo "Test: {$test['desc']}\n";
    echo "Data: {$test['data']}\n";
    echo "Expected: " . ($test['expected'] ? 'PASS' : 'FAIL') . "\n";
    echo "Actual: " . ($actual ? 'PASS' : 'FAIL') . "\n";
    echo "Status: {$status}\n";
    echo "---\n";
}

// ===========================================================================
// TEST 4: TRANSACTION TYPE FIELD (ENUM)
// Tests database constraint: ENUM('Income','Expense'), NOT NULL
// ===========================================================================
echo "\n\nTEST 4: TRANSACTION TYPE FIELD (ENUM)\n";
echo "======================================\n\n";

/**
 * Validates transaction type field according to database constraints
 * Database: ENUM('Income','Expense'), NOT NULL
 * @param mixed $type The transaction type to validate
 * @return bool True if valid, False if invalid
 */
function testTransactionType($type) {
    if ($type === null) return false;
    $type = strtolower(trim($type));
    return in_array($type, ['income', 'expense']);
}

$typeTests = [
    ['data' => 'Income', 'expected' => true, 'desc' => 'Valid: Income'],
    ['data' => 'Expense', 'expected' => true, 'desc' => 'Valid: Expense'],
    ['data' => 123, 'expected' => false, 'desc' => 'Invalid: Number'],
    ['data' => 'income', 'expected' => true, 'desc' => 'Valid: lowercase'],
    ['data' => 'INCOME', 'expected' => true, 'desc' => 'Valid: UPPERCASE'],
    ['data' => 'Savings', 'expected' => false, 'desc' => 'Invalid: Savings'],
    ['data' => null, 'expected' => false, 'desc' => 'Invalid: NULL'],
    ['data' => '', 'expected' => false, 'desc' => 'Invalid: Empty'],
    ['data' => ' Income ', 'expected' => true, 'desc' => 'Valid: with spaces'],
];

foreach ($typeTests as $test) {
    $actual = testTransactionType($test['data']);
    $status = ($actual === $test['expected']) ? 'PASS' : 'FAIL';
    
    echo "Test: {$test['desc']}\n";
    echo "Data: " . ($test['data'] === null ? 'NULL' : "'{$test['data']}'") . "\n";
    echo "Expected: " . ($test['expected'] ? 'PASS' : 'FAIL') . "\n";
    echo "Actual: " . ($actual ? 'PASS' : 'FAIL') . "\n";
    echo "Status: {$status}\n";
    echo "---\n";
}

// ===========================================================================
// SAVE RESULTS TO FILE
// ===========================================================================
$results = ob_get_contents();
file_put_contents('test-results.txt', $results);

echo "\n=============================================\n";
echo "Results saved to: dashboard-finance-tests/test-results.txt\n";
echo "Total Tests Run: " . (count($categoryTests) + count($budgetTests) + count($amountTests) + count($typeTests)) . "\n";
echo "=============================================\n";
?>