<?php
// Load the database connection
require "../config/db.php";

// Read POST variables, defaulting to empty strings if missing
$id          = $_POST["id"] ?? "";
$name        = $_POST["name"] ?? "";
$type        = $_POST["type"] ?? "";
$icon        = $_POST["icon"] ?? "";
$description = $_POST["description"] ?? "";

// Validate required fields: id, name, and type must be provided
if (!$id || !$name || !$type) {
    echo json_encode(["success" => false, "message" => "Missing fields"]);
    exit; // Stop execution if required fields are missing
}

// Prepare an UPDATE query using a prepared statement for safety
$stmt = $conn->prepare("
    UPDATE categories 
    SET category_name=?, category_type=?, icon=?, description=?, updated_at=NOW()
    WHERE category_id=?
");

// Bind parameters to the prepared statement
// s = string, i = integer
$stmt->bind_param("ssssi", $name, $type, $icon, $description, $id);

// Execute the update and return success status as JSON
echo json_encode(["success" => $stmt->execute()]);
