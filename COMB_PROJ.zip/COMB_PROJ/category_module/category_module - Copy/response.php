<?php
// backend/helpers/response.php

/**
 * Sends a standardized JSON response and stops execution.
 *
 * @param bool   $success  Whether the request was successful.
 * @param string $message  Optional message to include.
 * @param mixed  $data     Optional extra data to return.
 */
function respond($success, $message = "", $data = null) {
    // Ensure the output is JSON with UTF-8 support
    header("Content-Type: application/json; charset=utf-8");

    // Encode and return the structured response
    echo json_encode([
        "success" => $success,
        "message" => $message,
        "data"    => $data
    ]);

    // Stop the script immediately after sending the response
    exit;
}
