<?php
// Load database connection
require_once(__DIR__ . '../db.php');

// Tell the browser we are returning JSON
header("Content-Type: application/json; charset=utf-8");

// Read search query and escape it to prevent SQL injection
// If provided, wrap in wildcards for a LIKE search
$q = isset($_GET['q'])
    ? "%" . $conn->real_escape_string($_GET['q']) . "%"
    : null;

// Read optional category type filter and escape it
$type = isset($_GET['type'])
    ? $conn->real_escape_string($_GET['type'])
    : null;

// Base SQL query for categories
$sql = "SELECT 
            category_id,
            user_id,
            category_name,
            category_type,
            icon,
            description,
            created_at,
            updated_at
        FROM categories
        WHERE 1=1";   // allows easy appending of AND conditions

// Arrays used for prepared statement binding
$params = [];
$types  = "";

// Add search filter if a query was provided
if ($q !== null) {
    $sql .= " AND category_name LIKE ?";
    $params[] = $q;
    $types .= "s";   // 's' = string parameter
}

// Add type filter if provided
if (!empty($type)) {
    $sql .= " AND category_type = ?";
    $params[] = $type;
    $types .= "s";
}

// Limit results to avoid heavy queries
$sql .= " ORDER BY created_at DESC LIMIT 300";

// Prepare the SQL statement
$stmt = $conn->prepare($sql);

// Bind parameters only if needed
if ($params) {
    $stmt->bind_param($types, ...$params);
}

// Execute the query
$stmt->execute();

// Fetch the resulting rows
$res = $stmt->get_result();
$data = $res->fetch_all(MYSQLI_ASSOC);

// Output JSON with Unicode unescaped to keep emojis intact
echo json_encode(["success" => true, "data" => $data], JSON_UNESCAPED_UNICODE);
