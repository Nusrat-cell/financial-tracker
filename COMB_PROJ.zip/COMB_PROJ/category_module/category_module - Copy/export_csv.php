<?php
// Load the database connection
require "../config/db.php";

// Tell the browser that the response is a CSV file for download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=categories_export.csv');

// Open an output stream that writes directly to the browser
$output = fopen('php://output', 'w');

// Write the column headers to the CSV file
fputcsv($output, [
    'ID',
    'Name',
    'Type',
    'Icon',
    'Description',
    'Created At'
]);

// SQL query to fetch category data ordered by most recent
$sql = "
    SELECT 
        category_id,
        category_name,
        category_type,
        icon,
        description,
        created_at
    FROM categories
    ORDER BY created_at DESC
";

// Execute the query
$result = $conn->query($sql);

// If the query returned results, output each row as a CSV line
if ($result) {
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, [
            $row['category_id'],
            $row['category_name'],
            $row['category_type'],
            $row['icon'],
            $row['description'],
            $row['created_at']
        ]);
    }
}

// Close the output stream
fclose($output);

// Stop script execution after outputting the CSV
exit;
