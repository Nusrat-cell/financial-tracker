<?php
// Include the database connection file
require "../config/db.php";

// Read inputs from POST request, provide default values if missing
$name        = $_POST["name"] ?? "";
$type        = $_POST["type"] ?? "";
$icon        = $_POST["icon"] ?? "📁";  // Default icon if none provided
$description = $_POST["description"] ?? "";

// Validate required fields
if (!$name || !$type) {
    // Return error response if required fields are missing
    echo json_encode(["success" => false, "message" => "Missing fields"]);
    exit; // Stop script execution
}

// Prepare SQL insert statement
$stmt = $conn->prepare("
    INSERT INTO categories (category_name, category_type, icon, description, created_at, updated_at)
    VALUES (?, ?, ?, ?, NOW(), NOW())
");

// Bind variables to the prepared SQL statement
$stmt->bind_param("ssss", $name, $type, $icon, $description);

// Execute statement and return success status as JSON
echo json_encode(["success" => $stmt->execute()]);
