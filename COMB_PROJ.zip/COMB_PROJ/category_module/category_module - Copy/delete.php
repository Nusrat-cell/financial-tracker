<?php
// backend/category/delete.php

// Load the database connection
require_once(__DIR__ . '/../config/db.php');

// Load the helper function for sending standardized JSON responses
require_once(__DIR__ . '/../helpers/response.php');

// Read the category ID from POST, convert to integer, default to 0 if missing
$id = intval($_POST['id'] ?? 0);

// If no valid ID is provided, return an error response and stop execution
if (!$id) respond(false, "Missing ID");

// Prepare the SQL delete statement using a prepared statement for safety
$stmt = $conn->prepare("DELETE FROM categories WHERE category_id = ?");

// Bind the ID parameter as an integer
$stmt->bind_param("i", $id);

// Execute the query and send a response based on whether it succeeded
if ($stmt->execute()) 
    respond(true, "Deleted");
else 
    respond(false, "Delete failed: " . $conn->error);
