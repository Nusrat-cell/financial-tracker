// frontend/assets/js/dashboard.js

// Base path for category-related backend APIs
const API_BASE = "../backend/category"; // The folder where all PHP API files are located

// Global array holding all categories loaded from backend
let categories = []; // Stores categories retrieved via AJAX

// Stores the ID of the category selected for deletion
let categoryToDelete = null; // Used by delete modal

// Shortcut for getElementById
function q(id){ return document.getElementById(id); } // Helper to reduce typing

// Helper to fetch JSON with fetch()
function ajaxJSON(url, opts = {}) {
  return fetch(url, opts).then(r => r.json()); // Performs fetch, converts response to JSON
}

/* ----------------------------------
   Load categories from backend
---------------------------------- */
function loadCategories(){
  ajaxJSON(API_BASE + "/list.php") // Request category list from backend
    .then(res => { // Handle response
      if(res && res.success){ // Check success
        // Normalize missing fields to avoid undefined errors
        categories = res.data.map(c => { // Loop categories
          c.usage_count = c.usage_count ?? 'undefined'; // Default usage_count
          c.icon = c.icon ?? '📁'; // Default icon
          c.description = c.description ?? ""; // Default description
          return c; // Return normalized category
        });
        renderAll(); // update dashboard UI after load
      } else {
        console.error("Failed to load categories", res); // Backend returned error
      }
    })
    .catch(e=>console.error("Fetch error", e)); // Network error
}

/* ----------------------------------
   Render dashboard blocks
---------------------------------- */
function renderAll(){
  renderStats();   // Update statistics cards
  renderGrid();    // Update category grid
  renderRecent();  // Update "recently added" list
}

function renderStats(){
  q("totalCategories").innerText = categories.length; // Show total categories
  q("incomeCategories").innerText = categories.filter(c=>c.category_type==="income").length; // Count income
  q("expenseCategories").innerText = categories.filter(c=>c.category_type==="expense").length; // Count expense
}

/* ----------------------------------
   Render main category grid
---------------------------------- */
function renderGrid(){
  const search = (q("searchInput").value || "").toLowerCase(); // Get search term
  const filter = (q("filterType").value || ""); // Get type filter
  const grid = q("categoryGrid"); // Grid container
  grid.innerHTML = ""; // Clear existing items

  categories
    .filter(c => 
      c.category_name.toLowerCase().includes(search) && // Search filter
      (!filter || c.category_type === filter) // Type filter
    )
    .forEach(c => { // Create a card for each category
      const card = document.createElement("div");
      card.className = "category-card"; // Card styling

      // Icon section
      const iconHtml = `
        <div class="cat-icon">
          ${escapeHtml(c.icon)}
        </div>
      `;

      // Name, type, description
      const nameHtml = `
        <div>
          <h4>${escapeHtml(c.category_name)}</h4>
          <p>${escapeHtml(c.category_type)}</p>
          <p style="color:#56776F; font-size:15px; margin-top:4px;">
            ${escapeHtml(c.description || "")}
          </p>
        </div>
      `;

      card.innerHTML = iconHtml + nameHtml; // Combine content

      // Clicking a card opens details modal
      card.addEventListener("click", ()=> openDetailModal(c)); // Show details modal
      grid.appendChild(card); // Add card to grid
    });
}

/* ----------------------------------
   Render Recently Added List
---------------------------------- */
function renderRecent(){
  const list = q("recentList"); // UL container
  list.innerHTML = ""; // Clear list
  categories.slice(0,6).forEach(c=>{ // Take first 6 categories
    const li = document.createElement("li"); // Create list item
    li.textContent = c.category_name; // Show name
    list.appendChild(li); // Add to list
  });
}

/* ----------------------------------
   Setup event listeners on DOM load
---------------------------------- */
document.addEventListener("DOMContentLoaded", ()=>{ // Run when page loads

  // Search bar listener
  const search = q("searchInput");
  if(search) search.addEventListener("input", renderGrid); // Filter as user types

  // Dropdown filter
  const filter = q("filterType");
  if(filter) filter.addEventListener("change", renderGrid); // Filter on change

  // Open Add modal buttons
  const openAdd = q("openAddModal");
  const openAdd2 = q("openAddModal2");
  if(openAdd) openAdd.addEventListener("click", ()=> openModal("addModal")); // Button 1
  if(openAdd2) openAdd2.addEventListener("click", ()=> openModal("addModal")); // Button 2

  // Export CSV button
  const exp = q("exportCSV");
  if(exp) exp.addEventListener("click", ()=> { 
    window.location = "../backend/category/export_csv.php"; // Download CSV
  });

  // Close modal buttons
  document.querySelectorAll(".close-modal").forEach(b=>{
    b.addEventListener("click", closeAllModals); // Add close behavior to all buttons
  });

  // ----------------------------------------------------
  //   STAT CARD CLICK FILTER LOGIC
  // ----------------------------------------------------
  function setupStatCardFilters(){
    const statBlue  = document.querySelector(".stat-blue");   // all categories
    const statGreen = document.querySelector(".stat-green");  // income
    const statOrange = document.querySelector(".stat-orange");// expense

    function attach(card, typeValue){
      if(!card) return; // Skip if card doesn't exist
      card.style.cursor = "pointer"; // Show pointer cursor

      card.addEventListener("click", () => { // Make stat card clickable
        q("filterType").value = typeValue; // Set dropdown filter
        renderGrid(); // Refresh grid

        // Highlight selected card
        document.querySelectorAll(".stat-card").forEach(c => 
          c.classList.remove("active-stat")
        );
        card.classList.add("active-stat"); // Add highlight

        // Smooth scroll to grid
        window.scrollTo({ top: 300, behavior: "smooth" });
      });
    }

    attach(statBlue, ""); // Show all
    attach(statGreen, "income"); // Filter income
    attach(statOrange, "expense"); // Filter expense
  }

  setupStatCardFilters(); // Initialize stat card filter system

  /* ----------------------------------
     SAVE ADD CATEGORY
  ---------------------------------- */
  const saveAdd = q("saveAdd");
  if(saveAdd) saveAdd.addEventListener("click", ()=>{

    const name = q("addName").value.trim(); // Input name
    const type = q("addType").value; // Input type
    const icon = q("addIcon").value.trim() || "📁"; // Default icon
    const description = q("addDescription").value.trim(); // Input description

    // Validation
    if(!name || !type){ 
      alert("All fields required"); 
      return; 
    }

    // Build FormData for POST
    const fd = new FormData();
    fd.append("name", name);
    fd.append("type", type);
    fd.append("icon", icon);
    fd.append("description", description);

    ajaxJSON(API_BASE + "/add.php", { method:"POST", body: fd })
      .then(res => {
        if(res && res.success){
          closeAllModals(); // Hide modal
          loadCategories(); // Reload list
        }
        else alert(res.message || "Add failed");
      })
      .catch(e=> alert("Network error"));
  });

  /* ----------------------------------
     SAVE EDIT CATEGORY
  ---------------------------------- */
  const saveEdit = q("saveEdit");
  if(saveEdit) saveEdit.addEventListener("click", ()=>{

    const id = q("editId").value;
    const name = q("editName").value.trim();
    const type = q("editType").value;
    const icon = q("editIcon").value.trim() || "📁";
    const description = q("editDescription").value.trim();

    // Validation
    if(!id || !name || !type){
      alert("All fields required");
      return;
    }

    const fd = new FormData();
    fd.append("id", id);
    fd.append("name", name);
    fd.append("type", type);
    fd.append("icon", icon);
    fd.append("description", description);

    ajaxJSON(API_BASE + "/update.php", { method:"POST", body: fd })
      .then(res=> {
        if(res && res.success){
          closeAllModals();
          loadCategories();
        }
        else alert(res.message || "Update failed");
      })
      .catch(e=> alert("Network error"));
  });

  /* ----------------------------------
     CONFIRM DELETE CATEGORY
  ---------------------------------- */
  const confirmDelete = q("confirmDelete");
  if(confirmDelete) confirmDelete.addEventListener("click", ()=>{
    const fd = new FormData();
    fd.append("id", categoryToDelete); // Send ID of category to delete

    ajaxJSON(API_BASE + "/delete.php", { method:"POST", body: fd })
      .then(res => {
        if(res && res.success){
          closeAllModals(); // Close modal
          loadCategories(); // Refresh list
        }
        else alert(res.message || "Delete failed");
      })
      .catch(e=> alert("Network error"));
  });

  // Initial load
  loadCategories(); // Loads categories on page load
});

/* ----------------------------------
   DETAIL MODAL — OPEN
---------------------------------- */
function openDetailModal(cat){
  q("detailName").innerText = cat.category_name; // Show name
  q("detailType").innerText = cat.category_type; // Show type
  q("detailUsage").innerText = cat.usage_count; // Show usage count
  q("detailCreated").innerText = cat.created_at || "—"; // Show creation date
  q("detailDescription").innerText = cat.description || "—"; // Show description

  // Buttons inside modal
  q("editBtn").onclick = ()=> { closeAllModals(); openEditModal(cat); }; // Edit button
  q("deleteBtn").onclick = ()=> { closeAllModals(); openDeleteModal(cat.category_id); }; // Delete button

  openModal("detailModal"); // Show modal
}

/* ----------------------------------
   EDIT MODAL — OPEN
---------------------------------- */
function openEditModal(cat){
  q("editId").value = cat.category_id; // Set hidden ID field
  q("editName").value = cat.category_name; // Fill name
  q("editType").value = cat.category_type; // Fill type
  q("editIcon").value = cat.icon || ""; // Fill icon
  q("editDescription").value = cat.description || ""; // Fill description

  openModal("editModal"); // Show modal
}

function openDeleteModal(id){
  categoryToDelete = id; // Save ID of category we want to delete
  openModal("deleteModal"); // Show delete modal
}

/* Show a modal */
function openModal(id){
  const el = q(id); // Get modal
  if(el) el.style.display = "flex"; // Show modal
}

/* Hide all modals */
function closeAllModals(){
  document.querySelectorAll(".modal").forEach(m=>{
    m.style.display = "none"; // Hide modal
  });
}

/* ----------------------------------
   HTML Escape utility
---------------------------------- */
function escapeHtml(str){
  if(str === null || str === undefined) return ""; // Handle empty
  return String(str).replace(/[&<>"]/g, s => ({ // Replace dangerous characters
    '&':'&amp;',
    '<':'&lt;',
    '>':'&gt;',
    '"':'&quot;'
  }[s]));
}
