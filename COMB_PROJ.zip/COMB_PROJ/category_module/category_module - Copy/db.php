<?php
// backend/config/db.php

// Database connection settings
$host = "127.0.0.1";        // Database server (localhost)
$user = "root";             // MySQL username
$pass = "";                 // MySQL password
$db   = "login_system";  // Database name (must match your schema)

// Create a new MySQLi connection instance
$conn = new mysqli($host, $user, $pass, $db);

// Check for a connection error and stop execution if it fails
if ($conn->connect_error) {
    die("DB connection failed: " . $conn->connect_error);
}

// Set character encoding to utf8mb4 to support full UTF-8 (including emojis)
$conn->set_charset("utf8mb4");
