<?php
// Start session to manage user authentication state
session_start();

// If user is already logged in as admin, redirect to dashboard
if (isset($_SESSION['admin_role'])) {
    header("Location: admin_dashboard.php");
    exit; // Stop script execution after redirect
}

// Initialize error variable to display login errors
$error = "";

// Check if form was submitted via POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get email and password from form submission, using null coalescing for safety
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Hardcoded admin credentials check (in production, use database with password hashing)
    if ($email === "admin@mail.com" && $password === "admin123") {
        // Set session variables for authenticated admin user
        $_SESSION['admin_role'] = 'admin';  // User role identifier
        $_SESSION['admin'] = true;          // Admin status flag
        $_SESSION['user_id'] = 1;           // Hardcoded admin user ID
        $_SESSION['email'] = $email;        // Store email in session
        
        // Redirect to admin dashboard after successful login
        header("Location: admin_dashboard.php");
        exit; // Stop script execution after redirect
    } else {
        // Set error message for invalid credentials
        $error = "Invalid admin credentials!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Scratchers</title>
    <!-- Import Google Fonts for typography -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* CSS Reset and Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        /* Main page styling */
        body {
            font-family: 'Outfit', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #f8fafc;
        }
        
        /* Login container with glassmorphism effect */
        .login-container {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 24px;
            padding: 48px 40px;
            width: 100%;
            max-width: 440px;
            box-shadow: 0 16px 48px rgba(0, 102, 255, 0.16);
        }
        
        /* Logo styling */
        .logo {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #0066ff 0%, #0099ff 100%);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            margin: 0 auto 24px;
            box-shadow: 0 8px 32px rgba(0, 102, 255, 0.3);
        }
        
        /* Main heading with gradient text */
        h1 {
            text-align: center;
            font-size: 2rem;
            font-weight: 800;
            background: linear-gradient(135deg, #ffffff 0%, #3385ff 100%);
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
        }
        
        /* Subtitle text */
        .subtitle {
            text-align: center;
            color: #8c94a8;
            margin-bottom: 32px;
            font-size: 1.1rem;
        }
        
        /* Form field spacing */
        .form-group {
            margin-bottom: 24px;
        }
        
        /* Label styling */
        label {
            display: block;
            font-weight: 600;
            margin-bottom: 10px;
            color: #f8fafc;
            font-size: 0.95rem;
        }
        
        /* Input field styling */
        input {
            width: 100%;
            padding: 14px 18px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            font-size: 1rem;
            background: rgba(30, 41, 59, 0.9);
            color: #f8fafc;
            transition: all 0.3s ease;
            font-family: 'Outfit', sans-serif;
        }
        
        /* Input focus state */
        input:focus {
            outline: none;
            border-color: #0066ff;
            background: rgba(30, 41, 59, 0.95);
            box-shadow: 0 0 0 3px rgba(0, 102, 255, 0.3);
        }
        
        /* Login button styling */
        .btn-login {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #0066ff 0%, #0099ff 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Outfit', sans-serif;
            margin-top: 8px;
            box-shadow: 0 4px 16px rgba(0, 102, 255, 0.3);
        }
        
        /* Login button hover effect */
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(0, 102, 255, 0.4);
        }
        
        /* Error message styling */
        .error {
            background: rgba(255, 68, 68, 0.15);
            border: 1px solid rgba(255, 68, 68, 0.3);
            color: #ff6b6b;
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 24px;
            text-align: center;
            font-weight: 500;
        }
        
        /* Back link container */
        .back-link {
            text-align: center;
            margin-top: 24px;
        }
        
        /* Back link styling */
        .back-link a {
            color: #3385ff;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }
        
        /* Back link hover effect */
        .back-link a:hover {
            color: #0066ff;
        }
    </style>
</head>
<body>
    <!-- Main login container -->
    <div class="login-container">
        <!-- Logo icon -->
        <div class="logo">🔐</div>
        <h1>Admin Portal</h1>
        <p class="subtitle">Scratchers Financial Intelligence</p>
        
        <!-- Display error message if login fails -->
        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <!-- Login form -->
        <form method="POST">
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" required placeholder="admin@mail.com" autocomplete="email">
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required placeholder="Enter your password" autocomplete="current-password">
            </div>
            
            <button type="submit" class="btn-login">Login to Admin Panel</button>
        </form>
        
        <!-- Link to return to main dashboard -->
        <div class="back-link">
            <a href="../dashboard-finance2/index.php">← Back to Dashboard</a>
        </div>
    </div>
</body>
</html>