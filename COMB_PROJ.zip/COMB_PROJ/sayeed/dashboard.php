<?php
require_once 'functions_secure.php';
startSecureSession();
requireLogin();

$user = getCurrentUser();
if (!$user) {
    redirect('login.php');
}

/* ============================================
   HANDLE PROFILE UPDATES
   ============================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        setMessage('Security error. Please try again.', 'error');
    } else {
        $action = $_POST['action'] ?? '';
        
        // UPDATE PROFILE
        if ($action === 'update_profile') {
            $name = sanitize($_POST['name']);
            $phone = sanitize($_POST['phone']);
            
            $conn = getSecureConnection();
            $stmt = $conn->prepare("UPDATE users SET name = ?, phone = ? WHERE id = ?");
            $stmt->execute([$name, $phone, $user['id']]);
            
            logSecurityEvent('profile_updated', $user['id']);
            setMessage('Profile updated successfully!', 'success');
            $user = getCurrentUser(); // Refresh user data
        }
        
        // CHANGE PASSWORD
        elseif ($action === 'change_password') {
            $current = $_POST['current_password'];
            $new = $_POST['new_password'];
            $confirm = $_POST['confirm_password'];
            
            if (!password_verify($current, $user['password_hash'])) {
                setMessage('Current password is incorrect.', 'error');
            } elseif (strlen($new) < 8) {
                setMessage('New password must be at least 8 characters.', 'error');
            } elseif ($new !== $confirm) {
                setMessage('New passwords do not match.', 'error');
            } else {
                $hash = password_hash($new, PASSWORD_DEFAULT);
                $conn = getSecureConnection();
                $stmt = $conn->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
                $stmt->execute([$hash, $user['id']]);
                
                logSecurityEvent('password_changed', $user['id']);
                setMessage('Password changed successfully!', 'success');
            }
        }
        
        // DELETE ACCOUNT
        elseif ($action === 'delete_account') {
            $password = $_POST['confirm_password'];
            $confirmation = $_POST['delete_confirmation'];
            
            if (!password_verify($password, $user['password_hash'])) {
                setMessage('Password is incorrect.', 'error');
            } elseif (strtoupper($confirmation) !== 'DELETE') {
                setMessage('Please type DELETE to confirm account deletion.', 'error');
            } else {
                $conn = getSecureConnection();
                $stmt = $conn->prepare("UPDATE users SET is_disabled = 1 WHERE id = ?");
                $stmt->execute([$user['id']]);
                
                logSecurityEvent('account_deleted', $user['id']);
                session_destroy();
                redirect('login.php?deleted=1');
            }
        }
    }
}

// Get user initials for avatar
$initials = strtoupper(substr($user['name'] ?? $user['email'], 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Scratchers</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ============================================
           GLOBAL STYLES
           ============================================ */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        /* ============================================
           TOP NAVIGATION
           ============================================ */
        .top-nav {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .brand {
            font-size: 24px;
            font-weight: 700;
            color: white;
        }

        .profile-trigger {
            display: flex;
            align-items: center;
            gap: 15px;
            cursor: pointer;
            background: rgba(255, 255, 255, 0.1);
            padding: 8px 12px;
            border-radius: 50px;
            transition: all 0.3s;
        }

        .profile-trigger:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }

        .profile-info {
            text-align: right;
        }

        .profile-name {
            color: white;
            font-weight: 600;
            font-size: 14px;
        }

        .profile-role {
            color: rgba(255, 255, 255, 0.8);
            font-size: 12px;
        }

        .profile-avatar {
            width: 40px;
            height: 40px;
            background: white;
            color: #667eea;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 16px;
        }

        /* ============================================
           MAIN CONTENT
           ============================================ */
        .main-content {
            padding: 50px 30px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }

        .card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }

        .card h3 {
            color: #2d3748;
            margin-bottom: 10px;
        }

        .card p {
            color: #718096;
            line-height: 1.6;
        }

        /* ============================================
           MODAL OVERLAY
           ============================================ */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
            z-index: 999;
        }

        .modal-overlay.active {
            display: block;
        }

        /* ============================================
           PROFILE SIDEBAR
           ============================================ */
        .profile-sidebar {
            position: fixed;
            top: 0;
            right: -450px;
            width: 450px;
            height: 100%;
            background: white;
            box-shadow: -5px 0 20px rgba(0, 0, 0, 0.3);
            z-index: 1001;
            transition: right 0.3s ease;
            overflow-y: auto;
        }

        .profile-sidebar.active {
            right: 0;
        }

        .sidebar-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .sidebar-header h2 {
            font-size: 22px;
        }

        .close-btn {
            background: none;
            border: none;
            color: white;
            font-size: 35px;
            cursor: pointer;
            line-height: 1;
            transition: transform 0.2s;
        }

        .close-btn:hover {
            transform: rotate(90deg);
        }

        .sidebar-content {
            padding: 25px;
        }

        /* ============================================
           PROFILE HEADER
           ============================================ */
        .profile-header {
            text-align: center;
            padding: 20px 0;
            border-bottom: 2px solid #e2e8f0;
            margin-bottom: 20px;
        }

        .profile-avatar-large {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 32px;
            margin: 0 auto 15px;
        }

        .profile-header h3 {
            color: #2d3748;
            margin-bottom: 5px;
        }

        .profile-header p {
            color: #718096;
            font-size: 14px;
        }

        /* ============================================
           MENU SECTION
           ============================================ */
        .menu-section {
            margin-bottom: 25px;
        }

        .menu-section-title {
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            color: #a0aec0;
            margin-bottom: 10px;
            letter-spacing: 1px;
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: #f7fafc;
            border-radius: 10px;
            margin-bottom: 8px;
            cursor: pointer;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .menu-item:hover {
            background: #edf2f7;
            border-left-color: #667eea;
            transform: translateX(5px);
        }

        .menu-item-icon {
            font-size: 24px;
        }

        .menu-item-text strong {
            display: block;
            color: #2d3748;
            font-size: 14px;
            margin-bottom: 3px;
        }

        .menu-item-text small {
            color: #718096;
            font-size: 12px;
        }

        /* Delete account menu item styling */
        .menu-item.danger {
            border-left: 3px solid transparent;
        }

        .menu-item.danger:hover {
            background: #fff5f5;
            border-left-color: #f56565;
        }

        .menu-item.danger .menu-item-text strong {
            color: #c53030;
        }

        .menu-item.danger .menu-item-text small {
            color: #e53e3e;
        }

        /* ============================================
           FORM SECTIONS
           ============================================ */
        .form-section {
            display: none;
        }

        .form-section.active {
            display: block;
        }

        .back-btn {
            display: inline-flex;
            align-items: center;
            color: #667eea;
            cursor: pointer;
            font-weight: 600;
            margin-bottom: 20px;
            transition: all 0.2s;
        }

        .back-btn:hover {
            transform: translateX(-5px);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #2d3748;
            font-weight: 600;
            font-size: 14px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
        }

        /* ============================================
           INFO GRID
           ============================================ */
        .info-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 15px;
        }

        .info-item {
            background: #f7fafc;
            padding: 15px;
            border-radius: 8px;
        }

        .info-label {
            font-size: 12px;
            color: #718096;
            margin-bottom: 5px;
            font-weight: 600;
        }

        .info-value {
            color: #2d3748;
            font-size: 15px;
            font-weight: 500;
        }

        /* ============================================
           BUTTONS
           ============================================ */
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
        }

        .btn-primary {
            background: #667eea;
            color: white;
        }

        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }

        .btn-danger {
            background: #f56565;
            color: white;
        }

        .btn-danger:hover {
            background: #e53e3e;
            transform: translateY(-2px);
        }

        .logout-btn {
            width: 100%;
            padding: 15px;
            background: #f56565;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            margin-top: 20px;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: #e53e3e;
            transform: translateY(-2px);
        }

        /* ============================================
           MESSAGES
           ============================================ */
        .message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .message-success {
            background: #c6f6d5;
            color: #22543d;
            border-left: 4px solid #38a169;
        }

        .message-error {
            background: #fed7d7;
            color: #742a2a;
            border-left: 4px solid #e53e3e;
        }

        .message-info {
            background: #bee3f8;
            color: #2c5282;
            border-left: 4px solid #3182ce;
        }

        /* ============================================
           WARNING BOX
           ============================================ */
        .warning-box {
            background: #fffaf0;
            border: 2px solid #f6ad55;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }

        .warning-box h4 {
            color: #c05621;
            margin-bottom: 8px;
            font-size: 16px;
        }

        .warning-box p {
            color: #744210;
            font-size: 14px;
            line-height: 1.6;
        }

        .warning-box ul {
            margin-top: 10px;
            margin-left: 20px;
            color: #744210;
        }

        .warning-box ul li {
            margin-bottom: 5px;
        }

        /* ============================================
           RESPONSIVE
           ============================================ */
        @media (max-width: 768px) {
            .profile-sidebar {
                width: 100%;
                right: -100%;
            }
        }
    </style>
</head>
<body>
    <!-- ============================================
         TOP NAVIGATION
         ============================================ -->
    <div class="top-nav">
        <div class="brand">💰 Scratchers</div>
        <div class="profile-trigger" onclick="openProfileSidebar()">
            <div class="profile-info">
                <div class="profile-name"><?php echo sanitize($user['name'] ?? $user['email']); ?></div>
                <div class="profile-role"><?php echo ucfirst($user['role']); ?></div>
            </div>
            <div class="profile-avatar"><?php echo $initials; ?></div>
        </div>
    </div>

    <!-- ============================================
         MAIN CONTENT (' dashboard goes here)
         ============================================ -->
    <div class="main-content">
        <h1 style="color: white; font-size: 36px; margin-bottom: 10px;">Welcome Back! 👋</h1>
        <p style="color: rgba(255,255,255,0.9); font-size: 18px; margin-bottom: 30px;">
            Manage your finances and track your progress
        </p>

        <div class="dashboard-grid">
            <div class="card">
                <div class="card-icon">💰</div>
                <h3>Finance Tracker</h3>
                <p>Track your income, expenses, and savings goals all in one place.</p>
            </div>
            <div class="card">
                <div class="card-icon">📊</div>
                <h3>Analytics Dashboard</h3>
                <p>Visualize your spending patterns with detailed charts and insights.</p>
            </div>
            <div class="card">
                <div class="card-icon">🎯</div>
                <h3>Budget Planning</h3>
                <p>Set budgets for different categories and get alerts before overspending.</p>
            </div>
        </div>
    </div>

    <!-- ============================================
         MODAL OVERLAY
         ============================================ -->
    <div class="modal-overlay" id="modalOverlay" onclick="closeProfileSidebar()"></div>

    <!-- ============================================
         PROFILE SIDEBAR
         ============================================ -->
    <div class="profile-sidebar" id="profileSidebar">
        <!-- SIDEBAR HEADER -->
        <div class="sidebar-header">
            <h2>Profile Settings</h2>
            <button class="close-btn" onclick="closeProfileSidebar()">×</button>
        </div>

        <!-- SIDEBAR CONTENT -->
        <div class="sidebar-content">
            <?php displayMessage(); ?>

            <!-- MAIN MENU -->
            <div id="mainMenu">
                <div class="profile-header">
                    <div class="profile-avatar-large"><?php echo $initials; ?></div>
                    <h3><?php echo sanitize($user['name'] ?? 'User'); ?></h3>
                    <p><?php echo sanitize($user['email']); ?></p>
                </div>

                <div class="menu-section">
                    <div class="menu-section-title">Profile</div>
                    
                    <div class="menu-item" onclick="showSection('viewProfile')">
                        <span class="menu-item-icon">👤</span>
                        <div class="menu-item-text">
                            <strong>View Profile</strong>
                            <small>See your profile information</small>
                        </div>
                    </div>

                    <div class="menu-item" onclick="showSection('editProfile')">
                        <span class="menu-item-icon">✏️</span>
                        <div class="menu-item-text">
                            <strong>Edit Profile</strong>
                            <small>Update your information</small>
                        </div>
                    </div>

                    <div class="menu-item" onclick="showSection('changePassword')">
                        <span class="menu-item-icon">🔐</span>
                        <div class="menu-item-text">
                            <strong>Change Password</strong>
                            <small>Update your password</small>
                        </div>
                    </div>

                    <div class="menu-item danger" onclick="showSection('deleteAccount')">
                        <span class="menu-item-icon">⚠️</span>
                        <div class="menu-item-text">
                            <strong>Delete Account</strong>
                            <small>Permanently remove your account</small>
                        </div>
                    </div>
                </div>

                <?php if (isAdmin()): ?>
                <div class="menu-section">
                    <div class="menu-section-title">Admin</div>
                    
                    <div class="menu-item" onclick="window.location.href='admin_dashboard.php'">
                        <span class="menu-item-icon">⚙️</span>
                        <div class="menu-item-text">
                            <strong>Admin Dashboard</strong>
                            <small>Manage users and system</small>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <button class="logout-btn" onclick="window.location.href='logout.php'">
                    Logout
                </button>
            </div>

            <!-- VIEW PROFILE SECTION -->
            <div id="viewProfile" class="form-section">
                <div class="back-btn" onclick="showSection('mainMenu')">← Back</div>
                <h3 style="margin-bottom: 20px; color: #2d3748;">Profile Information</h3>

                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label">Full Name</div>
                        <div class="info-value"><?php echo sanitize($user['name'] ?? 'Not set'); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Email Address</div>
                        <div class="info-value"><?php echo sanitize($user['email']); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Phone Number</div>
                        <div class="info-value"><?php echo sanitize($user['phone'] ?? 'Not set'); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Role</div>
                        <div class="info-value"><?php echo ucfirst($user['role']); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Account Status</div>
                        <div class="info-value"><?php echo $user['is_disabled'] ? 'Disabled' : 'Active'; ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Member Since</div>
                        <div class="info-value"><?php echo date('F j, Y', strtotime($user['created_at'])); ?></div>
                    </div>
                </div>
            </div>

            <!-- EDIT PROFILE SECTION -->
            <div id="editProfile" class="form-section">
                <div class="back-btn" onclick="showSection('mainMenu')">← Back</div>
                <h3 style="margin-bottom: 20px; color: #2d3748;">Edit Profile</h3>

                <form method="POST">
                    <input type="hidden" name="action" value="update_profile">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">

                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="name" value="<?php echo sanitize($user['name'] ?? ''); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="text" name="phone" value="<?php echo sanitize($user['phone'] ?? ''); ?>">
                    </div>

                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </form>
            </div>

            <!-- CHANGE PASSWORD SECTION -->
            <div id="changePassword" class="form-section">
                <div class="back-btn" onclick="showSection('mainMenu')">← Back</div>
                <h3 style="margin-bottom: 20px; color: #2d3748;">Change Password</h3>

                <form method="POST">
                    <input type="hidden" name="action" value="change_password">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">

                    <div class="form-group">
                        <label>Current Password</label>
                        <input type="password" name="current_password" required>
                    </div>

                    <div class="form-group">
                        <label>New Password (min 8 characters)</label>
                        <input type="password" name="new_password" required minlength="8">
                    </div>

                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" required minlength="8">
                    </div>

                    <button type="submit" class="btn btn-primary">Update Password</button>
                </form>
            </div>

            <!-- DELETE ACCOUNT SECTION -->
            <div id="deleteAccount" class="form-section">
                <div class="back-btn" onclick="showSection('mainMenu')">← Back</div>
                <h3 style="margin-bottom: 20px; color: #c53030;">Delete Account</h3>

                <div class="warning-box">
                    <h4>⚠️ Warning: This action cannot be undone!</h4>
                    <p>Deleting your account will:</p>
                    <ul>
                        <li>Permanently disable your account</li>
                        <li>Remove access to all your data</li>
                        <li>Log you out immediately</li>
                    </ul>
                    <p style="margin-top: 10px;"><strong>Please make sure you want to proceed before confirming.</strong></p>
                </div>

                <form method="POST" onsubmit="return confirm('Are you absolutely sure you want to delete your account? This cannot be undone!');">
                    <input type="hidden" name="action" value="delete_account">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">

                    <div class="form-group">
                        <label>Enter Your Password</label>
                        <input type="password" name="confirm_password" required placeholder="Your current password">
                    </div>

                    <div class="form-group">
                        <label>Type "DELETE" to confirm</label>
                        <input type="text" name="delete_confirmation" required placeholder="Type DELETE in capital letters">
                    </div>

                    <button type="submit" class="btn btn-danger">Delete My Account</button>
                </form>
            </div>
        </div>
    </div>

    <!-- ============================================
         JAVASCRIPT
         ============================================ -->
    <script>
        function openProfileSidebar() {
            document.getElementById('profileSidebar').classList.add('active');
            document.getElementById('modalOverlay').classList.add('active');
        }

        function closeProfileSidebar() {
            document.getElementById('profileSidebar').classList.remove('active');
            document.getElementById('modalOverlay').classList.remove('active');
            showSection('mainMenu');
        }

        function showSection(sectionId) {
            // Hide all sections
            document.querySelectorAll('.form-section').forEach(section => {
                section.classList.remove('active');
            });
            
            // Hide main menu
            document.getElementById('mainMenu').style.display = 'none';
            
            // Show requested section
            if (sectionId === 'mainMenu') {
                document.getElementById('mainMenu').style.display = 'block';
            } else {
                document.getElementById(sectionId).classList.add('active');
            }
        }

        // Auto-open sidebar if there's a flash message
        <?php if (isset($_SESSION['flash_message'])): ?>
            setTimeout(() => openProfileSidebar(), 100);
        <?php endif; ?>
    </script>
</body>
</html>