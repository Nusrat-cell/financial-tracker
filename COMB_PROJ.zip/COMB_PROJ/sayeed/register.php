<?php
/**
 * User Registration System with Email Verification
 * 
 * This script handles user registration with email verification.
 * Features:
 * - User registration with password validation
 * - Email verification with 6-digit code
 * - Code expiration after 15 minutes
 * - Resend verification code functionality
 * 
 * @author Scratchers Team
 * @version 1.0
 */

// Enable error reporting for debugging (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session to track verification state
session_start();

// Include PHPMailer library for sending emails
require __DIR__ . "/../PHPMailer-master/src/PHPMailer.php";
require __DIR__ . "/../PHPMailer-master/src/SMTP.php";
require __DIR__ . "/../PHPMailer-master/src/Exception.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Initialize message variable for user feedback
$message = "";

// Database configuration
// TODO: Move these to a separate config file or environment variables for security
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "login_system";

/**
 * STEP 1: USER REGISTRATION
 * Handles new user registration with email and password
 */
if (isset($_POST['register'])) {
    // Validate and sanitize email input
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'];
    
    // Validation checks
    if (!$email) {
        $message = "Invalid email address!";
    } elseif (strlen($password) < 8) {
        $message = "Password must be at least 8 characters long!";
    } else {
        // Establish database connection
        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
        
        if ($conn->connect_error) {
            $message = "Database connection failed: " . $conn->connect_error;
        } else {
            // Check if email already exists in database
            $stmt = $conn->prepare("SELECT id, is_verified FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                // Email exists - check verification status
                $user = $result->fetch_assoc();
                if ($user['is_verified'] == 1) {
                    $message = "Email already registered and verified!";
                } else {
                    $message = "Email already registered but not verified. Please check your email or request a new code.";
                }
            } else {
                // Create new user account
                // Hash password using bcrypt for security
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                // Generate random 6-digit verification code
                $vcode = random_int(100000, 999999);
                
                // Record creation timestamp for expiration check
                $created_at = date('Y-m-d H:i:s');
                
                // Insert new user into database with unverified status
                $stmt = $conn->prepare("INSERT INTO users (email, password_hash, verification_code, is_verified, role, created_at) VALUES (?, ?, ?, 0, 'user', ?)");
                $stmt->bind_param("ssis", $email, $hashed_password, $vcode, $created_at);
                
                if ($stmt->execute()) {
                    // Send verification email with code
                    if (sendVerificationEmail($email, $vcode)) {
                        $message = "Registration successful! We sent a verification code to your email.";
                        // Store email in session to display verification form
                        $_SESSION['pending_verification_email'] = $email;
                    } else {
                        $message = "Registration successful but failed to send email. Please contact support.";
                        // TODO: Implement retry mechanism or queue for failed emails
                    }
                } else {
                    $message = "Registration failed! Please try again.";
                }
            }
            
            // Clean up database resources
            $stmt->close();
            $conn->close();
        }
    }
}

/**
 * STEP 2: EMAIL VERIFICATION
 * Verifies user's email using the 6-digit code sent via email
 */
if (isset($_POST['verify'])) {
    $email = $_POST['email'];
    $code = $_POST['code'];
    
    // Establish database connection
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    
    if ($conn->connect_error) {
        $message = "Database connection failed: " . $conn->connect_error;
    } else {
        // Retrieve user information and verification code
        $stmt = $conn->prepare("SELECT id, verification_code, created_at, is_verified FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 0) {
            $message = "Email not found!";
        } else {
            $user = $result->fetch_assoc();
            
            // Check if account is already verified
            if ($user['is_verified'] == 1) {
                $message = "Account already verified! You can now login.";
                unset($_SESSION['pending_verification_email']);
            } 
            // Check if verification code has expired (15 minutes = 900 seconds)
            elseif ((time() - strtotime($user['created_at'])) > 900) {
                $message = "Verification code expired! Please register again.";
                
                // Delete expired unverified user to allow re-registration
                $deleteStmt = $conn->prepare("DELETE FROM users WHERE id = ? AND is_verified = 0");
                $deleteStmt->bind_param("i", $user['id']);
                $deleteStmt->execute();
            }
            // Verify if entered code matches stored code
            elseif ($code == $user['verification_code']) {
                // Mark user as verified and clear verification code
                $updateStmt = $conn->prepare("UPDATE users SET is_verified = 1, verification_code = NULL WHERE id = ?");
                $updateStmt->bind_param("i", $user['id']);
                
                if ($updateStmt->execute()) {
                    $message = "Email verified successfully! You can now login.";
                    // Clear session variable as verification is complete
                    unset($_SESSION['pending_verification_email']);
                } else {
                    $message = "Verification failed! Please try again.";
                }
            } else {
                $message = "Invalid verification code!";
            }
        }
        
        // Clean up database resources
        $stmt->close();
        $conn->close();
    }
}

/**
 * STEP 3: RESEND VERIFICATION CODE
 * Generates and sends a new verification code to the user
 */
if (isset($_POST['resend_code'])) {
    $email = $_POST['resend_email'];
    
    // Establish database connection
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    
    if ($conn->connect_error) {
        $message = "Database connection failed: " . $conn->connect_error;
    } else {
        // Check if user exists
        $stmt = $conn->prepare("SELECT id, is_verified FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 0) {
            $message = "Email not found!";
        } else {
            $user = $result->fetch_assoc();
            
            if ($user['is_verified'] == 1) {
                $message = "Account already verified!";
            } else {
                // Generate new 6-digit verification code
                $new_vcode = random_int(100000, 999999);
                
                // Update timestamp to reset expiration timer
                $new_time = date('Y-m-d H:i:s');
                
                // Update database with new code and timestamp
                $updateStmt = $conn->prepare("UPDATE users SET verification_code = ?, created_at = ? WHERE id = ?");
                $updateStmt->bind_param("isi", $new_vcode, $new_time, $user['id']);
                
                if ($updateStmt->execute()) {
                    // Send new verification email
                    if (sendVerificationEmail($email, $new_vcode)) {
                        $message = "New verification code sent to your email!";
                        $_SESSION['pending_verification_email'] = $email;
                    } else {
                        $message = "Failed to send email. Please try again.";
                    }
                }
            }
        }
        
        // Clean up database resources
        $stmt->close();
        $conn->close();
    }
}

/**
 * Send Verification Email Function
 * 
 * Sends an email containing the 6-digit verification code using PHPMailer
 * 
 * @param string $email The recipient's email address
 * @param int $vcode The 6-digit verification code
 * @return bool True if email sent successfully, false otherwise
 */
function sendVerificationEmail($email, $vcode) {
    $mail = new PHPMailer(true);

    try {
        // Configure SMTP settings for Gmail
        $mail->isSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;
        
        // Email credentials (TODO: Move to environment variables)
        $mail->Username = "scratcherstest@gmail.com";
        $mail->Password = "gjwugwmzthqeaepq"; // App-specific password
        
        // SSL encryption on port 465
        $mail->SMTPSecure = "ssl";
        $mail->Port = 465;

        // Set sender and recipient
        $mail->setFrom("scratcherstest@gmail.com", "Verification System");
        $mail->addAddress($email);
        
        // Email content
        $mail->Subject = "Your Verification Code";
        $mail->Body = "Your verification code is: " . $vcode . "\n\nThis code will expire in 15 minutes.";

        // Send email and return result
        return $mail->send();
    } catch (Exception $e) {
        // Log error for debugging (do not expose to user)
        error_log("Email error: " . $mail->ErrorInfo);
        return false;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <!-- Link to external stylesheet for better organization -->
    <link rel="stylesheet" href="register.css">
</head>
<body>
    <div class="container">
        <!-- Logo -->
        <div class="logo">💰</div>
        
        <!-- Page Title -->
        <h2>User Registration</h2>
        <p class="subtitle">Join Scratchers - Your Financial Platform</p>
        
        <!-- Display feedback messages to user -->
        <?php if ($message): ?>
            <div class="message <?php echo (strpos($message, 'success') !== false || strpos($message, 'sent') !== false || strpos($message, 'verified') !== false) ? 'success' : 'error'; ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['pending_verification_email'])): ?>
            <!-- VERIFICATION FORM - Shown after registration -->
            <form method="POST">
                <div class="form-group">
                    <label>Verification Code</label>
                    <p class="info-text">Sent to: <?= htmlspecialchars($_SESSION['pending_verification_email']) ?></p>
                    
                    <!-- Hidden field to preserve email -->
                    <input type="hidden" name="email" value="<?= htmlspecialchars($_SESSION['pending_verification_email']) ?>">
                    
                    <!-- 6-digit code input with validation -->
                    <input type="text" name="code" required pattern="[0-9]{6}" maxlength="6" placeholder="Enter 6-digit code">
                </div>

                <button type="submit" name="verify">Verify Email</button>
            </form>

            <!-- RESEND CODE FORM - Allow user to request new code -->
            <form method="POST">
                <input type="hidden" name="resend_email" value="<?= htmlspecialchars($_SESSION['pending_verification_email']) ?>">
                <button type="submit" name="resend_code" class="btn-secondary">Resend Code</button>
            </form>

            <!-- Link to register with different email -->
            <p style="text-align: center; margin-top: 15px; color: #718096;">
                <a href="register.php">← Register different email</a>
            </p>
        <?php else: ?>
            <!-- REGISTRATION FORM - Initial registration -->
            <form method="POST">
                <div class="form-group">
                    <label>Email:</label>
                    <input type="email" name="email" required placeholder="your@email.com">
                </div>
                
                <div class="form-group">
                    <label>Password:</label>
                    <!-- Minimum 8 characters enforced both client and server side -->
                    <input type="password" name="password" required minlength="8" placeholder="Minimum 8 characters">
                </div>

                <button type="submit" name="register">Register</button>
            </form>

            <!-- Link to login page for existing users -->
            <p class="text-center">
                Already have an account? <a href="login.php">Login here</a>
            </p>
        <?php endif; ?>
    </div>
</body>
</html>