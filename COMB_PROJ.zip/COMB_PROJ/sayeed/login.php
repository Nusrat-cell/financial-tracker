<?php
require_once 'functions_secure.php';
startSecureSession();
$conn = getSecureConnection();

$message = "";

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $loginType = $_POST['login_type'] ?? 'user'; // Get login type

    // Admin login
    if ($loginType === 'admin') {
        if ($email === "admin@mail.com" && $password === "admin123") {
            $_SESSION['admin'] = true;
            $_SESSION['user_role'] = 'admin';
            $_SESSION['user_id'] = 1; // Admin user ID
            $_SESSION['email'] = $email;
            // Redirect to admin dashboard - FIXED LINE 21-
            header("Location: ../sayeed/admin_dashboard.php");
            exit();
        } else {
            $message = "Invalid admin credentials.";
        }
    } 
    // User login
    else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);

        if ($stmt->rowCount() === 1) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (password_verify($password, $row['password_hash'])) {
                $_SESSION['user'] = $row['email'];
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['user_role'] = $row['role'] ?? 'user';
                // Redirect to user dashboard
                header("Location: /COMB_PROJ/dashboard-finance2/index.php");
        exit();
            } else {
                $message = "Incorrect password.";
            }
        } else {
            $message = "Email not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="register.css">
    <style>
        /* Login mode toggle styling */
        .login-modes {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            border-bottom: 2px solid #ddd;
        }
        
        /* Individual mode tab */
        .mode-tab {
            padding: 10px 20px;
            cursor: pointer;
            border: none;
            background: none;
            font-size: 15px;
            border-bottom: 3px solid transparent;
            transition: all 0.3s;
        }
        
        /* Active tab gets underline */
        .mode-tab.active {
            border-bottom-color: #333;
            font-weight: bold;
        }
        
        /* Hover effect */
        .mode-tab:hover {
            background: #f5f5f5;
        }
        
        /* Forgot password link */
        .forgot-link {
            display: block;
            text-align: right;
            margin-top: 8px;
            font-size: 13px;
            text-decoration: none;
        }
        
        .forgot-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Login</h2>

    <!-- Simple tab-style toggle between User and Admin -->
    <div class="login-modes">
        <button type="button" class="mode-tab active" id="userTab" onclick="switchMode('user')">
            👤 User Login
        </button>
        <button type="button" class="mode-tab" id="adminTab" onclick="switchMode('admin')">
            ⚙️ Admin Login
        </button>
    </div>

    <?php if ($message): ?>
        <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="POST">
        <!-- Hidden field tracks current login mode -->
        <input type="hidden" name="login_type" id="loginType" value="user">

        <div class="form-group">
            <label>Email:</label>
            <input type="email" name="email" required>
        </div>

        <div class="form-group">
            <label>Password:</label>
            <input type="password" name="password" required>
            <!-- Forgot password link (hidden for admin) -->
            <a href="forgot_password.php" class="forgot-link" id="forgotLink">
                Forgot Password?
            </a>
        </div>

        <button type="submit" name="login">Login</button>
    </form>

    <script>
        // Switch between User and Admin login modes
        function switchMode(mode) {
            const userTab = document.getElementById('userTab');
            const adminTab = document.getElementById('adminTab');
            const loginType = document.getElementById('loginType');
            const forgotLink = document.getElementById('forgotLink');
            
            if (mode === 'admin') {
                // Activate admin tab
                adminTab.classList.add('active');
                userTab.classList.remove('active');
                loginType.value = 'admin';
                forgotLink.style.display = 'none'; // Hide forgot password
            } else {
                // Activate user tab
                userTab.classList.add('active');
                adminTab.classList.remove('active');
                loginType.value = 'user';
                forgotLink.style.display = 'block'; // Show forgot password
            }
        }
    </script>
</div>
</body>
</html>