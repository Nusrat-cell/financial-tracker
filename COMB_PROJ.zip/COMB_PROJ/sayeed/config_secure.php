<?php
// Database settings
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'login_system');

// Session lifetime in seconds (30 minutes)
define('SESSION_LIFETIME', 1800);



?>
