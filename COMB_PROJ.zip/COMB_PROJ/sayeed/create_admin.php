<?php
/**
 * Create Admin User Script
 * Run this file ONCE in your browser to create an admin user
 * Example: http://localhost/create_admin.php
 * 
 * IMPORTANT: DELETE THIS FILE AFTER CREATING ADMIN!
 */

require_once 'config_secure.php';

echo "<h2>Creating Admin User...</h2>";

// Admin credentials
$email = 'admin@gmail.com';
$name = 'Admin User';
$password = 'admin123';
$password_hash = password_hash($password, PASSWORD_DEFAULT);

// Check if admin already exists
$check = $conn->prepare("SELECT id, email FROM users WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    echo "<p style='color: red;'>❌ Admin user already exists with this email!</p>";
    $existing = $result->fetch_assoc();
    echo "<p>User ID: " . $existing['id'] . "</p>";
    echo "<p>Email: " . $existing['email'] . "</p>";
    echo "<hr>";
    echo "<h3>Options:</h3>";
    echo "<p>1. Login with existing account</p>";
    echo "<p>2. Or run this to delete and recreate:</p>";
    echo "<pre>DELETE FROM users WHERE email = 'admin@example.com';</pre>";
} else {
    // Create admin user
    $stmt = $conn->prepare("INSERT INTO users (email, name, password_hash, role, is_verified, is_disabled, created_at, updated_at) VALUES (?, ?, ?, 'admin', 1, 0, NOW(), NOW())");
    $stmt->bind_param("sss", $email, $name, $password_hash);
    
    if ($stmt->execute()) {
        echo "<p style='color: green; font-weight: bold;'>✅ Admin user created successfully!</p>";
        echo "<hr>";
        echo "<h3>Login Credentials:</h3>";
        echo "<p><strong>Email:</strong> admin@example.com</p>";
        echo "<p><strong>Password:</strong> admin123</p>";
        echo "<hr>";
        echo "<p style='color: red; font-weight: bold;'>⚠️ IMPORTANT: DELETE THIS FILE NOW!</p>";
        echo "<p><a href='login.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;'>Go to Login</a></p>";
    } else {
        echo "<p style='color: red;'>❌ Error creating admin: " . $conn->error . "</p>";
    }
}

// Show all users in database
echo "<hr>";
echo "<h3>All Users in Database:</h3>";
$all_users = $conn->query("SELECT id, email, name, role, is_verified, is_disabled FROM users");
if ($all_users->num_rows > 0) {
    echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
    echo "<tr><th>ID</th><th>Email</th><th>Name</th><th>Role</th><th>Verified</th><th>Disabled</th></tr>";
    while ($user = $all_users->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $user['id'] . "</td>";
        echo "<td>" . $user['email'] . "</td>";
        echo "<td>" . ($user['name'] ?: 'N/A') . "</td>";
        echo "<td><strong>" . strtoupper($user['role']) . "</strong></td>";
        echo "<td>" . ($user['is_verified'] ? '✅' : '❌') . "</td>";
        echo "<td>" . ($user['is_disabled'] ? '❌' : '✅') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No users found in database.</p>";
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Admin User</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        table {
            width: 100%;
            background: white;
        }
        th {
            background: #007bff;
            color: white;
        }
    </style>
</head>
<body>
</body>
</html>