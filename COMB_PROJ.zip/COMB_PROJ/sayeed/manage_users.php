<?php
session_start();
if ($_SESSION['admin_role'] != "admin") { die("Not allowed."); }

$conn = new mysqli("localhost", "root", "", "login_system");

if (isset($_GET['disable'])) {
    $id = $_GET['disable'];
    $conn->query("UPDATE users SET is_disabled=1 WHERE id=$id");
}

if (isset($_GET['enable'])) {
    $id = $_GET['enable'];
    $conn->query("UPDATE users SET is_disabled=0 WHERE id=$id");
}

$users = $conn->query("SELECT * FROM users");
?>

<h2>Manage Users</h2>
<table border="1" cellpadding="5">
<tr>
    <th>Email</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php while ($u = $users->fetch_assoc()) { ?>
<tr>
    <td><?= $u['email'] ?></td>
    <td><?= $u['is_disabled'] ? 'Disabled' : 'Active' ?></td>
    <td>
        <?php if ($u['is_disabled'] == 0) { ?>
            <a href="manage_users.php?disable=<?= $u['id'] ?>">Disable</a>
        <?php } else { ?>
            <a href="manage_users.php?enable=<?= $u['id'] ?>">Enable</a>
        <?php } ?>
    </td>
</tr>
<?php } ?>

</table>

<p><a href="admin_dashboard.php">Back</a></p>
