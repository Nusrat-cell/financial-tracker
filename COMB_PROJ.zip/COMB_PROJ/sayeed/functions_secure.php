<?php
require_once 'config_secure.php';

/* ============================================
   SESSION MANAGEMENT
   ============================================ */
function startSecureSession() {
    if (session_status() === PHP_SESSION_NONE) {
        ini_set('session.cookie_httponly', 1);
        ini_set('session.cookie_secure', 0); // Set 1 if using HTTPS
        ini_set('session.cookie_samesite', 'Strict');
        ini_set('session.use_strict_mode', 1);
        session_start();

        // Session timeout check
        if (isset($_SESSION['last_activity']) &&
            (time() - $_SESSION['last_activity'] > SESSION_LIFETIME)) {
            session_unset();
            session_destroy();
            session_start();
        }

        $_SESSION['last_activity'] = time();
    }
}

/* ============================================
   DATABASE CONNECTION
   ============================================ */
function getSecureConnection() {
    try {
        $conn = new PDO(
            "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
            DB_USER,
            DB_PASS
        );
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

/* ============================================
   USER AUTHENTICATION - WORKS WITH YOUR EXISTING LOGIN
   ============================================ */
function isLoggedIn() {
    // Check multiple session variables for compatibility
    return isset($_SESSION['user_id']) || isset($_SESSION['user']) || isset($_SESSION['admin']);
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;

    $conn = getSecureConnection();
    
    // Try user_id first (new system)
    if (isset($_SESSION['user_id'])) {
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ? AND is_disabled = 0 LIMIT 1");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) return $user;
    }
    
    // Try email-based session (your existing system)
    if (isset($_SESSION['user'])) {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND is_disabled = 0 LIMIT 1");
        $stmt->execute([$_SESSION['user']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            // Set user_id for consistency
            $_SESSION['user_id'] = $user['id'];
            return $user;
        }
    }
    
    // Try admin session
    if (isset($_SESSION['admin']) && $_SESSION['admin'] === true) {
        $stmt = $conn->prepare("SELECT * FROM users WHERE role = 'admin' LIMIT 1");
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            // Set user_id for consistency
            $_SESSION['user_id'] = $user['id'];
            return $user;
        }
    }

    return null;
}

function isAdmin() {
    $user = getCurrentUser();
    return $user && $user['role'] === 'admin';
}

function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit();
    }
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        die("<h2>Access Denied - Admin Only</h2>");
    }
}

/* ============================================
   SECURITY FUNCTIONS
   ============================================ */
function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function generateCsrfToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function logSecurityEvent($event, $user_id = null) {
    // Optional: Log security events to database
    // You can implement this later if needed
}

/* ============================================
   FLASH MESSAGES
   ============================================ */
function setMessage($msg, $type = 'info') {
    $_SESSION['flash_message'] = $msg;
    $_SESSION['flash_type'] = $type;
}

function displayMessage() {
    if (!isset($_SESSION['flash_message'])) return;
    $msg = sanitize($_SESSION['flash_message']);
    $type = sanitize($_SESSION['flash_type'] ?? 'info');
    echo "<div class='message message-$type'>$msg</div>";
    unset($_SESSION['flash_message']);
    unset($_SESSION['flash_type']);
}

/* ============================================
   REDIRECT HELPER
   ============================================ */
function redirect($url) {
    header("Location: $url");
    exit();
}
?>
