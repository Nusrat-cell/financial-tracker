<?php
/**
 * Admin Dashboard - User Management System
 * Allows admin to view, filter, search, and manage all registered users
 */

session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_role']) || $_SESSION['admin_role'] !== 'admin') {
    header("Location: admin_login.php");
    exit;
}

// Database connection
$conn = new mysqli("localhost", "root", "", "login_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle user deletion with confirmation
if (isset($_GET['delete'])) {
    $user_id = (int)$_GET['delete']; // Cast to int for security
    $conn->query("DELETE FROM users WHERE id = $user_id");
    header("Location: admin_dashboard.php");
    exit;
}

// Get filter and search parameters from URL
$filter = $_GET['filter'] ?? 'all';
$search = $_GET['search'] ?? '';

// Build dynamic WHERE clause based on filter selection
$where = "WHERE 1=1"; // Base condition for easy appending
if ($filter === 'verified') {
    $where .= " AND is_verified = 1";
} elseif ($filter === 'unverified') {
    $where .= " AND is_verified = 0";
} elseif ($filter === 'disabled') {
    $where .= " AND is_disabled = 1";
}

// Add search condition if search term provided
if (!empty($search)) {
    $search_safe = $conn->real_escape_string($search); // Prevent SQL injection
    $where .= " AND (name LIKE '%$search_safe%' OR email LIKE '%$search_safe%')";
}

// Fetch filtered users from database
$users_query = "SELECT * FROM users $where ORDER BY id DESC";
$users_result = $conn->query($users_query);

// Calculate statistics for dashboard cards
$total_users = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
$verified_users = $conn->query("SELECT COUNT(*) as count FROM users WHERE is_verified = 1")->fetch_assoc()['count'];
$unverified_users = $conn->query("SELECT COUNT(*) as count FROM users WHERE is_verified = 0")->fetch_assoc()['count'];
$disabled_users = $conn->query("SELECT COUNT(*) as count FROM users WHERE is_disabled = 1")->fetch_assoc()['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - User Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Outfit', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%);
            min-height: 100vh;
            color: #f8fafc;
            padding: 24px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        /* Header Section */
        .header {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 32px 40px;
            margin-bottom: 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 16px 48px rgba(0, 102, 255, 0.16);
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .logo {
            width: 64px;
            height: 64px;
            background: linear-gradient(135deg, #0066ff 0%, #0099ff 100%);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            box-shadow: 0 8px 32px rgba(0, 102, 255, 0.3);
        }
        
        h1 {
            font-size: 2.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, #ffffff 0%, #3385ff 100%);
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .subtitle {
            color: #8c94a8;
            font-size: 1.1rem;
            margin-top: 4px;
        }
        
        .header-right {
            display: flex;
            gap: 12px;
        }
        
        /* Button Styles */
        .btn {
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            cursor: pointer;
            font-size: 0.95rem;
            border: none;
            font-family: 'Outfit', sans-serif;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #0066ff 0%, #0099ff 100%);
            color: white;
            box-shadow: 0 4px 16px rgba(0, 102, 255, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(0, 102, 255, 0.4);
        }
        
        .btn-secondary {
            background: rgba(255, 255, 255, 0.1);
            color: #f8fafc;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.15);
        }
        
        /* Statistics Cards Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 32px;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 28px 24px;
            transition: all 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.2);
        }
        
        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 12px;
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: #8c94a8;
            margin-bottom: 8px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 800;
            color: #f8fafc;
        }
        
        /* Card Container */
        .card {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 32px;
            box-shadow: 0 16px 48px rgba(0, 102, 255, 0.16);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 28px;
        }
        
        .card-title {
            font-size: 1.5rem;
            font-weight: 700;
        }
        
        /* Filter Buttons */
        .filters {
            display: flex;
            gap: 16px;
            margin-bottom: 24px;
        }
        
        .filter-btn {
            padding: 10px 20px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.05);
            color: #8c94a8;
            border: 1px solid rgba(255, 255, 255, 0.1);
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }
        
        .filter-btn.active,
        .filter-btn:hover {
            background: #0066ff;
            color: white;
            border-color: #0066ff;
        }
        
        /* Search Box */
        .search-box {
            width: 100%;
            max-width: 400px;
            padding: 12px 18px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            background: rgba(30, 41, 59, 0.9);
            color: #f8fafc;
            font-size: 0.95rem;
            font-family: 'Outfit', sans-serif;
        }
        
        .search-box:focus {
            outline: none;
            border-color: #0066ff;
            box-shadow: 0 0 0 3px rgba(0, 102, 255, 0.3);
        }
        
        /* User Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: rgba(255, 255, 255, 0.05);
        }
        
        th {
            padding: 16px;
            text-align: left;
            font-weight: 700;
            color: #f8fafc;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        td {
            padding: 20px 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        tr:hover {
            background: rgba(255, 255, 255, 0.03);
        }
        
        /* Status Badges */
        .badge {
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: inline-block;
        }
        
        .badge-success {
            background: rgba(0, 200, 83, 0.2);
            color: #00c853;
            border: 1px solid rgba(0, 200, 83, 0.3);
        }
        
        .badge-warning {
            background: rgba(255, 170, 0, 0.2);
            color: #ffaa00;
            border: 1px solid rgba(255, 170, 0, 0.3);
        }
        
        .badge-danger {
            background: rgba(255, 68, 68, 0.2);
            color: #ff4444;
            border: 1px solid rgba(255, 68, 68, 0.3);
        }
        
        /* Delete Button */
        .btn-delete {
            background: linear-gradient(135deg, #ff4444 0%, #ff6b6b 100%);
            color: white;
            padding: 8px 16px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-block;
        }
        
        .btn-delete:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(255, 68, 68, 0.4);
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #8c94a8;
        }
        
        .empty-state-icon {
            font-size: 4rem;
            margin-bottom: 16px;
        }
        
        /* Responsive Design */
        @media (max-width: 1200px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 20px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .filters {
                flex-wrap: wrap;
            }
            
            table {
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header Section -->
        <div class="header">
            <div class="header-left">
                <div class="logo">⚙️</div>
                <div>
                    <h1>Admin Dashboard</h1>
                    <p class="subtitle">User Management System</p>
                </div>
            </div>
            <div class="header-right">
                <a href="../dashboard-finance2/index.php" class="btn btn-secondary">📊 Dashboard</a>
                <a href="logout.php" class="btn btn-primary">🚪 Logout</a>
            </div>
        </div>
        
        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">👥</div>
                <div class="stat-label">Total Users</div>
                <div class="stat-value"><?= $total_users ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">✅</div>
                <div class="stat-label">Verified</div>
                <div class="stat-value"><?= $verified_users ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">⏳</div>
                <div class="stat-label">Unverified</div>
                <div class="stat-value"><?= $unverified_users ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">🚫</div>
                <div class="stat-label">Disabled</div>
                <div class="stat-value"><?= $disabled_users ?></div>
            </div>
        </div>
        
        <!-- Users Table Card -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">User Management</h2>
            </div>
            
            <!-- Filter Buttons -->
            <div class="filters">
                <a href="?filter=all" class="filter-btn <?= $filter === 'all' ? 'active' : '' ?>">All Users</a>
                <a href="?filter=verified" class="filter-btn <?= $filter === 'verified' ? 'active' : '' ?>">Verified</a>
                <a href="?filter=unverified" class="filter-btn <?= $filter === 'unverified' ? 'active' : '' ?>">Unverified</a>
                <a href="?filter=disabled" class="filter-btn <?= $filter === 'disabled' ? 'active' : '' ?>">Disabled</a>
            </div>
            
            <!-- Search Form -->
            <form method="GET" style="margin-bottom: 24px;">
                <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
                <input type="text" name="search" class="search-box" 
                       placeholder="Search by name or email..." 
                       value="<?= htmlspecialchars($search) ?>">
            </form>
            
            <!-- Users Table or Empty State -->
            <?php if ($users_result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Verified</th>
                            <th>Registered</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($user = $users_result->fetch_assoc()): ?>
                            <tr>
                                <td><?= $user['id'] ?></td>
                                <td><strong><?= htmlspecialchars($user['name']) ?></strong></td>
                                <td><?= htmlspecialchars($user['email']) ?></td>
                                <td>
                                    <?php if ($user['is_disabled']): ?>
                                        <span class="badge badge-danger">Disabled</span>
                                    <?php else: ?>
                                        <span class="badge badge-success">Active</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($user['is_verified']): ?>
                                        <span class="badge badge-success">✓ Verified</span>
                                    <?php else: ?>
                                        <span class="badge badge-warning">⏳ Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= date('M d, Y', strtotime($user['created_at'] ?? 'now')) ?></td>
                                <td>
                                    <!-- Delete button with confirmation -->
                                    <a href="?delete=<?= $user['id'] ?>&filter=<?= $filter ?>&search=<?= urlencode($search) ?>" 
                                       class="btn-delete"
                                       onclick="return confirm('Are you sure you want to delete this user?')">
                                        🗑️ Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <!-- Empty State when no users found -->
                <div class="empty-state">
                    <div class="empty-state-icon">🔍</div>
                    <p style="font-size: 1.2rem; margin-bottom: 8px;">No users found</p>
                    <p>Try adjusting your search or filters</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?>