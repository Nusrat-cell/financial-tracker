<?php
session_start();
if ($_SESSION['admin_role'] != "audit") { die("Not allowed."); }

$conn = new mysqli("localhost", "root", "", "login_system");

$users = $conn->query("SELECT email, role, is_disabled FROM users");
?>

<h2>Audit Log – View Only</h2>
<table border="1" cellpadding="5">
<tr>
    <th>Email</th>
    <th>Role</th>
    <th>Status</th>
</tr>

<?php while ($u = $users->fetch_assoc()) { ?>
<tr>
    <td><?= $u['email'] ?></td>
    <td><?= $u['role'] ?></td>
    <td><?= $u['is_disabled'] ? 'Disabled' : 'Active' ?></td>
</tr>
<?php } ?>
</table>

<p><a href="admin_dashboard.php">Back</a></p>
