<?php
require_once 'functions_secure.php';
startSecureSession();

// Destroy all session data
session_unset();
session_destroy();

// Start new session for message
session_start();
setMessage('You have been logged out successfully.', 'success');

// Redirect to login page
header("Location: login.php");
exit();
?>
