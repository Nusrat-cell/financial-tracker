<?php
// Database connection
$db_server = "127.0.0.1";
$db_name   = "login_system";
$db_user = "root";
$db_pass = "";
$connection = "";


try{
    $connection = mysqli_connect($db_server, $db_user, $db_pass, $db_name);
    if($connection){
        echo "Database connected successfully.";
    } else {
        echo "Database connection failed: " . mysqli_connect_error();
    }
} catch(Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
 


