<?php
/**
 * ===========================================
 * SCRATCHERS FINANCE - CONFIGURATION FILE
 * ===========================================
 * Main configuration for database, security, and app settings
 */

// Prevent direct access
if (!defined('APP_INIT')) {
    die('Direct access not permitted');
}

// ============================================
// DATABASE CONFIGURATION
// ============================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'scratchers_finance');
define('DB_CHARSET', 'utf8mb4');

// ============================================
// APPLICATION SETTINGS
// ============================================
define('APP_NAME', 'Scratchers Finance');
define('APP_URL', 'http://localhost/scratchers-finance');
define('APP_VERSION', '1.0.0');

// ============================================
// SESSION CONFIGURATION
// ============================================
define('SESSION_LIFETIME', 1800); // 30 minutes in seconds
define('SESSION_NAME', 'SCRATCHERS_SESSION');

// ============================================
// SECURITY SETTINGS
// ============================================
define('PASSWORD_MIN_LENGTH', 8);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes in seconds

// ============================================
// MAILHOG CONFIGURATION (for development)
// ============================================
define('MAIL_HOST', 'localhost');
define('MAIL_PORT', 1025);
define('MAIL_FROM', 'noreply@scratchers.local');
define('MAIL_FROM_NAME', 'Scratchers Finance');

// ============================================
// FILE PATHS
// ============================================
define('BASE_PATH', dirname(__DIR__));
define('INCLUDES_PATH', BASE_PATH . '/includes');
define('CONTROLLERS_PATH', BASE_PATH . '/controllers');
define('VIEWS_PATH', BASE_PATH . '/views');
define('PUBLIC_PATH', BASE_PATH . '/public');
define('LOGS_PATH', BASE_PATH . '/logs');

// ============================================
// ERROR REPORTING (set to 0 in production)
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', LOGS_PATH . '/php_errors.log');

// ============================================
// TIMEZONE
// ============================================
date_default_timezone_set('UTC');
?>