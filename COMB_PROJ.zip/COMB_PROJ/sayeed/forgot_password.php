<?php
session_start();
require '../PHPMailer-master/src/PHPMailer.php';
require '../PHPMailer-master/src/SMTP.php';
require '../PHPMailer-master/src/Exception.php';
$conn = new mysqli("localhost", "root", "", "login_system");

$message = "";
$message_type = ""; // success or error

// Step 1 - user requests password reset
if (isset($_POST['send_code'])) {
    $email = $_POST['email'];

    // Check if user exists
    $result = $conn->query("SELECT * FROM users WHERE email='$email'");
    if ($result->num_rows == 0) {
        $message = "Email not found!";
        $message_type = "error";
    } else {
        $_SESSION['reset_email'] = $email;
        $_SESSION['reset_code'] = rand(100000, 999999);

        // --- SEND EMAIL ---
        $mail = new PHPMailer\PHPMailer\PHPMailer();
        $mail->isSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;
        $mail->Username = "scratcherstest@gmail.com";
        $mail->Password = "gjwugwmzthqeaepq";
        $mail->SMTPSecure = "ssl";
        $mail->Port = 465;

        $mail->setFrom("scratcherstest@gmail.com", "Password Reset");
        $mail->addAddress($email);
        $mail->Subject = "Your Password Reset Code";
        $mail->Body = "Your password reset code is: " . $_SESSION['reset_code'];

        if ($mail->send()) {
            $message = "Reset code sent to your email.";
            $message_type = "success";
            $_SESSION['step'] = 2;
        } else {
            $message = "Error sending email.";
            $message_type = "error";
        }
    }
}

// Step 2 - user verifies the code
if (isset($_POST['verify_code'])) {
    if ($_POST['code'] == $_SESSION['reset_code']) {
        $message = "Code verified. Enter your new password.";
        $message_type = "success";
        $_SESSION['step'] = 3;
    } else {
        $message = "Incorrect verification code!";
        $message_type = "error";
    }
}

// Step 3 - user sets new password
if (isset($_POST['change_password'])) {
    $pass = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
    $email = $_SESSION['reset_email'];

    $stmt = $conn->prepare("UPDATE users SET password_hash=? WHERE email=?");
    $stmt->bind_param("ss", $pass, $email);
    $stmt->execute();
    
    session_destroy();

    $message = "Password updated! You can now log in.";
    $message_type = "success";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Reset Your Account</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            padding: 50px 40px;
            max-width: 450px;
            width: 100%;
            animation: slideUp 0.5s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .header {
            text-align: center;
            margin-bottom: 40px;
        }

        .icon-wrapper {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
        }

        .icon-wrapper svg {
            width: 40px;
            height: 40px;
            color: white;
        }

        h2 {
            color: #2d3748;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .subtitle {
            color: #718096;
            font-size: 14px;
            line-height: 1.6;
        }

        .step-indicator {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 30px;
        }

        .step {
            width: 40px;
            height: 4px;
            background: #e2e8f0;
            border-radius: 2px;
            transition: all 0.3s ease;
        }

        .step.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-size: 14px;
            font-weight: 500;
            animation: slideDown 0.3s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert.success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }

        .alert.error {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            color: #4a5568;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        input[type="email"],
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 14px 18px;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            font-size: 15px;
            transition: all 0.3s ease;
            font-family: 'Inter', sans-serif;
            background: #f7fafc;
        }

        input:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .btn {
            width: 100%;
            padding: 14px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        }

        .btn:active {
            transform: translateY(0);
        }

        .back-link {
            text-align: center;
            margin-top: 25px;
        }

        .back-link a {
            color: #667eea;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .back-link a:hover {
            color: #764ba2;
            text-decoration: underline;
        }

        @media (max-width: 480px) {
            .container {
                padding: 40px 30px;
            }

            h2 {
                font-size: 24px;
            }

            .icon-wrapper {
                width: 70px;
                height: 70px;
            }

            .icon-wrapper svg {
                width: 35px;
                height: 35px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="icon-wrapper">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
            </div>
            <h2>
                <?php 
                if (!isset($_SESSION['step'])) {
                    echo "Forgot Password?";
                } elseif ($_SESSION['step'] == 2) {
                    echo "Verify Code";
                } elseif ($_SESSION['step'] == 3) {
                    echo "Set New Password";
                }
                ?>
            </h2>
            <p class="subtitle">
                <?php 
                if (!isset($_SESSION['step'])) {
                    echo "No worries! Enter your email and we'll send you a reset code.";
                } elseif ($_SESSION['step'] == 2) {
                    echo "Check your email for the 6-digit verification code.";
                } elseif ($_SESSION['step'] == 3) {
                    echo "Choose a strong password for your account.";
                }
                ?>
            </p>
        </div>

        <div class="step-indicator">
            <div class="step <?php echo (!isset($_SESSION['step']) || $_SESSION['step'] >= 1) ? 'active' : ''; ?>"></div>
            <div class="step <?php echo (isset($_SESSION['step']) && $_SESSION['step'] >= 2) ? 'active' : ''; ?>"></div>
            <div class="step <?php echo (isset($_SESSION['step']) && $_SESSION['step'] >= 3) ? 'active' : ''; ?>"></div>
        </div>

        <?php if ($message): ?>
            <div class="alert <?= $message_type ?>">
                <?= $message ?>
            </div>
        <?php endif; ?>

        <?php if (!isset($_SESSION['step'])) { ?>
            <!-- Step 1: Ask for email -->
            <form method="POST">
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" required>
                </div>
                <button type="submit" name="send_code" class="btn">Send Reset Code</button>
            </form>

        <?php } elseif ($_SESSION['step'] == 2) { ?>
            <!-- Step 2: Enter verification code -->
            <form method="POST">
                <div class="form-group">
                    <label for="code">Verification Code</label>
                    <input type="text" id="code" name="code" placeholder="Enter 6-digit code" maxlength="6" required>
                </div>
                <button type="submit" name="verify_code" class="btn">Verify Code</button>
            </form>

        <?php } elseif ($_SESSION['step'] == 3) { ?>
            <!-- Step 3: Enter new password -->
            <form method="POST">
                <div class="form-group">
                    <label for="new_password">New Password</label>
                    <input type="password" id="new_password" name="new_password" placeholder="Enter new password" required>
                </div>
                <button type="submit" name="change_password" class="btn">Update Password</button>
            </form>

        <?php } ?>

        <div class="back-link">
            <a href="login.php">← Back to Login</a>
        </div>
    </div>
</body>
</html>