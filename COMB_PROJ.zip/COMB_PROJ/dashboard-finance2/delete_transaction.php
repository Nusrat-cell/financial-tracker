<?php
// delete_transaction.php
require_once __DIR__ . '/api/db.php';

$id = $_GET['id'] ?? 0;

if ($id) {
    try {
        $stmt = $pdo->prepare("DELETE FROM transactions WHERE id = ?");
        $stmt->execute([$id]);
    } catch (Exception $e) {
        // Handle error if needed
    }
}

// Redirect back to dashboard
header('Location: index.php');
exit;