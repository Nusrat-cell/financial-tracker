<?php
// export_csv.php
require_once __DIR__ . '/api/db.php';

// Get filter values from URL (same as dashboard)
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$search = $_GET['search'] ?? '';

try {
    // Build WHERE clause for filters (same logic as dashboard)
    $whereClause = "";
    $params = [];
    
    if (!empty($start_date) && !empty($end_date)) {
        $whereClause = "WHERE date BETWEEN ? AND ?";
        $params = [$start_date, $end_date];
    } elseif (!empty($start_date)) {
        $whereClause = "WHERE date >= ?";
        $params = [$start_date];
    } elseif (!empty($end_date)) {
        $whereClause = "WHERE date <= ?";
        $params = [$end_date];
    }

    // Add search to WHERE clause
    if (!empty($search)) {
        if (empty($whereClause)) {
            $whereClause = "WHERE (description LIKE ? OR category LIKE ?)";
            $params = ["%$search%", "%$search%"];
        } else {
            $whereClause .= " AND (description LIKE ? OR category LIKE ?)";
            $params = array_merge($params, ["%$search%", "%$search%"]);
        }
    }

    // Get transactions with current filters
    $txQuery = "SELECT description, amount, type, category, date, note 
                FROM transactions 
                $whereClause 
                ORDER BY date DESC, id DESC";
    $txStmt = $pdo->prepare($txQuery);
    $txStmt->execute($params);
    $transactions = $txStmt->fetchAll();

    // Get summary totals
    $summaryQuery = "
        SELECT 
            SUM(CASE WHEN `type` = 'Income' THEN amount ELSE 0 END) AS income,
            SUM(CASE WHEN `type` = 'Expense' THEN amount ELSE 0 END) AS expense
        FROM transactions
        $whereClause
    ";
    $summaryStmt = $pdo->prepare($summaryQuery);
    $summaryStmt->execute($params);
    $summary = $summaryStmt->fetch();
    
    $income = $summary['income'] ?? 0;
    $expense = $summary['expense'] ?? 0;
    $balance = $income - $expense;

    // Set headers for CSV download
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="financial_report_' . date('Y-m-d') . '.csv"');

    // Create output stream
    $output = fopen('php://output', 'w');

    // Add UTF-8 BOM for Excel compatibility
    fputs($output, $bom = (chr(0xEF) . chr(0xBB) . chr(0xBF)));

    // Write summary section
    fputcsv($output, ['FINANCIAL REPORT SUMMARY']);
    fputcsv($output, ['Generated:', date('Y-m-d H:i:s')]);
    fputcsv($output, ['']);
    fputcsv($output, ['Total Income:', '$' . number_format($income, 2)]);
    fputcsv($output, ['Total Expenses:', '$' . number_format($expense, 2)]);
    fputcsv($output, ['Balance:', '$' . number_format($balance, 2)]);
    fputcsv($output, ['']);
    fputcsv($output, ['']);

    // Write transactions header
    fputcsv($output, ['TRANSACTIONS']);
    fputcsv($output, ['Date', 'Description', 'Category', 'Type', 'Amount', 'Note']);

    // Write transaction data
    foreach ($transactions as $tx) {
        fputcsv($output, [
            $tx['date'],
            $tx['description'],
            $tx['category'] ?? '',
            $tx['type'],
            '$' . number_format($tx['amount'], 2),
            $tx['note'] ?? ''
        ]);
    }

    fclose($output);
    exit;

} catch (Exception $e) {
    // If error, redirect back to dashboard
    header('Location: index.php?error=export_failed');
    exit;
}