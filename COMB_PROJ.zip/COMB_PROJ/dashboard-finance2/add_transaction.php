<?php
// add_transaction.php
require_once __DIR__ . '/api/db.php';

$message = '';
$message_type = ''; // success or error

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $description = $_POST['description'] ?? '';
        $amount = $_POST['amount'] ?? '';
        $type = $_POST['type'] ?? '';
        $category = $_POST['category'] ?? '';
        $date = $_POST['date'] ?? '';
        $note = $_POST['note'] ?? '';

        // Basic validation
        if (empty($description) || empty($amount) || empty($type) || empty($date)) {
            throw new Exception('Please fill in all required fields');
        }

        if (!is_numeric($amount) || $amount <= 0) {
            throw new Exception('Amount must be a positive number');
        }

        // Insert into database
        $stmt = $pdo->prepare("
            INSERT INTO transactions (description, amount, type, category, date, note) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([$description, $amount, $type, $category, $date, $note]);
        
        $message = 'Transaction added successfully!';
        $message_type = 'success';
        
    } catch (Exception $e) {
        $message = 'Error: ' . $e->getMessage();
        $message_type = 'error';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Add Transaction - Financial Dashboard</title>
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/modern-css-reset/dist/reset.min.css">
    <style>
        body { font-family: Arial, sans-serif; background:#f4f6f8; padding:20px; }
        .container { max-width: 600px; margin: 0 auto; }
        .form-card { background: white; padding: 25px; border-radius: 10px; box-shadow: 0 6px 18px rgba(0,0,0,0.06); }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; color: #333; }
        input, select, textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; }
        .required { color: red; }
        .btn { padding: 12px 25px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; text-decoration: none; display: inline-block; }
        .btn-primary { background: #0072ff; color: white; }
        .btn-secondary { background: #6c757d; color: white; margin-right: 10px; }
        .message { padding: 15px; margin-bottom: 20px; border-radius: 5px; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Add New Transaction</h1>
        
        <?php if ($message): ?>
            <div class="message <?= $message_type ?>"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <div class="form-card">
            <form method="POST" action="">
                <div class="form-group">
                    <label for="description">Description <span class="required">*</span></label>
                    <input type="text" id="description" name="description" required 
                           value="<?= htmlspecialchars($_POST['description'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label for="amount">Amount <span class="required">*</span></label>
                    <input type="number" id="amount" name="amount" step="0.01" min="0.01" required 
                           value="<?= htmlspecialchars($_POST['amount'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label for="type">Type <span class="required">*</span></label>
                    <select id="type" name="type" required>
                        <option value="">Select Type</option>
                        <option value="Income" <?= ($_POST['type'] ?? '') === 'Income' ? 'selected' : '' ?>>Income</option>
                        <option value="Expense" <?= ($_POST['type'] ?? '') === 'Expense' ? 'selected' : '' ?>>Expense</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="category">Category</label>
                    <input type="text" id="category" name="category" 
                           value="<?= htmlspecialchars($_POST['category'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label for="date">Date <span class="required">*</span></label>
                    <input type="date" id="date" name="date" required 
                           value="<?= htmlspecialchars($_POST['date'] ?? date('Y-m-d')) ?>">
                </div>

                <div class="form-group">
                    <label for="note">Note</label>
                    <textarea id="note" name="note" rows="3"><?= htmlspecialchars($_POST['note'] ?? '') ?></textarea>
                </div>

                <div>
                    <a href="index.php" class="btn btn-secondary">Back to Dashboard</a>
                    <button type="submit" class="btn btn-primary">Add Transaction</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>