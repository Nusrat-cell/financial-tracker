<?php
// index.php - server-rendered dashboard with filters
require_once __DIR__ . '/api/db.php';

// Get filter values from URL
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';

try {
  // Build WHERE clause for filters
  $whereClause = "";
  $params = [];
  
  if (!empty($start_date) && !empty($end_date)) {
    $whereClause = "WHERE date BETWEEN ? AND ?";
    $params = [$start_date, $end_date];
  } elseif (!empty($start_date)) {
    $whereClause = "WHERE date >= ?";
    $params = [$start_date];
  } elseif (!empty($end_date)) {
    $whereClause = "WHERE date <= ?";
    $params = [$end_date];
  }

  // Add search to WHERE clause
  if (!empty($search)) {
    if (empty($whereClause)) {
      $whereClause = "WHERE (description LIKE ? OR category LIKE ?)";
      $params = ["%$search%", "%$search%"];
    } else {
      $whereClause .= " AND (description LIKE ? OR category LIKE ?)";
      $params = array_merge($params, ["%$search%", "%$search%"]);
    }
  }

  // Add category to WHERE clause
  if (!empty($category)) {
    if (empty($whereClause)) {
      $whereClause = "WHERE category = ?";
      $params = [$category];
    } else {
      $whereClause .= " AND category = ?";
      $params[] = $category;
    }
  }

  // Summary totals with filters
  $summaryQuery = "
    SELECT 
      SUM(CASE WHEN `type` = 'Income' THEN amount ELSE 0 END) AS income,
      SUM(CASE WHEN `type` = 'Expense' THEN amount ELSE 0 END) AS expense
    FROM transactions
    $whereClause
  ";
  $summaryStmt = $pdo->prepare($summaryQuery);
  $summaryStmt->execute($params);
  $summary = $summaryStmt->fetch();
  
  $income = isset($summary['income']) ? (float)$summary['income'] : 0;
  $expense = isset($summary['expense']) ? (float)$summary['expense'] : 0;
  $balance = $income - $expense;

  // Recent transactions with filters
  $txQuery = "SELECT id, description, amount, type, category, date, note 
              FROM transactions 
              $whereClause 
              ORDER BY date DESC, id DESC 
              LIMIT 10";
  $txStmt = $pdo->prepare($txQuery);
  $txStmt->execute($params);
  $transactions = $txStmt->fetchAll();

  // Monthly aggregation with filters
  $chartQuery = "
    SELECT DATE_FORMAT(date, '%Y-%m') AS ym,
      SUM(CASE WHEN type='Income' THEN amount ELSE 0 END) AS income,
      SUM(CASE WHEN type='Expense' THEN amount ELSE 0 END) AS expense
    FROM transactions
    WHERE date IS NOT NULL
    " . (empty($whereClause) ? "" : " AND " . substr($whereClause, 5)) . "
    GROUP BY ym
    ORDER BY ym DESC
    LIMIT 6
  ";
  $chartStmt = $pdo->prepare($chartQuery);
  $chartStmt->execute($params);
  $monthlyRaw = array_reverse($chartStmt->fetchAll());
  $monthlyLabels = array_map(fn($r)=>$r['ym'], $monthlyRaw);
  $monthlyIncome = array_map(fn($r)=>(float)$r['income'], $monthlyRaw);
  $monthlyExpense = array_map(fn($r)=>(float)$r['expense'], $monthlyRaw);

} catch (Exception $e) {
  // fallback so UI loads even on error
  $income = $expense = $balance = 0;
  $transactions = [];
  $monthlyLabels = $monthlyIncome = $monthlyExpense = [];
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Scratchers - Financial Intelligence</title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/modern-css-reset/dist/reset.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary: #0066ff;
      --primary-dark: #0052cc;
      --primary-light: #3385ff;
      --success: #00c853;
      --success-dark: #00a844;
      --danger: #ff4444;
      --danger-dark: #cc3636;
      --warning: #ffaa00;
      --warning-dark: #cc8800;
      --dark: #1a1d29;
      --darker: #151822;
      --light: #f8fafc;
      --gray: #8c94a8;
      --gray-light: #e2e8f0;
      --card-bg: #ffffff;
      --card-hover: #f8fafc;
      --gradient-primary: linear-gradient(135deg, var(--primary) 0%, #0099ff 100%);
      --gradient-success: linear-gradient(135deg, var(--success) 0%, #00e676 100%);
      --gradient-danger: linear-gradient(135deg, var(--danger) 0%, #ff6b6b 100%);
      --gradient-warning: linear-gradient(135deg, var(--warning) 0%, #ffd93d 100%);
      --shadow-sm: 0 2px 8px rgba(0, 102, 255, 0.08);
      --shadow-md: 0 8px 32px rgba(0, 102, 255, 0.12);
      --shadow-lg: 0 16px 48px rgba(0, 102, 255, 0.16);
      --border-radius: 16px;
      --border-radius-sm: 12px;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    body { 
      font-family: 'Outfit', sans-serif; 
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%);
      min-height: 100vh;
      color: var(--light);
      line-height: 1.6;
      overflow-x: hidden;
    }
    
    /* Animated background elements */
    .bg-elements {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: -1;
    }
    
    .bg-element {
      position: absolute;
      border-radius: 50%;
      background: var(--primary);
      opacity: 0.03;
      animation: float 20s infinite linear;
    }
    
    .bg-element:nth-child(1) { width: 300px; height: 300px; top: 10%; left: 5%; animation-delay: 0s; }
    .bg-element:nth-child(2) { width: 200px; height: 200px; top: 60%; right: 10%; animation-delay: -5s; }
    .bg-element:nth-child(3) { width: 150px; height: 150px; bottom: 20%; left: 15%; animation-delay: -10s; }
    
    @keyframes float {
      0%, 100% { transform: translateY(0px) rotate(0deg); }
      25% { transform: translateY(-20px) rotate(90deg); }
      50% { transform: translateY(0px) rotate(180deg); }
      75% { transform: translateY(20px) rotate(270deg); }
    }
    
    .app-container {
      max-width: 1400px;
      margin: 0 auto;
      padding: 24px;
      position: relative;
      z-index: 1;
    }
    
    /* Header with glass morphism */
    .app-header {
      background: rgba(255, 255, 255, 0.08);
      backdrop-filter: blur(20px);
      border-radius: var(--border-radius);
      padding: 32px 40px;
      margin-bottom: 32px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      box-shadow: var(--shadow-lg);
      position: relative;
      overflow: hidden;
    }
    
    .app-header::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 1px;
      background: linear-gradient(90deg, transparent, var(--primary), transparent);
    }
    
    .app-brand {
      display: flex;
      align-items: center;
      gap: 20px;
    }
    
    .app-logo {
      width: 64px;
      height: 64px;
      background: var(--gradient-primary);
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: 800;
      font-size: 1.8rem;
      box-shadow: var(--shadow-md);
      position: relative;
      overflow: hidden;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .app-logo::after {
      content: '';
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
      transform: rotate(45deg);
      transition: all 0.6s ease;
    }
    
    .app-logo:hover {
      transform: rotate(5deg) scale(1.05);
      box-shadow: 0 12px 40px rgba(0, 102, 255, 0.3);
    }
    
    .app-logo:hover::after {
      transform: rotate(45deg) translate(50%, 50%);
    }
    
    .app-title {
      font-size: 3rem;
      font-weight: 800;
      background: linear-gradient(135deg, #ffffff 0%, var(--primary-light) 100%);
      background-clip: text;
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin: 0;
      letter-spacing: -0.5px;
    }
    
    .app-subtitle {
      color: var(--gray);
      font-size: 1.2rem;
      margin: 8px 0 0 0;
      font-weight: 400;
    }
    
    /* Main Layout */
    .dashboard-layout {
      display: grid;
      grid-template-columns: 1fr 380px;
      gap: 28px;
      align-items: start;
    }
    
    .main-content {
      display: flex;
      flex-direction: column;
      gap: 28px;
    }
    
    .sidebar {
      display: flex;
      flex-direction: column;
      gap: 28px;
    }
    
    /* Cards with glass morphism */
    .card {
      background: rgba(255, 255, 255, 0.08);
      backdrop-filter: blur(20px);
      border-radius: var(--border-radius);
      padding: 28px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      box-shadow: var(--shadow-md);
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      position: relative;
      overflow: hidden;
    }
    
    .card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 1px;
      background: linear-gradient(90deg, transparent, var(--primary), transparent);
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    
    .card:hover {
      transform: translateY(-4px);
      box-shadow: var(--shadow-lg);
      border-color: rgba(255, 255, 255, 0.15);
    }
    
    .card:hover::before {
      opacity: 1;
    }
    
    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
    }
    
    .card-title {
      font-size: 1.4rem;
      font-weight: 700;
      color: var(--light);
      margin: 0;
    }
    
    /* Summary Cards with animated gradients */
    .summary-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 20px;
      margin-bottom: 8px;
    }
    
    .summary-card {
      background: rgba(255, 255, 255, 0.1);
      padding: 28px 24px;
      border-radius: var(--border-radius-sm);
      border: 1px solid rgba(255, 255, 255, 0.1);
      position: relative;
      overflow: hidden;
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    
    .summary-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
      transition: left 0.6s ease;
    }
    
    .summary-card:hover::before {
      left: 100%;
    }
    
    .summary-card.income {
      background: linear-gradient(135deg, rgba(0, 200, 83, 0.15) 0%, rgba(0, 230, 118, 0.1) 100%);
      border-color: rgba(0, 200, 83, 0.3);
    }
    
    .summary-card.expense {
      background: linear-gradient(135deg, rgba(255, 68, 68, 0.15) 0%, rgba(255, 107, 107, 0.1) 100%);
      border-color: rgba(255, 68, 68, 0.3);
    }
    
    .summary-card.balance {
      background: linear-gradient(135deg, rgba(0, 102, 255, 0.15) 0%, rgba(51, 133, 255, 0.1) 100%);
      border-color: rgba(0, 102, 255, 0.3);
    }
    
    .summary-card:hover {
      transform: translateY(-6px) scale(1.02);
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.2);
    }
    
    .summary-icon {
      font-size: 2.5rem;
      margin-bottom: 16px;
      opacity: 0.9;
      transition: transform 0.3s ease;
    }
    
    .summary-card:hover .summary-icon {
      transform: scale(1.1) rotate(5deg);
    }
    
    .summary-label {
      font-size: 0.9rem;
      color: var(--gray);
      margin-bottom: 8px;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    
    .summary-amount {
      font-size: 2rem;
      font-weight: 800;
      color: var(--light);
      transition: all 0.3s ease;
    }
    
    .summary-card:hover .summary-amount {
      color: white;
      text-shadow: 0 0 20px rgba(255, 255, 255, 0.5);
    }
    
    /* Action Buttons with magnetic effect */
    .action-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
    }
    
    .action-btn {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 24px 16px;
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: var(--border-radius-sm);
      text-decoration: none;
      color: var(--light);
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      text-align: center;
      position: relative;
      overflow: hidden;
    }
    
    .action-btn::before {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      width: 0;
      height: 0;
      background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
      transition: all 0.4s ease;
      transform: translate(-50%, -50%);
    }
    
    .action-btn:hover::before {
      width: 300px;
      height: 300px;
    }
    
    .action-btn:hover {
      transform: translateY(-4px) scale(1.05);
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.2);
      border-color: var(--primary);
      color: white;
    }
    
    .action-icon {
      font-size: 2rem;
      margin-bottom: 12px;
      transition: all 0.3s ease;
    }
    
    .action-btn:hover .action-icon {
      transform: scale(1.2) rotate(10deg);
    }
    
    .action-label {
      font-size: 0.9rem;
      font-weight: 600;
      transition: all 0.3s ease;
    }
    
    .action-btn:hover .action-label {
      letter-spacing: 0.5px;
    }
    
    /* Filters with smooth animations */
    .filters-section {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
    }
    
    .filter-group {
      margin-bottom: 20px;
    }
    
    .filter-label {
      display: block;
      font-weight: 600;
      margin-bottom: 10px;
      color: var(--light);
      font-size: 0.95rem;
    }
    
    .filter-input {
      width: 100%;
      padding: 12px 16px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 12px;
      font-size: 0.95rem;
      background: rgba(30, 41, 59, 0.9);
      color: var(--light);
      transition: all 0.3s ease;
      font-family: 'Outfit', sans-serif;
      backdrop-filter: blur(10px);
      cursor: pointer;
    }

    /* Modern dropdown styling that works across browsers */
    .filter-input option {
      background: #1e293b;
      color: #e2e8f0;
      padding: 12px 16px;
      font-size: 0.95rem;
      border: none;
      margin: 2px 0;
    }

    .filter-input option:hover {
      background: var(--primary) !important;
      color: white !important;
    }

    .filter-input option:checked {
      background: var(--primary) !important;
      color: white !important;
    }

    .filter-input option:focus {
      background: var(--primary) !important;
      color: white !important;
    }

    .filter-input:focus {
      outline: none;
      border-color: var(--primary);
      background: rgba(30, 41, 59, 0.95);
      box-shadow: 0 0 0 3px rgba(0, 102, 255, 0.3);
    }

    /* For Webkit browsers (Chrome, Safari) */
    .filter-input::-webkit-scrollbar {
      width: 8px;
    }

    .filter-input::-webkit-scrollbar-track {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 4px;
    }

    .filter-input::-webkit-scrollbar-thumb {
      background: var(--primary);
      border-radius: 4px;
    }

    .filter-input::-webkit-scrollbar-thumb:hover {
      background: var(--primary-light);
    }
    
    .filter-input::placeholder {
      color: var(--gray);
    }
    
    .filter-actions {
      display: flex;
      gap: 10px;
      align-items: center;
      margin-top: 12px;
    }
    
    /* Buttons with gradient backgrounds */
    .btn {
      padding: 12px 20px;
      border: none;
      border-radius: 12px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
      font-size: 0.9rem;
      font-family: 'Outfit', sans-serif;
      position: relative;
      overflow: hidden;
    }
    
    .btn::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
      transition: left 0.5s ease;
    }
    
    .btn:hover::before {
      left: 100%;
    }
    
    .btn-sm {
      padding: 10px 16px;
      font-size: 0.85rem;
    }
    
    .btn-primary {
      background: var(--gradient-primary);
      color: white;
      box-shadow: 0 4px 16px rgba(0, 102, 255, 0.3);
    }
    
    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(0, 102, 255, 0.4);
    }
    
    .btn-secondary {
      background: rgba(255, 255, 255, 0.1);
      color: var(--light);
      border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .btn-secondary:hover {
      background: rgba(255, 255, 255, 0.15);
      transform: translateY(-2px);
    }
    
    /* Transaction List with smooth entries */
    .transaction-list {
      max-height: 400px;
      overflow-y: auto;
    }
    
    .transaction-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
      transition: all 0.3s ease;
      border-radius: 12px;
      margin-bottom: 4px;
    }
    
    .transaction-item:hover {
      background: rgba(255, 255, 255, 0.05);
      transform: translateX(8px);
      border-bottom-color: transparent;
    }
    
    .transaction-item:last-child {
      border-bottom: none;
      margin-bottom: 0;
    }
    
    .transaction-info {
      flex: 1;
    }
    
    .transaction-title {
      font-weight: 600;
      margin-bottom: 6px;
      color: var(--light);
    }
    
    .transaction-meta {
      font-size: 0.85rem;
      color: var(--gray);
    }
    
    .transaction-amount {
      font-weight: 700;
      font-size: 1.2rem;
      margin-bottom: 8px;
      color: var(--light);
    }
    
    .transaction-type {
      padding: 6px 12px;
      border-radius: 8px;
      font-size: 0.8rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    
    .type-income {
      background: rgba(0, 200, 83, 0.2);
      color: #00c853;
      border: 1px solid rgba(0, 200, 83, 0.3);
    }
    
    .type-expense {
      background: rgba(255, 68, 68, 0.2);
      color: #ff4444;
      border: 1px solid rgba(255, 68, 68, 0.3);
    }
    
    .transaction-actions {
      display: flex;
      gap: 8px;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    
    .transaction-item:hover .transaction-actions {
      opacity: 1;
    }
    
    /* Charts with glowing effects */
    .chart-container {
      background: rgba(255, 255, 255, 0.05);
      padding: 24px;
      border-radius: var(--border-radius-sm);
      border: 1px solid rgba(255, 255, 255, 0.1);
      position: relative;
    }
    
    .chart-wrapper {
      position: relative;
      height: 300px;
      width: 100%;
    }
    
    /* Budget Alerts with pulse animation */
    .alert-item {
      padding: 20px;
      border-radius: 12px;
      margin-bottom: 16px;
      border-left: 4px solid;
      background: rgba(255, 255, 255, 0.05);
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
    }
    
    .alert-item::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 4px;
      height: 100%;
      background: inherit;
      border-radius: 2px;
    }
    
    .alert-warning {
      border-left-color: var(--warning);
      background: rgba(255, 170, 0, 0.1);
    }
    
    .alert-danger {
      border-left-color: var(--danger);
      background: rgba(255, 68, 68, 0.1);
      animation: pulse 2s infinite;
    }
    
    .alert-safe {
      border-left-color: var(--success);
      background: rgba(0, 200, 83, 0.1);
    }
    
    .alert-item:hover {
      transform: translateX(4px);
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
    }
    
    @keyframes pulse {
      0%, 100% { box-shadow: 0 0 0 0 rgba(255, 68, 68, 0.4); }
      50% { box-shadow: 0 0 0 8px rgba(255, 68, 68, 0); }
    }
    
    /* Responsive Design */
    @media (max-width: 1200px) {
      .dashboard-layout {
        grid-template-columns: 1fr;
      }
      
      .summary-grid {
        grid-template-columns: repeat(2, 1fr);
      }
      
      .action-grid {
        grid-template-columns: repeat(2, 1fr);
      }
    }
    
    @media (max-width: 768px) {
      .app-container {
        padding: 16px;
      }
      
      .app-header {
        padding: 24px;
      }
      
      .app-title {
        font-size: 2.2rem;
      }
      
      .summary-grid {
        grid-template-columns: 1fr;
      }
      
      .action-grid {
        grid-template-columns: 1fr;
      }
      
      .filters-section {
        grid-template-columns: 1fr;
      }
    }
    
    /* Custom scrollbar */
    .transaction-list::-webkit-scrollbar {
      width: 6px;
    }
    
    .transaction-list::-webkit-scrollbar-track {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 3px;
    }
    
    .transaction-list::-webkit-scrollbar-thumb {
      background: var(--primary);
      border-radius: 3px;
    }
    
    .transaction-list::-webkit-scrollbar-thumb:hover {
      background: var(--primary-light);
    }
  </style>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
  <!-- Animated Background Elements -->
  <div class="bg-elements">
    <div class="bg-element"></div>
    <div class="bg-element"></div>
    <div class="bg-element"></div>
  </div>

  <div class="app-container">
    <!-- Header -->
    <header class="app-header">
      <div class="app-brand">
        <div class="app-logo">💎</div>
        <div>
          <h1 class="app-title">Scratchers</h1>
          <p class="app-subtitle">Financial intelligence reimagined</p>
        </div>
      </div>
    </header>

    <div class="dashboard-layout">
      <!-- Main Content -->
      <div class="main-content">
        <!-- Summary Cards -->
        <div class="summary-grid">
          <div class="summary-card income">
            <div class="summary-icon">💰</div>
            <div class="summary-label">Total Income</div>
            <div class="summary-amount">$<?=number_format($income,2)?></div>
          </div>
          <div class="summary-card expense">
            <div class="summary-icon">💸</div>
            <div class="summary-label">Total Expenses</div>
            <div class="summary-amount">$<?=number_format($expense,2)?></div>
          </div>
          <div class="summary-card balance">
            <div class="summary-icon">⚖️</div>
            <div class="summary-label">Current Balance</div>
            <div class="summary-amount">$<?=number_format($balance,2)?></div>
          </div>
        </div>

        <!-- Quick Actions -->
        <div class="card">
          <h3 class="card-title">Quick Actions</h3>
          <div class="action-grid">
            <a href="add_transaction.php" class="action-btn">
              <div class="action-icon">✨</div>
              <div class="action-label">Add Transaction</div>
            </a>
            <a href="manage_budgets.php" class="action-btn">
              <div class="action-icon">🎯</div>
              <div class="action-label">Manage Budgets</div>
            </a>
            <a href="../category_module/category_module - Copy/dashboard.php" class="action-btn">
              <div class="action-icon">📂</div>
              <div class="action-label">Manage Categories</div>
            </a>
            <a href="export_csv.php?<?= http_build_query($_GET) ?>" class="action-btn">
              <div class="action-icon">📊</div>
              <div class="action-label">Export Data</div>
            </a>
          </div>
        </div>

        <!-- Category Management System -->
        <div class="card">
          <h3 class="card-title">Category Management</h3>
          <div class="action-grid">
            <a href="../FinancialTrackerAPI/incomes.php" class="action-btn">
              <div class="action-icon">💰</div>
              <div class="action-label">Income Management</div>
            </a>
            <a href="../FinancialTrackerAPI/expenses.php" class="action-btn">
              <div class="action-icon">💸</div>
              <div class="action-label">Expense Management</div>
            </a>
            <a href="../category_module/category_module - Copy/dashboard.html" class="action-btn">
              <div class="action-icon">📊</div>
              <div class="action-label">Category Dashboard</div>
            </a>
            <a href="../category_module/category_module - Copy/list.php" class="action-btn">
              <div class="action-icon">📋</div>
              <div class="action-label">View Categories</div>
            </a>
            <a href="../category_module/category_module - Copy/add.php" class="action-btn">
              <div class="action-icon">➕</div>
              <div class="action-label">Add Category</div>
            </a>
            <a href="../sayeed/admin_dashboard.php" class="action-btn">
              <div class="action-icon">⚙️</div>
              <div class="action-label">Admin Portal</div>
            </a>
          </div>
        </div>

        <!-- Filters -->
        <div class="card">
          <h3 class="card-title">Filter & Search</h3>
          <div class="filters-section">
            <!-- Search -->
            <div class="filter-group">
              <label class="filter-label">Search Transactions</label>
              <form method="GET" action="">
                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" 
                       placeholder="What are you looking for?" class="filter-input">
                <div class="filter-actions">
                  <button type="submit" class="btn btn-primary btn-sm">Search</button>
                  <?php if (!empty($search)): ?>
                    <a href="?" class="btn btn-secondary btn-sm">Clear All</a>
                  <?php endif; ?>
                </div>
              </form>
            </div>

            <!-- Category -->
            <div class="filter-group">
              <label class="filter-label">Filter by Category</label>
              <form method="GET" action="">
                <input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
                <input type="hidden" name="start_date" value="<?= htmlspecialchars($start_date) ?>">
                <input type="hidden" name="end_date" value="<?= htmlspecialchars($end_date) ?>">
                
                <select name="category" onchange="this.form.submit()" class="filter-input">
                  <option value="">All Categories</option>
                  <?php
                  $categoryStmt = $pdo->query("SELECT DISTINCT category FROM transactions WHERE category IS NOT NULL AND category != '' ORDER BY category");
                  $categories = $categoryStmt->fetchAll();
                  
                  $selectedCategory = $_GET['category'] ?? '';
                  foreach ($categories as $cat) {
                    $isSelected = ($selectedCategory === $cat['category']) ? 'selected' : '';
                    echo "<option value=\"" . htmlspecialchars($cat['category']) . "\" $isSelected>" . htmlspecialchars($cat['category']) . "</option>";
                  }
                  ?>
                </select>
              </form>
            </div>

            <!-- Date Range -->
            <div class="filter-group">
              <label class="filter-label">Date Range</label>
              <form method="GET" action="">
                <input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
                <input type="hidden" name="category" value="<?= htmlspecialchars($category) ?>">
                
                <div style="display: flex; gap: 10px; margin-bottom: 12px;">
                  <input type="date" name="start_date" value="<?= htmlspecialchars($start_date) ?>" class="filter-input">
                  <input type="date" name="end_date" value="<?= htmlspecialchars($end_date) ?>" class="filter-input">
                </div>
                <div class="filter-actions">
                  <button type="submit" class="btn btn-primary btn-sm">Apply Dates</button>
                  <a href="?<?= http_build_query(['search' => $search, 'category' => $category]) ?>" class="btn btn-secondary btn-sm">Clear Dates</a>
                </div>
              </form>
            </div>
          </div>
        </div>

        <!-- Recent Transactions -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Recent Transactions</h3>
          </div>
          <div class="transaction-list">
            <?php if (count($transactions)===0): ?>
              <div style="text-align: center; padding: 60px 20px; color: var(--gray);">
                <div style="font-size: 3rem; margin-bottom: 16px;">📊</div>
                <p style="font-size: 1.1rem; margin-bottom: 8px;">No transactions found</p>
                <?php if (!empty($search) || !empty($start_date) || !empty($end_date) || !empty($category)): ?>
                  <p style="font-size: 0.95rem;">Try adjusting your filters</p>
                <?php else: ?>
                  <a href="add_transaction.php" class="btn btn-primary" style="margin-top: 16px;">Add Your First Transaction</a>
                <?php endif; ?>
              </div>
            <?php else: ?>
              <?php foreach($transactions as $tx): ?>
                <div class="transaction-item">
                  <div class="transaction-info">
                    <div class="transaction-title"><?=htmlspecialchars($tx['description'])?></div>
                    <div class="transaction-meta"><?=htmlspecialchars($tx['category'] ?? '')?> • <?=htmlspecialchars($tx['date'] ?? '')?></div>
                  </div>
                  <div style="text-align: right;">
                    <div class="transaction-amount">$<?=number_format((float)$tx['amount'],2)?></div>
                    <div class="transaction-type <?= $tx['type']==='Income' ? 'type-income' : 'type-expense' ?>">
                      <?=htmlspecialchars($tx['type'])?>
                    </div>
                  </div>
                  <div class="transaction-actions">
                    <a href="edit_transaction.php?id=<?= $tx['id'] ?>" class="btn btn-primary btn-sm">Edit</a>
                    <a href="delete_transaction.php?id=<?= $tx['id'] ?>" 
                       onclick="return confirm('Delete this transaction?')"
                       class="btn btn-secondary btn-sm">Delete</a>
                  </div>
                </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>

        <!-- Monthly Overview Chart -->
        <div class="card">
          <h3 class="card-title">Monthly Financial Overview</h3>
          <div class="chart-wrapper">
            <canvas id="monthlyChart"></canvas>
          </div>
        </div>
      </div>

      <!-- Sidebar -->
      <div class="sidebar">
        <!-- Budget Alerts -->
        <div class="card">
          <h3 class="card-title">Budget Alerts</h3>
          <?php
          $budgetAlertsStmt = $pdo->query("
              SELECT b.category, b.monthly_budget, 
                     COALESCE(SUM(t.amount), 0) as spent,
                     (COALESCE(SUM(t.amount), 0) / b.monthly_budget * 100) as percentage
              FROM budgets b
              LEFT JOIN transactions t ON b.category = t.category 
                  AND t.type = 'Expense' 
                  AND t.user_id = 1
                  AND MONTH(t.date) = MONTH(CURRENT_DATE()) 
                  AND YEAR(t.date) = YEAR(CURRENT_DATE())
              WHERE b.user_id = 1
              GROUP BY b.category, b.monthly_budget
              HAVING percentage >= 70
              ORDER BY percentage DESC
          ");
          $budgetAlerts = $budgetAlertsStmt->fetchAll();
          
          if (empty($budgetAlerts)): ?>
            <div class="alert-item alert-safe">
              <strong>✅ All Good!</strong><br>
              All budgets are within safe limits
            </div>
          <?php else: ?>
            <?php foreach ($budgetAlerts as $alert): 
              $alertClass = $alert['percentage'] < 90 ? 'alert-warning' : 'alert-danger';
            ?>
              <div class="alert-item <?= $alertClass ?>">
                <strong><?= htmlspecialchars($alert['category']) ?></strong><br>
                $<?= number_format($alert['spent'], 2) ?> of $<?= number_format($alert['monthly_budget'], 2) ?> 
                (<?= number_format($alert['percentage'], 1) ?>% used)
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
          <div style="margin-top: 20px;">
            <a href="manage_budgets.php" class="btn btn-primary" style="width: 100%; text-align: center; justify-content: center;">
              🎯 Manage Budgets
            </a>
          </div>
        </div>

        <!-- Quick Charts -->
        <div class="card">
          <h3 class="card-title">Income vs Expenses</h3>
          <div class="chart-wrapper">
            <canvas id="pieChart"></canvas>
          </div>
        </div>

        <div class="card">
          <h3 class="card-title">Recent Spending</h3>
          <div class="chart-wrapper">
            <canvas id="barChart"></canvas>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Pie Chart - Income vs Expenses
    const pieData = {
      labels: ['Income','Expense'],
      datasets: [{
        data: [<?=json_encode($income)?>, <?=json_encode($expense)?>],
        backgroundColor: ['#00c853','#ff4444'],
        borderWidth: 3,
        borderColor: 'rgba(255, 255, 255, 0.1)',
        hoverBorderWidth: 4,
        hoverBorderColor: 'rgba(255, 255, 255, 0.3)'
      }]
    };
    
    new Chart(document.getElementById('pieChart'), { 
      type: 'doughnut', 
      data: pieData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '65%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              color: '#e2e8f0',
              font: {
                family: 'Outfit',
                size: 12
              }
            }
          }
        },
        animation: {
          animateScale: true,
          animateRotate: true
        }
      }
    });

    // Bar Chart - Recent Transactions
    const txLabels = <?= json_encode(array_map(fn($t)=>$t['description'], $transactions)) ?>;
    const txAmounts = <?= json_encode(array_map(fn($t)=>(float)$t['amount'], $transactions)) ?>;
    new Chart(document.getElementById('barChart'), {
      type: 'bar',
      data: { 
        labels: txLabels, 
        datasets: [{ 
          label: 'Amount', 
          data: txAmounts,
          backgroundColor: '#0066ff',
          borderRadius: 8,
          borderSkipped: false,
        }] 
      },
      options: { 
        responsive: true,
        maintainAspectRatio: false,
        scales:{ 
          y:{ 
            beginAtZero:true,
            grid: {
              color: 'rgba(255, 255, 255, 0.1)'
            },
            ticks: {
              color: '#8c94a8'
            }
          },
          x: {
            grid: {
              display: false
            },
            ticks: {
              color: '#8c94a8',
              maxRotation: 45,
              minRotation: 45
            }
          }
        },
        plugins: {
          legend: {
            display: false
          }
        }
      } 
    });

    // Monthly Chart
    const monthlyLabels = <?= json_encode($monthlyLabels) ?>;
    const monthlyIncome = <?= json_encode($monthlyIncome) ?>;
    const monthlyExpense = <?= json_encode($monthlyExpense) ?>;
    new Chart(document.getElementById('monthlyChart'), {
      type: 'bar',
      data: {
        labels: monthlyLabels,
        datasets: [
          { 
            label: 'Income', 
            data: monthlyIncome,
            backgroundColor: '#00c853',
            borderRadius: 8,
            borderSkipped: false,
          },
          { 
            label: 'Expense', 
            data: monthlyExpense,
            backgroundColor: '#ff4444',
            borderRadius: 8,
            borderSkipped: false,
          }
        ]
      },
      options: { 
        responsive: true,
        maintainAspectRatio: false,
        scales:{ 
          y:{ 
            beginAtZero:true,
            grid: {
              color: 'rgba(255, 255, 255, 0.1)'
            },
            ticks: {
              color: '#8c94a8'
            }
          },
          x: {
            grid: {
              display: false
            },
            ticks: {
              color: '#8c94a8'
            }
          }
        },
        plugins: {
          legend: {
            labels: {
              color: '#e2e8f0',
              font: {
                family: 'Outfit'
              }
            }
          }
        }
      } 
    });


    
  </script>
</body>
</html>