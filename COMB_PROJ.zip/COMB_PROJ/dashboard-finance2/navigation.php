<?php
// dashboard-finance2/navigation.php
?>
<nav style="background: #1a1d29; padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.1);">
    <div style="display: flex; gap: 15px; align-items: center; flex-wrap: wrap;">
        <!-- Zeeshan's Dashboard Links -->
        <a href="index.php" style="color: white; text-decoration: none; font-weight: 600; padding: 10px 20px; border-radius: 8px; background: rgba(0,102,255,0.3); border: 1px solid rgba(0,102,255,0.5);">
            📊 Dashboard
        </a>
        <a href="add_transaction.php" style="color: white; text-decoration: none; font-weight: 500; padding: 8px 16px; border-radius: 6px; background: rgba(255,255,255,0.1);">
            ➕ Add Transaction
        </a>
        <a href="manage_budgets.php" style="color: white; text-decoration: none; font-weight: 500; padding: 8px 16px; border-radius: 6px; background: rgba(255,255,255,0.1);">
            🎯 Manage Budgets
        </a>
        
        <!-- Your Finance System Links -->
        <a href="../FinancialTrackerAPI/incomes.php" style="color: white; text-decoration: none; font-weight: 600; padding: 10px 20px; border-radius: 8px; background: rgba(0,200,83,0.3); border: 1px solid rgba(0,200,83,0.5);">
            💰 My Income
        </a>
        <a href="../FinancialTrackerAPI/expenses.php" style="color: white; text-decoration: none; font-weight: 600; padding: 10px 20px; border-radius: 8px; background: rgba(255,68,68,0.3); border: 1px solid rgba(255,68,68,0.5);">
            💸 My Expenses
        </a>
    </div>
</nav>