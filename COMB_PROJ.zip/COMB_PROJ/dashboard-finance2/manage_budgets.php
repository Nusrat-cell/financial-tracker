<?php
// manage_budgets.php
require_once __DIR__ . '/api/db.php';

$message = '';
$message_type = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_budget'])) {
        $category = $_POST['category'] ?? '';
        $monthly_budget = $_POST['monthly_budget'] ?? '';
        
        if (!empty($category) && is_numeric($monthly_budget) && $monthly_budget > 0) {
            try {
                $stmt = $pdo->prepare("INSERT INTO budgets (user_id, category, monthly_budget) VALUES (1, ?, ?)");
                $stmt->execute([$category, $monthly_budget]);
                $message = 'Budget added successfully!';
                $message_type = 'success';
            } catch (Exception $e) {
                $message = 'Error adding budget: ' . $e->getMessage();
                $message_type = 'error';
            }
        }
    }
    
    if (isset($_POST['update_budget'])) {
        $budget_id = $_POST['budget_id'] ?? '';
        $monthly_budget = $_POST['monthly_budget'] ?? '';
        
        if (!empty($budget_id) && is_numeric($monthly_budget) && $monthly_budget > 0) {
            try {
                $stmt = $pdo->prepare("UPDATE budgets SET monthly_budget = ? WHERE id = ?");
                $stmt->execute([$monthly_budget, $budget_id]);
                $message = 'Budget updated successfully!';
                $message_type = 'success';
            } catch (Exception $e) {
                $message = 'Error updating budget: ' . $e->getMessage();
                $message_type = 'error';
            }
        }
    }
    
    if (isset($_POST['delete_budget'])) {
        $budget_id = $_POST['budget_id'] ?? '';
        
        if (!empty($budget_id)) {
            try {
                $stmt = $pdo->prepare("DELETE FROM budgets WHERE id = ?");
                $stmt->execute([$budget_id]);
                $message = 'Budget deleted successfully!';
                $message_type = 'success';
            } catch (Exception $e) {
                $message = 'Error deleting budget: ' . $e->getMessage();
                $message_type = 'error';
            }
        }
    }
}

// Get current budgets
$budgetsStmt = $pdo->query("SELECT * FROM budgets WHERE user_id = 1 ORDER BY category");
$budgets = $budgetsStmt->fetchAll();

// Get current month spending by category
$spendingStmt = $pdo->query("
    SELECT category, SUM(amount) as total_spent 
    FROM transactions 
    WHERE type = 'Expense' 
    AND user_id = 1 
    AND MONTH(date) = MONTH(CURRENT_DATE()) 
    AND YEAR(date) = YEAR(CURRENT_DATE())
    GROUP BY category
");
$spending = $spendingStmt->fetchAll();

// Create spending map for easy access
$spendingMap = [];
foreach ($spending as $spend) {
    $spendingMap[$spend['category']] = $spend['total_spent'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Manage Budgets - Financial Dashboard</title>
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/modern-css-reset/dist/reset.min.css">
    <style>
        body { font-family: Arial, sans-serif; background:#f4f6f8; padding:20px; }
        .container { max-width: 800px; margin: 0 auto; }
        .card { background: white; padding: 25px; border-radius: 10px; box-shadow: 0 6px 18px rgba(0,0,0,0.06); margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; color: #333; }
        input, select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; }
        .btn { padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; text-decoration: none; display: inline-block; }
        .btn-primary { background: #0072ff; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-secondary { background: #6c757d; color: white; margin-right: 10px; }
        .message { padding: 15px; margin-bottom: 20px; border-radius: 5px; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .budget-item { border: 1px solid #eee; padding: 15px; margin-bottom: 10px; border-radius: 5px; }
        .progress-bar { background: #e9ecef; border-radius: 10px; height: 20px; margin: 10px 0; overflow: hidden; }
        .progress-fill { height: 100%; border-radius: 10px; transition: width 0.3s ease; }
        .safe { background: #28a745; }
        .warning { background: #ffc107; }
        .danger { background: #dc3545; }
        .budget-stats { display: flex; justify-content: space-between; font-size: 14px; color: #666; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Manage Budgets</h1>
        
        <?php if ($message): ?>
            <div class="message <?= $message_type ?>"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <div class="card">
            <h2>Add New Budget</h2>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="category">Category</label>
                    <select id="category" name="category" required>
                        <option value="">Select Category</option>
                        <?php
                        $categoryStmt = $pdo->query("SELECT DISTINCT category FROM transactions WHERE category IS NOT NULL AND category != '' AND type = 'Expense' ORDER BY category");
                        $categories = $categoryStmt->fetchAll();
                        foreach ($categories as $cat) {
                            echo "<option value=\"" . htmlspecialchars($cat['category']) . "\">" . htmlspecialchars($cat['category']) . "</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="monthly_budget">Monthly Budget ($)</label>
                    <input type="number" id="monthly_budget" name="monthly_budget" step="0.01" min="0.01" required>
                </div>
                <button type="submit" name="add_budget" class="btn btn-primary">Add Budget</button>
                <a href="index.php" class="btn btn-secondary">Back to Dashboard</a>
            </form>
        </div>

        <div class="card">
            <h2>Current Budgets</h2>
            <?php if (empty($budgets)): ?>
                <p>No budgets set yet. Add your first budget above!</p>
            <?php else: ?>
                <?php foreach ($budgets as $budget): 
                    $spent = $spendingMap[$budget['category']] ?? 0;
                    $percentage = $budget['monthly_budget'] > 0 ? min(100, ($spent / $budget['monthly_budget']) * 100) : 0;
                    $progressClass = $percentage < 70 ? 'safe' : ($percentage < 90 ? 'warning' : 'danger');
                ?>
                    <div class="budget-item">
                        <h3><?= htmlspecialchars($budget['category']) ?></h3>
                        <div class="budget-stats">
                            <span>Spent: $<?= number_format($spent, 2) ?></span>
                            <span>Budget: $<?= number_format($budget['monthly_budget'], 2) ?></span>
                            <span>Remaining: $<?= number_format($budget['monthly_budget'] - $spent, 2) ?></span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill <?= $progressClass ?>" style="width: <?= $percentage ?>%"></div>
                        </div>
                        <form method="POST" action="" style="display: inline-block;">
                            <input type="hidden" name="budget_id" value="<?= $budget['id'] ?>">
                            <input type="number" name="monthly_budget" value="<?= $budget['monthly_budget'] ?>" step="0.01" min="0.01" style="width: 120px; display: inline-block;">
                            <button type="submit" name="update_budget" class="btn btn-primary">Update</button>
                        </form>
                        <form method="POST" action="" style="display: inline-block; margin-left: 10px;">
                            <input type="hidden" name="budget_id" value="<?= $budget['id'] ?>">
                            <button type="submit" name="delete_budget" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this budget?')">Delete</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>