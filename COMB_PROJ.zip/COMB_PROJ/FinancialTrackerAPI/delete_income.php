<?php
// Start session to access user login information
session_start();

// Check if user is logged in - if not, redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(); // Stop execution immediately after redirect
}
// ... rest of your existing delete code
?>

<?php
// Database connection settings
$host = 'localhost'; // Database server location
$dbname = 'financialtracker'; // Your financial database name
$username = 'root'; // Database username
$password = ''; // Database password

try {
    // Create connection to MySQL database using PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set error mode to exceptions for better error handling
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    // If connection fails, show error and stop script
    die("❌ Connection failed: " . $e->getMessage());
}

// Delete income record when ID is provided in URL
if(isset($_GET['id'])) {
    // Prepare DELETE statement to prevent SQL injection
    $stmt = $pdo->prepare("DELETE FROM incomes WHERE IncomeID = ?");
    
    // Execute the statement with the income ID from URL
    if($stmt->execute([$_GET['id']])) {
        // If successful, redirect back to incomes page with success message
        header("Location: incomes.php?message=deleted");
        exit(); // Stop execution after redirect
    } else {
        // If deletion fails, show error message
        die("❌ Error deleting income!");
    }
} else {
    // If no ID provided, redirect back to incomes page
    header("Location: incomes.php");
    exit();
}
?>