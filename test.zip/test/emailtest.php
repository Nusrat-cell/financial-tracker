<?php

require_once __DIR__ . '/../classes/user.php';

use PHPUnit\Framework\TestCase;

/**
 * Email Validation Tests
 * Testing email field from users table
 * Started: 3rd Dec 2024
 * TODO: maybe add more edge cases later?
 */
class EmailTest extends TestCase {
    
    private $user;
    
    // setup function runs before each test
    protected function setUp(): void {
        $this->user = new User();
    }
    
    /**
     * TEST 1 - Empty Email Test
     * checking if empty email gets rejected
     */
    public function test_empty_email() {
        $testValue = "";
        
        $error = $this->user->validate("email", $testValue);
        
        $this->assertNotEmpty($error, "Empty email should fail");
        $this->assertEquals("Email is required", $error);
        
        echo "\n✓ TEST 1 PASSED: Empty email rejected\n";
    }
    
    /**
     * TEST 2 - Invalid email format
     * no @ symbol so should fail
     */
    public function test_invalid_email_format() {
        $testValue = "notanemail";
        
        $error = $this->user->validate("email", $testValue);
        
        $this->assertNotEmpty($error, "Invalid format should fail");
        $this->assertEquals("Invalid email format", $error);
        
        echo "✓ TEST 2 PASSED: Invalid format rejected\n";
    }
    
    /**
     * TEST 3 - Valid email test
     * standard email should work
     */
    public function test_valid_email() {
        $testValue = "user@example.com";
        
        $error = $this->user->validate("email", $testValue);
        
        $this->assertEmpty($error, "Valid email should pass");
        
        echo "✓ TEST 3 PASSED: Valid email accepted\n";
    }
    
    /**
     * TEST 4 - Minimum valid email
     * smallest possible valid email
     */
    public function test_min_valid_email() {
        $testValue = "a@b.c";
        
        $error = $this->user->validate("email", $testValue);
        
        $this->assertEmpty($error, "Minimum valid email should pass");
        
        echo "✓ TEST 4 PASSED: Minimum boundary email accepted\n";
    }
    
    /**
     * TEST 5 - Maximum length test (255 chars)
     * need to test the varchar(255) limit
     */
    public function test_max_length_email() {
        // creating email with exactly 255 characters
        // 243 a's + @example.com = 255 total
        $localPart = str_repeat("a", 243);
        $testValue = $localPart . "@example.com";
        
        // make sure it's actually 255 chars
        $this->assertEquals(255, strlen($testValue), "Test email should be exactly 255 characters");
        
        $error = $this->user->validate("email", $testValue);
        
        $this->assertEmpty($error, "Email at max length (255 chars) should pass");
        
        echo "✓ TEST 5 PASSED: Maximum boundary (255 chars) email accepted\n";
    }
    
    /**
     * TEST 6 - Over maximum test (256 chars)
     * should reject emails over 255 chars
     */
    public function test_over_max_length_email() {
        // 244 a's + @example.com = 256 chars (over limit)
        $localPart = str_repeat("a", 244);
        $testValue = $localPart . "@example.com";
        
        $this->assertEquals(256, strlen($testValue), "Test email should be exactly 256 characters");
        
        $error = $this->user->validate("email", $testValue);
        
        $this->assertNotEmpty($error, "Email over max length (256 chars) should fail");
        $this->assertEquals("Email exceeds maximum length", $error);
        
        echo "✓ TEST 6 PASSED: Over maximum (256 chars) email rejected\n";
    }
    
    // TEST 7 - no domain test
    public function test_email_no_domain() {
        $testValue = "user@";
        
        $error = $this->user->validate("email", $testValue);
        
        $this->assertNotEmpty($error, "Email without domain should fail");
        $this->assertEquals("Invalid email format", $error);
        
        echo "✓ TEST 7 PASSED: Email without domain rejected\n";
    }
    
    // TEST 8 - spaces in email (should fail)
    public function test_email_with_spaces() {
        $testValue = "user @example.com";  // space before @
        
        $error = $this->user->validate("email", $testValue);
        
        $this->assertNotEmpty($error, "Email with spaces should fail");
        $this->assertEquals("Invalid email format", $error);
        
        echo "✓ TEST 8 PASSED: Email with spaces rejected\n";
    }
    
    // TEST 9 - special characters that ARE valid
    public function test_email_with_valid_special_chars() {
        $testValue = "user.name+tag@example.com"; // dots and plus signs are ok
        
        $error = $this->user->validate("email", $testValue);
        
        $this->assertEmpty($error, "Email with valid special characters should pass");
        
        echo "✓ TEST 9 PASSED: Email with valid special characters accepted\n";
    }
    
    // TEST 10 - multiple @ symbols
    public function test_email_multiple_at_symbols() {
        $testValue = "user@@example.com";
        
        $error = $this->user->validate("email", $testValue);
        
        $this->assertNotEmpty($error, "Email with multiple @ symbols should fail");
        $this->assertEquals("Invalid email format", $error);
        
        echo "✓ TEST 10 PASSED: Email with multiple @ rejected\n";
    }
}