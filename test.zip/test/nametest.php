<?php

require_once __DIR__ . '/../classes/user.php';

use PHPUnit\Framework\TestCase;

// Name field tests - checking varchar(100) with min 2 chars
// this one was bit tricky to figure out at first
class NameTest extends TestCase {
    
    private $user;
    
    protected function setUp(): void {
        $this->user = new User();
    }
    
    // Test 1: empty name
    public function test_empty_name() {
        $testValue = "";
        $error = $this->user->validate("name", $testValue);
        
        $this->assertNotEmpty($error);
        $this->assertEquals("Name is required", $error);
        
        echo "\n✓ TEST 1 PASSED: Empty name rejected\n";
    }
    
    /* Test 2: just one character - should fail because min is 2 */
    public function test_single_character_name() {
        $testValue = "A";
        $error = $this->user->validate("name", $testValue);
        
        $this->assertNotEmpty($error);
        $this->assertEquals("Name must be at least 2 characters", $error);
        
        echo "✓ TEST 2 PASSED: Single character name rejected\n";
    }
    
    // Test 3: exactly 2 chars (boundary)
    public function test_min_boundary_name() {
        $testValue = "Jo";
        $error = $this->user->validate("name", $testValue);
        
        $this->assertEmpty($error);
        
        echo "✓ TEST 3 PASSED: Minimum boundary (2 chars) accepted\n";
    }
    
    // Test 4: 3 characters (just above min)
    public function test_min_plus_one_name() {
        $testValue = "Joe";
        $error = $this->user->validate("name", $testValue);
        
        $this->assertEmpty($error);
        echo "✓ TEST 4 PASSED: Min+1 (3 chars) accepted\n";
    }
    
    // test 5: normal name
    public function test_mid_range_name() {
        $testValue = "John Smith";
        $error = $this->user->validate("name", $testValue);
        
        $this->assertEmpty($error);
        echo "✓ TEST 5 PASSED: Mid-range name accepted\n";
    }
    
    /**
     * Test 6 - testing 99 chars (one below max)
     */
    public function test_max_minus_one_name() {
        $testValue = str_repeat("A", 99);  // creates string with 99 A's
        
        $this->assertEquals(99, strlen($testValue));
        $error = $this->user->validate("name", $testValue);
        
        $this->assertEmpty($error);
        echo "✓ TEST 6 PASSED: Max-1 (99 chars) accepted\n";
    }
    
    /**
     * Test 7 - max boundary test (100 chars exactly)
     * this is the varchar(100) limit
     */
    public function test_max_boundary_name() {
        $testValue = str_repeat("A", 100);
        
        $this->assertEquals(100, strlen($testValue));
        $error = $this->user->validate("name", $testValue);
        
        $this->assertEmpty($error);
        echo "✓ TEST 7 PASSED: Maximum boundary (100 chars) accepted\n";
    }
    
    // Test 8: 101 chars - over the limit
    public function test_max_plus_one_name() {
        $testValue = str_repeat("A", 101);
        
        $this->assertEquals(101, strlen($testValue));
        $error = $this->user->validate("name", $testValue);
        
        $this->assertNotEmpty($error);
        $this->assertEquals("Name exceeds maximum length", $error);
        echo "✓ TEST 8 PASSED: Max+1 (101 chars) rejected\n";
    }
    
    // Test 9: way over the limit
    public function test_extreme_max_name() {
        $testValue = str_repeat("A", 200);  // 200 characters
        
        $this->assertEquals(200, strlen($testValue));
        $error = $this->user->validate("name", $testValue);
        
        $this->assertNotEmpty($error);
        $this->assertEquals("Name exceeds maximum length", $error);
        echo "✓ TEST 9 PASSED: Extreme max (200 chars) rejected\n";
    }
    
    // Test 10: name with numbers - should be fine
    public function test_name_with_numbers() {
        $testValue = "John Smith 3rd";  // numbers are allowed in names
        $error = $this->user->validate("name", $testValue);
        
        $this->assertEmpty($error);
        echo "✓ TEST 10 PASSED: Name with numbers accepted\n";
    }
}