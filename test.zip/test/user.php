<?php

/**
 * User Class - handles validation for user fields
 * Database: login_system
 * Table: users
 * 
 * Created for CTEC2713 Portfolio 2
 * Last updated: Dec 2024
 */
class User {
    
    /**
     * Main validate function
     * Takes field name and value, returns error message or empty string
     */
    public function validate($field, $value) {
        
        switch($field) {
            case 'email':
                return $this->validateEmail($value);
                
            case 'name':
                return $this->validateName($value);
                
            case 'phone':
                return $this->validatePhone($value);
                
            case 'password':
                return $this->validatePassword($value);
                
            case 'verification_code':
                return $this->validateVerificationCode($value);
                
            default:
                return "Unknown field";
        }
    }
    
    /**
     * Email validation
     * varchar(255), required
     * 
     * NOTE: Had issues with filter_var rejecting 255 char emails
     * Solution: check length BEFORE format validation
     */
    private function validateEmail($email) {
        // first check if empty
        if (empty($email)) {
            return "Email is required";
        }
        
        // IMPORTANT: check length before format
        // filter_var has 254 char limit (RFC 5321) but our DB allows 255
        if (strlen($email) > 255) {
            return "Email exceeds maximum length";
        }
        
        // basic format check with regex (allows up to 255 chars)
        $pattern = '/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/';
        if (!preg_match($pattern, $email)) {
            return "Invalid email format";
        }
        
        // additional strict validation for normal length emails
        if (strlen($email) <= 254) {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return "Invalid email format";
            }
        }
        
        return "";  // all good
    }
    
    /**
     * Name validation
     * varchar(100), min 2 chars, required
     */
    private function validateName($name) {
        if (empty($name)) {
            return "Name is required";
        }
        
        if (strlen($name) < 2) {
            return "Name must be at least 2 characters";
        }
        
        if (strlen($name) > 100) {
            return "Name exceeds maximum length";
        }
        
        return "";
    }
    
    /**
     * Phone validation
     * varchar(15), 10-15 digits, required
     * Strips non-numeric characters before checking
     */
    private function validatePhone($phone) {
        if (empty($phone)) {
            return "Phone is required";
        }
        
        // remove everything except digits
        // this allows formats like +44 (123) 456-7890
        $cleanPhone = preg_replace('/[^0-9]/', '', $phone);
        
        if (strlen($cleanPhone) < 10) {
            return "Phone must be at least 10 digits";
        }
        
        if (strlen($cleanPhone) > 15) {
            return "Phone exceeds maximum length";
        }
        
        return "";
    }
    
    /**
     * Password validation
     * varchar(255), min 8 chars, required
     * Must have: uppercase, lowercase, number
     */
    private function validatePassword($password) {
        if (empty($password)) {
            return "Password is required";
        }
        
        if (strlen($password) < 8) {
            return "Password must be at least 8 characters";
        }
        
        if (strlen($password) > 255) {
            return "Password exceeds maximum length";
        }
        
        // check for uppercase letter
        if (!preg_match('/[A-Z]/', $password)) {
            return "Password must contain at least one uppercase letter";
        }
        
        // check for lowercase letter
        if (!preg_match('/[a-z]/', $password)) {
            return "Password must contain at least one lowercase letter";
        }
        
        // check for number
        if (!preg_match('/[0-9]/', $password)) {
            return "Password must contain at least one number";
        }
        
        return "";
    }
    
    /**
     * Verification code validation
     * varchar(6), exactly 6 digits, numeric only, required
     */
    private function validateVerificationCode($code) {
        if (empty($code)) {
            return "Verification code is required";
        }
        
        // must be exactly 6 characters
        if (strlen($code) < 6) {
            return "Verification code must be 6 digits";
        }
        
        if (strlen($code) > 6) {
            return "Verification code must be 6 digits";
        }
        
        // must be numeric only (no letters or special chars)
        if (!ctype_digit($code)) {
            return "Verification code must contain only numbers";
        }
        
        return "";
    }
}