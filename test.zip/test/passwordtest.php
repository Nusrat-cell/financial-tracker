<?php

require_once __DIR__ . '/../classes/user.php';

use PHPUnit\Framework\TestCase;

/**
 * Password validation testing
 * Requirements: min 8 chars, uppercase, lowercase, number
 * varchar(255) in database
 * 
 * NOTE: complexity rules are important for security!!
 */
class PasswordTest extends TestCase {
    
    private $user;
    
    protected function setUp(): void {
        $this->user = new User();
    }
    
    // test 1 - empty password
    public function test_empty_password() {
        $testValue = "";
        $error = $this->user->validate("password", $testValue);
        
        $this->assertNotEmpty($error, "Empty password should fail");
        $this->assertEquals("Password is required", $error);
        
        echo "\n✓ TEST 1 PASSED: Empty password rejected\n";
    }
    
    /**
     * Test 2: 7 characters (below min)
     */
    public function test_seven_char_password() {
        $testValue = "Pass123";  // only 7 chars
        $error = $this->user->validate("password", $testValue);
        
        $this->assertNotEmpty($error);
        $this->assertEquals("Password must be at least 8 characters", $error);
        
        echo "✓ TEST 2 PASSED: 7 characters rejected\n";
    }
    
    // TEST 3 - exactly 8 chars (min boundary)
    // needs to have upper, lower, and number
    public function test_min_boundary_password() {
        $testValue = "Pass1234";  // 8 chars: P(upper), ass(lower), 1234(numbers)
        $error = $this->user->validate("password", $testValue);
        
        $this->assertEmpty($error, "8-character valid password should pass");
        echo "✓ TEST 3 PASSED: Minimum boundary (8 chars) accepted\n";
    }
    
    // test 4: 9 characters
    public function test_min_plus_one_password() {
        $testValue = "Pass12345";
        $error = $this->user->validate("password", $testValue);
        
        $this->assertEmpty($error);
        echo "✓ TEST 4 PASSED: Min+1 (9 chars) accepted\n";
    }
    
    // test 5: mid range password
    public function test_mid_range_password() {
        $testValue = "SecurePass123456";  // 16 chars
        $error = $this->user->validate("password", $testValue);
        
        $this->assertEmpty($error);
        echo "✓ TEST 5 PASSED: Mid-range (16 chars) accepted\n";
    }
    
    /* TEST 6: 254 chars (one below max) */
    public function test_max_minus_one_password() {
        // make a 254 char password with Aa1 + bunch of x's
        $testValue = "Aa1" . str_repeat("x", 251);
        
        $this->assertEquals(254, strlen($testValue));
        $error = $this->user->validate("password", $testValue);
        
        $this->assertEmpty($error);
        echo "✓ TEST 6 PASSED: Max-1 (254 chars) accepted\n";
    }
    
    /**
     * TEST 7: Maximum boundary test (255 chars)
     * varchar(255) limit
     */
    public function test_max_boundary_password() {
        $testValue = "Aa1" . str_repeat("x", 252);  // 255 total
        
        $this->assertEquals(255, strlen($testValue));
        $error = $this->user->validate("password", $testValue);
        
        $this->assertEmpty($error, "255-character password should pass");
        echo "✓ TEST 7 PASSED: Maximum boundary (255 chars) accepted\n";
    }
    
    // TEST 8 - over max (256 chars)
    public function test_max_plus_one_password() {
        $testValue = "Aa1" . str_repeat("x", 253);  // 256 chars total
        
        $this->assertEquals(256, strlen($testValue));
        $error = $this->user->validate("password", $testValue);
        
        $this->assertNotEmpty($error, "256-character password should fail");
        $this->assertEquals("Password exceeds maximum length", $error);
        echo "✓ TEST 8 PASSED: Max+1 (256 chars) rejected\n";
    }
    
    // test 9: way over max
    public function test_extreme_max_password() {
        $testValue = "Aa1" . str_repeat("x", 297);  // 300 chars
        
        $this->assertEquals(300, strlen($testValue));
        $error = $this->user->validate("password", $testValue);
        
        $this->assertNotEmpty($error);
        $this->assertEquals("Password exceeds maximum length", $error);
        echo "✓ TEST 9 PASSED: Extreme max (300 chars) rejected\n";
    }
    
    /**
     * TEST 10 - no uppercase letter
     * should fail complexity check
     */
    public function test_password_no_uppercase() {
        $testValue = "password123";  // all lowercase + numbers
        $error = $this->user->validate("password", $testValue);
        
        $this->assertNotEmpty($error);
        $this->assertEquals("Password must contain at least one uppercase letter", $error);
        echo "✓ TEST 10 PASSED: No uppercase rejected\n";
    }
    
    // TEST 11 - no lowercase
    public function test_password_no_lowercase() {
        $testValue = "PASSWORD123";  // all uppercase + numbers
        $error = $this->user->validate("password", $testValue);
        
        $this->assertNotEmpty($error);
        $this->assertEquals("Password must contain at least one lowercase letter", $error);
        echo "✓ TEST 11 PASSED: No lowercase rejected\n";
    }
    
    // TEST 12 - no numbers
    // has upper and lower but missing numbers
    public function test_password_no_number() {
        $testValue = "PasswordTest";  // P is upper, rest is lower, but no digits
        $error = $this->user->validate("password", $testValue);
        
        $this->assertNotEmpty($error);
        $this->assertEquals("Password must contain at least one number", $error);
        echo "✓ TEST 12 PASSED: No number rejected\n";
    }
}