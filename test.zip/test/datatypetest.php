<?php

require_once __DIR__ . '/../classes/user.php';

use PHPUnit\Framework\TestCase;

/**
 * Datatype Validation Tests
 * Testing what happens when wrong datatypes are passed to validation
 * All fields should only accept strings
 * Date: Dec 2024
 */
class DatatypeTest extends TestCase {
    
    private $user;
    
    protected function setUp(): void {
        $this->user = new User();
    }
    
    // ========== EMAIL DATATYPE TESTS ==========
    
    /**
     * TEST 1: Email as Integer
     * Should handle numeric value (convert to string or reject)
     */
    public function test_email_integer_value() {
        $testValue = 12345;  // integer instead of string
        $error = $this->user->validate("email", $testValue);
        
        // Should fail validation (not a valid email format)
        $this->assertNotEmpty($error, "Integer should not be valid email");
        
        echo "\n✓ TEST 1 PASSED: Email integer rejected\n";
    }
    
    /**
     * TEST 2: Email as Float
     */
    public function test_email_float_value() {
        $testValue = 123.45;  // float
        $error = $this->user->validate("email", $testValue);
        
        $this->assertNotEmpty($error);
        echo "✓ TEST 2 PASSED: Email float rejected\n";
    }
    
    /**
     * TEST 3: Email as Boolean
     */
    public function test_email_boolean_value() {
        $testValue = true;  // boolean
        $error = $this->user->validate("email", $testValue);
        
        $this->assertNotEmpty($error);
        echo "✓ TEST 3 PASSED: Email boolean rejected\n";
    }
    
    /**
     * TEST 4: Email as Array
     */
    public function test_email_array_value() {
        $testValue = ["user@example.com"];  // array
        
        // This should cause an error or be handled
        try {
            $error = $this->user->validate("email", $testValue);
            $this->assertNotEmpty($error);
            echo "✓ TEST 4 PASSED: Email array rejected\n";
        } catch (Exception $e) {
            // If it throws exception, that's also acceptable
            $this->assertTrue(true);
            echo "✓ TEST 4 PASSED: Email array caused error (expected)\n";
        }
    }
    
    // ========== NAME DATATYPE TESTS ==========
    
    /**
     * TEST 5: Name as Integer
     */
    public function test_name_integer_value() {
        $testValue = 12345;
        $error = $this->user->validate("name", $testValue);
        
        // Integer "12345" has 5 chars, should pass length check
        // but it's still wrong datatype
        $this->assertEmpty($error, "Integer converts to string");
        echo "✓ TEST 5 PASSED: Name integer accepted (converts to string)\n";
    }
    
    /**
     * TEST 6: Name as Float
     */
    public function test_name_float_value() {
        $testValue = 123.45;
        $error = $this->user->validate("name", $testValue);
        
        // Should convert to "123.45" string
        $this->assertEmpty($error);
        echo "✓ TEST 6 PASSED: Name float accepted (converts to string)\n";
    }
    
    /**
     * TEST 7: Name with NULL value
     */
    public function test_name_null_value() {
        $testValue = null;
        $error = $this->user->validate("name", $testValue);
        
        // NULL should be treated as empty
        $this->assertNotEmpty($error);
        $this->assertEquals("Name is required", $error);
        echo "✓ TEST 7 PASSED: Name NULL rejected\n";
    }
    
    // ========== PHONE DATATYPE TESTS ==========
    
    /**
     * TEST 8: Phone as Integer (valid case)
     * Phone numbers are often stored as integers
     */
    public function test_phone_integer_value() {
        $testValue = 1234567890;  // 10 digit integer
        $error = $this->user->validate("phone", $testValue);
        
        // Should accept and convert to string
        $this->assertEmpty($error, "10 digit integer should be valid phone");
        echo "✓ TEST 8 PASSED: Phone integer accepted\n";
    }
    
    /**
     * TEST 9: Phone as Float
     */
    public function test_phone_float_value() {
        $testValue = 1234567890.5;  // float
        $error = $this->user->validate("phone", $testValue);
        
        // Might accept (converts to "1234567890.5" then strips to digits)
        $this->assertEmpty($error);
        echo "✓ TEST 9 PASSED: Phone float accepted (strips decimal)\n";
    }
    
    /**
     * TEST 10: Phone with String containing letters
     * Testing mixed alphanumeric
     */
    public function test_phone_alphanumeric_string() {
        $testValue = "123ABC456DEF78";  // mixed
        $error = $this->user->validate("phone", $testValue);
        
        // After stripping non-digits: "12345678" = 8 digits (too short)
        $this->assertNotEmpty($error);
        echo "✓ TEST 10 PASSED: Phone alphanumeric rejected\n";
    }
    
    // ========== PASSWORD DATATYPE TESTS ==========
    
    /**
     * TEST 11: Password as Integer
     */
    public function test_password_integer_value() {
        $testValue = 12345678;  // 8 digits
        $error = $this->user->validate("password", $testValue);
        
        // "12345678" has no uppercase/lowercase letters
        $this->assertNotEmpty($error);
        echo "✓ TEST 11 PASSED: Password integer rejected (no letters)\n";
    }
    
    /**
     * TEST 12: Password with only special characters
     */
    public function test_password_special_chars_only() {
        $testValue = "!@#$%^&*()";
        $error = $this->user->validate("password", $testValue);
        
        // No uppercase, lowercase, or numbers
        $this->assertNotEmpty($error);
        echo "✓ TEST 12 PASSED: Password special chars only rejected\n";
    }
    
    /**
     * TEST 13: Password with Unicode characters
     */
    public function test_password_unicode() {
        $testValue = "Pässwörd123";  // unicode characters
        $error = $this->user->validate("password", $testValue);
        
        // Has uppercase, lowercase, numbers - should pass
        $this->assertEmpty($error, "Unicode should be accepted");
        echo "✓ TEST 13 PASSED: Password unicode accepted\n";
    }
    
    // ========== VERIFICATION CODE DATATYPE TESTS ==========
    
    /**
     * TEST 14: Verification code as Integer
     */
    public function test_vcode_integer_value() {
        $testValue = 123456;  // integer (6 digits)
        $error = $this->user->validate("verification_code", $testValue);
        
        // Should convert to "123456" string and pass
        $this->assertEmpty($error, "6-digit integer should pass");
        echo "✓ TEST 14 PASSED: Vcode integer accepted\n";
    }
    
    /**
     * TEST 15: Verification code as Float
     */
    public function test_vcode_float_value() {
        $testValue = 123.456;  // float
        $error = $this->user->validate("verification_code", $testValue);
        
        // Converts to "123.456" which has decimal point (not pure digit)
        $this->assertNotEmpty($error);
        echo "✓ TEST 15 PASSED: Vcode float rejected\n";
    }
    
    /**
     * TEST 16: Verification code starting with zero
     */
    public function test_vcode_leading_zero() {
        $testValue = "012345";  // string with leading zero
        $error = $this->user->validate("verification_code", $testValue);
        
        // Should be valid (exactly 6 digits)
        $this->assertEmpty($error);
        echo "✓ TEST 16 PASSED: Vcode with leading zero accepted\n";
    }
    
    // ========== CROSS-FIELD DATATYPE TESTS ==========
    
    /**
     * TEST 17: SQL Injection attempt in email
     */
    public function test_email_sql_injection() {
        $testValue = "admin'--@example.com";
        $error = $this->user->validate("email", $testValue);
        
        // Should fail format validation
        $this->assertNotEmpty($error);
        echo "✓ TEST 17 PASSED: SQL injection in email rejected\n";
    }
    
    /**
     * TEST 18: XSS attempt in name
     */
    public function test_name_xss_attempt() {
        $testValue = "<script>alert('xss')</script>";
        $error = $this->user->validate("name", $testValue);
        
        // Has 29 chars, should pass length but contains HTML
        $this->assertEmpty($error, "XSS string accepted (needs sanitization elsewhere)");
        echo "✓ TEST 18 PASSED: XSS in name accepted (sanitization needed)\n";
    }
    
    /**
     * TEST 19: Negative number as phone
     */
    public function test_phone_negative_number() {
        $testValue = -1234567890;
        $error = $this->user->validate("phone", $testValue);
        
        // After stripping non-digits: "1234567890" = 10 digits
        $this->assertEmpty($error);
        echo "✓ TEST 19 PASSED: Phone negative accepted (strips minus)\n";
    }
    
    /**
     * TEST 20: Very large number for verification code
     */
    public function test_vcode_large_number() {
        $testValue = 9999999999;  // 10 digits
        $error = $this->user->validate("verification_code", $testValue);
        
        // Converts to "9999999999" (10 chars, not 6)
        $this->assertNotEmpty($error);
        echo "✓ TEST 20 PASSED: Vcode large number rejected\n";
    }
}