<?php
/**
 * Bootstrap file - loads before tests run
 */

// Load PHPUnit
require_once __DIR__ . '/../vendor/autoload.php';

// Load our User class
require_once __DIR__ . '/../classes/User.php';

echo "\n";
echo "========================================\n";
echo "Testing: login_system.users table\n";
echo "========================================\n";
echo "\n";