<?php

require_once __DIR__ . '/../classes/user.php';

use PHPUnit\Framework\TestCase;

/*
 * Phone number validation tests
 * varchar(15) field, needs 10-15 digits
 * Date: Dec 2024
 */
class PhoneTest extends TestCase {
    
    private $user;
    
    protected function setUp(): void {
        $this->user = new User();
    }
    
    // TEST 1 - empty phone number
    public function test_empty_phone() {
        $testValue = "";
        $error = $this->user->validate("phone", $testValue);
        
        $this->assertNotEmpty($error, "Empty phone should fail");
        $this->assertEquals("Phone is required", $error);
        
        echo "\n✓ TEST 1 PASSED: Empty phone rejected\n";
    }
    
    // TEST 2 - 9 digits (below minimum)
    public function test_nine_digit_phone() {
        $testValue = "123456789";
        $error = $this->user->validate("phone", $testValue);
        
        $this->assertNotEmpty($error, "9-digit phone should fail");
        $this->assertEquals("Phone must be at least 10 digits", $error);
        
        echo "✓ TEST 2 PASSED: 9 digits rejected\n";
    }
    
    /* TEST 3 - minimum boundary (10 digits) */
    public function test_min_boundary_phone() {
        $testValue = "1234567890";
        $error = $this->user->validate("phone", $testValue);
        
        $this->assertEmpty($error, "10-digit phone should pass");
        
        echo "✓ TEST 3 PASSED: Minimum boundary (10 digits) accepted\n";
    }
    
    // test 4: 11 digits
    public function test_min_plus_one_phone() {
        $testValue = "12345678901";
        $error = $this->user->validate("phone", $testValue);
        
        $this->assertEmpty($error);
        echo "✓ TEST 4 PASSED: Min+1 (11 digits) accepted\n";
    }
    
    // test 5: mid range - 12 digits
    public function test_mid_range_phone() {
        $testValue = "123456789012";
        $error = $this->user->validate("phone", $testValue);
        
        $this->assertEmpty($error);
        echo "✓ TEST 5 PASSED: Mid-range (12 digits) accepted\n";
    }
    
    // TEST 6: 14 digits (one below max)
    public function test_max_minus_one_phone() {
        $testValue = "12345678901234";
        $error = $this->user->validate("phone", $testValue);
        
        $this->assertEmpty($error);
        echo "✓ TEST 6 PASSED: Max-1 (14 digits) accepted\n";
    }
    
    /**
     * TEST 7 - Max boundary (15 digits)
     * this is the maximum allowed
     */
    public function test_max_boundary_phone() {
        $testValue = "123456789012345";
        $error = $this->user->validate("phone", $testValue);
        
        $this->assertEmpty($error, "15-digit phone should pass");
        
        echo "✓ TEST 7 PASSED: Maximum boundary (15 digits) accepted\n";
    }
    
    // TEST 8 - 16 digits (over max)
    public function test_max_plus_one_phone() {
        $testValue = "1234567890123456";
        $error = $this->user->validate("phone", $testValue);
        
        $this->assertNotEmpty($error, "16-digit phone should fail");
        $this->assertEquals("Phone exceeds maximum length", $error);
        
        echo "✓ TEST 8 PASSED: Max+1 (16 digits) rejected\n";
    }
    
    // TEST 9: way too many digits
    public function test_extreme_max_phone() {
        $testValue = "12345678901234567890";  // 20 digits
        $error = $this->user->validate("phone", $testValue);
        
        $this->assertNotEmpty($error);
        $this->assertEquals("Phone exceeds maximum length", $error);
        
        echo "✓ TEST 9 PASSED: Extreme max (20 digits) rejected\n";
    }
    
    /**
     * TEST 10 - phone with formatting
     * should strip out formatting and pass
     */
    public function test_phone_with_formatting() {
        $testValue = "+44 (123) 456-7890";  // has +, spaces, brackets, dash
        $error = $this->user->validate("phone", $testValue);
        
        // the validation should strip non-numeric chars leaving 13 digits
        $this->assertEmpty($error, "Formatted phone should pass");
        
        echo "✓ TEST 10 PASSED: Phone with formatting accepted\n";
    }
    
    // TEST 11 - phone with letters (invalid)
    // letters should get stripped leaving too few digits
    public function test_phone_with_letters() {
        $testValue = "123ABC7890";
        $error = $this->user->validate("phone", $testValue);
        
        // after stripping letters, only "1237890" = 7 digits
        $this->assertNotEmpty($error, "Phone with letters should fail");
        $this->assertEquals("Phone must be at least 10 digits", $error);
        
        echo "✓ TEST 11 PASSED: Phone with letters rejected\n";
    }
}