<?php

require_once __DIR__ . '/../classes/user.php';

use PHPUnit\Framework\TestCase;

/**
 * Verification Code Tests
 * Field: verification_code (varchar(6))
 * Must be exactly 6 digits, no letters or special chars
 */
class vcodetest extends TestCase {
    
    private $user;
    
    protected function setUp(): void {
        $this->user = new User();
    }
    
    // Test #1: Empty code
    public function test_empty_code() {
        $testValue = "";
        $error = $this->user->validate("verification_code", $testValue);
        
        $this->assertNotEmpty($error);
        $this->assertEquals("Verification code is required", $error);
        
        echo "\n✓ TEST 1 PASSED: Empty code rejected\n";
    }
    
    /**
     * Test 2 - 5 digits (below required)
     */
    public function test_five_digit_code() {
        $testValue = "12345";
        $error = $this->user->validate("verification_code", $testValue);
        
        $this->assertNotEmpty($error, "5-digit code should fail");
        $this->assertEquals("Verification code must be 6 digits", $error);
        
        echo "✓ TEST 2 PASSED: 5 digits rejected\n";
    }
    
    // TEST 3: exactly 6 digits (all zeros)
    public function test_six_digits_all_zeros() {
        $testValue = "000000";
        $error = $this->user->validate("verification_code", $testValue);
        
        $this->assertEmpty($error, "6-digit code with zeros should pass");
        echo "✓ TEST 3 PASSED: 6 digits (all zeros) accepted\n";
    }
    
    // test 4 - valid 6 digit code
    public function test_valid_six_digit_code() {
        $testValue = "123456";
        $error = $this->user->validate("verification_code", $testValue);
        
        $this->assertEmpty($error);
        echo "✓ TEST 4 PASSED: Valid 6 digits accepted\n";
    }
    
    /* Test 5: mid-range value */
    public function test_mid_range_code() {
        $testValue = "555555";
        $error = $this->user->validate("verification_code", $testValue);
        
        $this->assertEmpty($error);
        echo "✓ TEST 5 PASSED: Mid-range 6 digits accepted\n";
    }
    
    // TEST 6 - maximum valid value (all 9s)
    public function test_max_valid_code() {
        $testValue = "999999";
        $error = $this->user->validate("verification_code", $testValue);
        
        $this->assertEmpty($error, "Maximum valid 6-digit code should pass");
        echo "✓ TEST 6 PASSED: Maximum valid (999999) accepted\n";
    }
    
    /**
     * Test 7: 7 digits (over the limit)
     * Should be rejected
     */
    public function test_seven_digit_code() {
        $testValue = "1234567";
        $error = $this->user->validate("verification_code", $testValue);
        
        $this->assertNotEmpty($error, "7-digit code should fail");
        $this->assertEquals("Verification code must be 6 digits", $error);
        
        echo "✓ TEST 7 PASSED: 7 digits rejected\n";
    }
    
    // Test 8: way over limit (10 digits)
    public function test_ten_digit_code() {
        $testValue = "1234567890";
        $error = $this->user->validate("verification_code", $testValue);
        
        $this->assertNotEmpty($error);
        $this->assertEquals("Verification code must be 6 digits", $error);
        echo "✓ TEST 8 PASSED: 10 digits rejected\n";
    }
    
    /*
     * TEST 9 - code with letters
     * ABC123 is 6 chars but has letters so should fail
     */
    public function test_code_with_letters() {
        $testValue = "ABC123";
        $error = $this->user->validate("verification_code", $testValue);
        
        $this->assertNotEmpty($error, "Code with letters should fail");
        $this->assertEquals("Verification code must contain only numbers", $error);
        
        echo "✓ TEST 9 PASSED: Code with letters rejected\n";
    }
    
    // test 10: special characters
    public function test_code_with_special_chars() {
        $testValue = "12-34@";  // has dash and @ symbol
        $error = $this->user->validate("verification_code", $testValue);
        
        $this->assertNotEmpty($error);
        $this->assertEquals("Verification code must contain only numbers", $error);
        echo "✓ TEST 10 PASSED: Code with special chars rejected\n";
    }
    
    // TEST 11 - code with spaces
    public function test_code_with_spaces() {
        $testValue = "123 456";  // space in middle
        $error = $this->user->validate("verification_code", $testValue);
        
        $this->assertNotEmpty($error, "Code with spaces should fail");
        $this->assertEquals("Verification code must contain only numbers", $error);
        
        echo "✓ TEST 11 PASSED: Code with spaces rejected\n";
    }
}