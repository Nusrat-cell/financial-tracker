-- FINANCIAL TRACKER TEST DATA
-- For Portfolio 2 Testing Component
-- Student: [Your Name]
-- Date: December 2024

-- ============= INCOMES TEST DATA =============
-- Testing various scenarios and boundaries
INSERT INTO incomes (Amount, Source, DateReceived, Description, Currency) VALUES
-- Normal valid entries
(1000.50, 'Monthly Salary', '2024-12-01', 'Regular salary payment', 'USD'),
(500.00, 'Freelance Work', '2024-12-05', 'Web development project', 'USD'),
(300.25, 'Annual Bonus', '2024-12-10', 'Year-end bonus', 'USD'),

-- Boundary testing
(0.01, 'Interest', '2024-12-15', 'Minimum amount test', 'USD'),  -- Minimum valid
(999999.99, 'Investment Return', '2024-12-20', 'Maximum test amount', 'USD'),  -- Large amount

-- Different currencies
(750.00, 'EU Contract', '2024-12-03', 'European client payment', 'EUR'),
(600.00, 'UK Project', '2024-12-07', 'British client work', 'GBP'),

-- Various sources for search testing
(200.00, 'Part-time Job', '2024-12-02', 'Weekend work', 'USD'),
(150.00, 'Online Sales', '2024-12-08', 'E-commerce income', 'USD');

-- ============= EXPENSES TEST DATA =============
INSERT INTO expenses (Amount, Vendor, DateSpent, Description) VALUES
-- Normal expenses
(50.00, 'Supermarket', '2024-12-01', 'Weekly groceries'),
(15.50, 'Coffee Shop', '2024-12-02', 'Morning coffee'),
(200.00, 'Gas Station', '2024-12-03', 'Car fuel'),

-- Boundary testing
(0.99, 'App Store', '2024-12-04', 'Minimum expense test'),  -- Small amount
(5000.00, 'Electronics Store', '2024-12-05', 'Maximum expense test'),  -- Large amount

-- Various vendors for search testing
(30.00, 'Restaurant', '2024-12-06', 'Dinner out'),
(25.00, 'Pharmacy', '2024-12-07', 'Medical supplies'),
(80.00, 'Clothing Store', '2024-12-08', 'New clothes');

-- ============= BUDGETS TEST DATA =============
-- Testing boolean repeat flag
INSERT INTO budgets (user_id, category, amount, period, start_date, end_date, repeat_budget, repeat_interval) VALUES
(1, 'Monthly Expenses', 2000.00, 'monthly', '2024-12-01', '2024-12-31', TRUE, 'monthly'),  -- Repeating budget
(1, 'Entertainment', 300.00, 'monthly', '2024-12-01', '2024-12-31', FALSE, NULL),  -- One-time budget
(1, 'Savings Goal', 1000.00, 'monthly', '2024-12-01', '2025-12-01', TRUE, 'monthly');  -- Long-term repeating

-- ============= CURRENCIES TEST DATA =============
INSERT INTO currencies (currency_code, currency_name, exchange_rate, symbol) VALUES
('USD', 'US Dollar', 1.0000, '$'),
('EUR', 'Euro', 0.8500, '€'),
('GBP', 'British Pound', 0.7300, '£'),
('CAD', 'Canadian Dollar', 1.2500, 'C$'),
('BDT', 'Bangladeshi Taka', 110.5000, '৳');

-- ============= TEST DATA SUMMARY =============
-- Total Records Created:
-- Incomes: 9 records (testing amounts, currencies, dates)
-- Expenses: 8 records (testing amounts, vendors, dates)
-- Budgets: 3 records (testing boolean repeat flag)
-- Currencies: 5 currencies (multi-currency support)

-- This test data covers:
-- 1. All data types (string, numeric, boolean, date)
-- 2. Boundary values (min/max amounts)
-- 3. Different scenarios (various sources, vendors)
-- 4. Boolean testing (repeat_budget true/false)
-- 5. Date range testing