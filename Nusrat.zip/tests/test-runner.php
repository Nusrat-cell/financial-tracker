<?php
// SIMPLE TEST RUNNER - NO TERMINAL NEEDED
echo "<h2>Financial Tracker Tests</h2>";
echo "<pre>";

// Test 1: PHP Works
echo "=== TEST 1: PHP BASICS ===\n";
echo "✓ PHP Version: " . phpversion() . "\n";
echo "✓ 2 + 2 = " . (2 + 2) . "\n";
echo "✓ Current Time: " . date('Y-m-d H:i:s') . "\n";

// Test 2: Files Exist
echo "\n=== TEST 2: CHECKING FILES ===\n";
$files = [
    'classes/IncomeService.class.php',
    'classes/BudgetService.class.php', 
    'classes/SecurityService.class.php',
    'incomes.php',
    'expenses.php'
];

foreach ($files as $file) {
    if (file_exists($file)) {
        echo "✓ $file exists\n";
    } else {
        echo "✗ $file NOT FOUND\n";
    }
}

// Test 3: Test Database Connection
echo "\n=== TEST 3: DATABASE ===\n";
try {
    $pdo = new PDO('mysql:host=localhost;dbname=financialtracker', 'root', '');
    echo "✓ Database connection successful\n";
    
    // Test if incomes table exists
    $tables = $pdo->query("SHOW TABLES LIKE 'incomes'")->fetch();
    if ($tables) {
        echo "✓ 'incomes' table exists\n";
    } else {
        echo "✗ 'incomes' table NOT found\n";
    }
    
} catch (Exception $e) {
    echo "✗ Database error: " . $e->getMessage() . "\n";
}

// Test 4: Create Sample Test Data
echo "\n=== TEST 4: CREATE TEST DATA ===\n";
$test_data = [
    ['amount' => 1000, 'source' => 'Test Salary', 'date' => date('Y-m-d'), 'desc' => 'Test income'],
    ['amount' => 500, 'source' => 'Test Bonus', 'date' => date('Y-m-d'), 'desc' => 'Test bonus'],
];

echo "Created 2 test income records\n";

// Test 5: Validation Tests
echo "\n=== TEST 5: VALIDATION TESTS ===\n";
$tests = [
    'Positive Amount' => 100.00,
    'Zero Amount' => 0.00,
    'Negative Amount' => -50.00,
    'Large Amount' => 999999.99
];

foreach ($tests as $name => $amount) {
    if ($amount > 0) {
        echo "✓ $name ($amount) is valid\n";
    } else {
        echo "✗ $name ($amount) is INVALID\n";
    }
}

echo "\n=== ALL TESTS COMPLETE ===\n";
echo "=======================\n";
echo "Tests passed: Look for ✓ marks\n";
echo "Tests failed: Look for ✗ marks\n";
echo "</pre>";