<?php
// Start PHP session to maintain user state across requests
session_start();

// Check if user is logged in, if not set default user ID for development
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1;  // Default user ID for testing
}

// Database connection configuration
$host = 'localhost';        // Database server hostname
$dbname = 'financialtracker'; // Name of the database
$username = 'root';         // Database username
$password = '';             // Database password

try {
    // Create PDO database connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set PDO error mode to exceptions for better error handling
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    // Stop execution and display error if connection fails
    die("Database connection failed: " . $e->getMessage());
}

// Get search filters from URL parameters with null coalescing for safety
$search_query = $_GET['search_query'] ?? '';        // Text search query from URL
$filter_start_date = $_GET['start_date'] ?? '';     // Start date filter from URL
$filter_end_date = $_GET['end_date'] ?? '';         // End date filter from URL
$filter_min_amount = $_GET['min_amount'] ?? '';     // Minimum amount filter from URL
$filter_vendor = $_GET['vendor_search'] ?? '';      // Vendor search filter from URL

// Build SQL query for filtering expenses (same as in expenses.php)
$sql = "SELECT * FROM expenses WHERE 1=1";  // Base query with 1=1 for easy AND appending
$params = [];  // Array to hold prepared statement parameters

// Add start date filter if provided
if(!empty($filter_start_date)) {
    $sql .= " AND DateSpent >= ?";  // Append date filter condition
    $params[] = $filter_start_date; // Add start date to parameters array
}

// Add end date filter if provided
if(!empty($filter_end_date)) {
    $sql .= " AND DateSpent <= ?";  // Append date filter condition
    $params[] = $filter_end_date;   // Add end date to parameters array
}

// Add minimum amount filter if provided
if(!empty($filter_min_amount)) {
    $sql .= " AND Amount >= ?";     // Append amount filter condition
    $params[] = $filter_min_amount; // Add minimum amount to parameters array
}

// Add vendor search filter if provided
if(!empty($filter_vendor)) {
    $sql .= " AND Vendor LIKE ?";   // Append vendor search with LIKE for partial matching
    $params[] = '%' . $filter_vendor . '%';  // Add vendor search term with wildcards
}

// Order results by most recent dates first
$sql .= " ORDER BY DateSpent DESC";

// Prepare and execute the SQL query with filters
$stmt = $pdo->prepare($sql);  // Create prepared statement
$stmt->execute($params);      // Execute query with filter parameters
$expenses = $stmt->fetchAll(); // Fetch all matching expenses as array

// Set HTTP headers for CSV file download
header('Content-Type: text/csv; charset=utf-8');  // Set content type as CSV
header('Content-Disposition: attachment; filename=expenses_export_' . date('Y-m-d_H-i-s') . '.csv');  // Force download with timestamped filename

// Create output stream for writing CSV data
$output = fopen('php://output', 'w');  // Open PHP output stream for writing

// Add BOM (Byte Order Mark) for UTF-8 encoding to ensure Excel compatibility
fputs($output, "\xEF\xBB\xBF");  // UTF-8 BOM characters

// Add CSV column headers as first row
fputcsv($output, ['Amount', 'Vendor', 'Date', 'Description']);  // Write header row to CSV

// Loop through each expense and add as data row in CSV
foreach ($expenses as $expense) {
    // Format and write each expense record as CSV row
    fputcsv($output, [
        '$' . number_format($expense['Amount'], 2),  // Format amount with dollar sign and 2 decimals
        $expense['Vendor'],                          // Vendor name as-is
        $expense['DateSpent'],                       // Date in YYYY-MM-DD format
        $expense['Description']                      // Expense description
    ]);
}

// Close the output stream
fclose($output);

// Exit script to prevent any additional output that would corrupt CSV file
exit;
?>