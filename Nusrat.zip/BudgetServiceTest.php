Invoke-WebRequest -Uri "https://phar.phpunit.de/phpunit-9.6.phar" -OutFile "phpunit.phar"
