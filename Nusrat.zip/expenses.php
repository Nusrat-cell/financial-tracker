<?php
// =============================================
// ERROR REPORTING & SESSION CONFIGURATION
// =============================================

// Enable all error reporting for debugging during development
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start PHP session to maintain user state across page loads
// Sessions store user data on server between page requests
session_start();

// =============================================
// USER AUTHENTICATION & DEFAULT SETTINGS
// =============================================

// Check if user is logged in by verifying session user_id exists
// If not logged in, set a default user ID for development/testing
if (!isset($_SESSION['user_id'])) {
    // Set default user ID to prevent authentication errors during development
    $_SESSION['user_id'] = 1;
}

// =============================================
// DATABASE CONNECTION CONFIGURATION
// =============================================

// Database server hostname (localhost for local development)
$host = 'localhost';

// Name of the database to connect to
$dbname = 'financialtracker';

// Database username for authentication (root is default for localhost)
$username = 'root';

// Database password (empty by default in XAMPP/WAMP local environments)
$password = '';

// Try to establish database connection using PDO (PHP Data Objects)
// PDO provides a consistent interface for database access
try {
    // Create new PDO instance for database connection
    // DSN (Data Source Name) specifies database type and location
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    
    // Set error mode to exceptions for better error handling
    // This makes PDO throw exceptions instead of silent failures
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Optional: Test database connection with a simple query
    $pdo->query("SELECT 1");
    
} catch(PDOException $e) {
    // Stop execution and display error if connection fails
    // PDOException contains specific database error information
    die("Database connection failed: " . $e->getMessage());
}

// =============================================
// PRESENTATION LAYER VARIABLES - UI/UX Settings
// =============================================

// Get current theme from session or default to light theme
// Null coalescing operator (??) provides fallback value
$current_theme = $_SESSION['theme'] ?? 'light';

// Time-based greeting system variables
// Get current hour in 24-hour format (00-23)
$current_hour = date('H');

// Get current time in 12-hour format with AM/PM
$current_time = date('h:i A');

// Get current date in full month name format (e.g., "December 25, 2024")
$current_date = date('F j, Y');

// Determine appropriate greeting based on time of day
// Morning: 12 AM - 11:59 AM
if ($current_hour < 12) {
    // Morning greeting for hours before noon
    $greeting = "Good Morning";
    // Morning icon/symbol (sunrise)
    $time_image = "🌅";
} 
// Afternoon: 12 PM - 4:59 PM  
elseif ($current_hour < 17) {
    // Afternoon greeting for hours between 12-5 PM
    $greeting = "Good Afternoon"; 
    // Afternoon sun icon
    $time_image = "☀️";
} 
// Evening: 5 PM - 8:59 PM
elseif ($current_hour < 21) {
    // Evening greeting for hours between 5-9 PM
    $greeting = "Good Evening";
    // Sunset icon for evening
    $time_image = "🌇";
} 
// Night: 9 PM - 11:59 PM
else {
    // Night greeting for hours after 9 PM
    $greeting = "Good Night";
    // Moon icon for night time
    $time_image = "🌙";
}

// Array of inspirational financial quotes about expenses
// These will be displayed randomly to motivate users
$money_quotes = [
    "Track your expenses like you track your goals - meticulously and consistently.",
    "Financial freedom begins with knowing where your money goes.",
    "Small expenses add up to big amounts. Track them all!",
    "Budgeting has one rule: Do not go over budget.",
    "Every dollar saved from unnecessary expenses is a step towards financial independence.",
    "Wealth is not built on income alone, but on disciplined spending habits.",
    "The goal isn't to spend less, but to spend wisely.",
    "A penny saved is a penny earned - track every single one!",
    "Don't let small expenses sneak up on you. Track them diligently.",
    "Financial peace comes from controlling your expenses, not just your income."
];

// Select a random quote from the array to display
// array_rand() returns a random key from the array
$random_quote = $money_quotes[array_rand($money_quotes)];

// Initialize message variables for user feedback
// These will display success/error messages to users
$success = '';
$error = '';

// Check for success messages passed via URL parameters (from edit/delete actions)
// This happens when user is redirected back after edit/delete operations
if(isset($_GET['message'])) {
    // Check if message indicates a record was updated
    if($_GET['message'] == 'updated') {
        // Set success message for update operation
        $success = "✅ Expense record updated successfully!";
    } 
    // Check if message indicates a record was deleted
    elseif($_GET['message'] == 'deleted') {
        // Set success message for delete operation
        $success = "✅ Expense record deleted successfully!";
    }
}

// Control variable for showing the animated doll character
// Doll appears when form is submitted successfully
$show_doll = false;

// =============================================
// FORM PROCESSING - Handle New Expense Submission
// =============================================

// Handle form submission for adding new expenses
// Check if the 'add_expense' button was clicked
if(isset($_POST['add_expense'])) {
    // Show doll animation when form is submitted
    $show_doll = true;
    
    // Get and sanitize form input data
    // Convert amount to float for numerical operations
    $amount = floatval($_POST['amount']);
    
    // Trim whitespace from vendor name to remove extra spaces
    $vendor = trim($_POST['vendor']);
    
    // Get date from form (already in YYYY-MM-DD format)
    $date = $_POST['date_spent'];
    
    // Trim whitespace from description
    $description = trim($_POST['description']);
    
    // =============================================
    // FORM VALIDATION - Check all input requirements
    // =============================================
    
    // Validate all required fields are filled
    if(empty($amount) || empty($vendor) || empty($date)) {
        // Set error message for missing required fields
        $error = "❌ Please fill all required fields (Amount, Vendor, and Date)";
    }
    // Validate amount is positive number
    elseif($amount <= 0) {
        // Set error message for invalid amount
        $error = "❌ Amount must be greater than $0.00";
    }
    // Validate vendor name length (at least 2 characters)
    elseif(strlen($vendor) < 2) {
        // Set error message for short vendor name
        $error = "❌ Vendor name must be at least 2 characters long";
    }
    // Validate date is not in the future
    elseif($date > date('Y-m-d')) {
        // Set error message for future date
        $error = "❌ Date cannot be in the future";
    }
    // All validation passed - proceed with database insertion
    else {
        // Prepare SQL query for inserting new expense
        // Using prepared statements to prevent SQL injection
        $sql = "INSERT INTO expenses (Amount, Vendor, DateSpent, Description) VALUES (?, ?, ?, ?)";
        
        // Create prepared statement to prevent SQL injection
        // Prepared statements separate SQL code from data
        $stmt = $pdo->prepare($sql);
        
        // Execute query with form data as parameters
        // execute() binds the parameters safely to the SQL statement
        if($stmt->execute([$amount, $vendor, $date, $description])) {
            // Set success message for successful addition
            $success = "✅ Expense recorded successfully! Stay mindful! 💡";
            
            // Clear form fields after successful submission
            // This prevents form resubmission on page refresh
            $_POST = array();
        } else {
            // Set error message for database insertion failure
            $error = "❌ Error adding expense to database. Please try again.";
        }
    }
}

// =============================================
// SEARCH & FILTER FUNCTIONALITY
// =============================================

// Search and filter variables with null coalescing for safety
// These get URL parameters for filtering expense records
$search_query = $_GET['search_query'] ?? '';
$filter_start_date = $_GET['start_date'] ?? '';
$filter_end_date = $_GET['end_date'] ?? '';
$filter_min_amount = $_GET['min_amount'] ?? '';
$filter_vendor = $_GET['vendor_search'] ?? '';

// Build base SQL query for expenses
// 'WHERE 1=1' is a trick to easily append AND conditions
$sql = "SELECT * FROM expenses WHERE 1=1";

// Array to hold parameter values for prepared statement
// This ensures safe SQL execution with user input
$params = [];

// Add date range filter if start date provided
if(!empty($filter_start_date)) {
    // Append date filter to SQL query
    $sql .= " AND DateSpent >= ?";
    // Add start date to parameters array
    $params[] = $filter_start_date;
}

// Add date range filter if end date provided
if(!empty($filter_end_date)) {
    // Append end date filter to SQL query
    $sql .= " AND DateSpent <= ?";
    // Add end date to parameters array
    $params[] = $filter_end_date;
}

// Add minimum amount filter if provided
if(!empty($filter_min_amount)) {
    // Append amount filter to SQL query
    $sql .= " AND Amount >= ?";
    // Add minimum amount to parameters array
    $params[] = floatval($filter_min_amount);
}

// Add vendor search filter if provided
if(!empty($filter_vendor)) {
    // Append vendor search to SQL query with LIKE for partial matching
    $sql .= " AND Vendor LIKE ?";
    // Add vendor search term with wildcards to parameters array
    $params[] = '%' . $filter_vendor . '%';
}

// Order results by most recent expenses first
// DESC = descending order (newest first)
$sql .= " ORDER BY DateSpent DESC";

// Prepare the final SQL query with all filters applied
$stmt = $pdo->prepare($sql);

// Execute query with all filter parameters
// If no parameters, execute without arguments
if (!empty($params)) {
    $stmt->execute($params);
} else {
    $stmt->execute();
}

// Fetch all matching expenses as associative array
// Each expense becomes an array with field names as keys
$expenses = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get summary statistics for dashboard display
// Calculate total count and sum of all expenses
$stats_sql = "SELECT COUNT(*) as total, SUM(Amount) as total_amount FROM expenses";
$stats_stmt = $pdo->query($stats_sql);
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

// If no expenses exist, set default values to prevent errors
if (!$stats['total']) {
    $stats['total'] = 0;
    $stats['total_amount'] = 0;
}

// Determine if filters are active for UI display
// Used to show appropriate messages when no results found
$show_filters = !empty($search_query) || !empty($filter_start_date) || 
                !empty($filter_end_date) || !empty($filter_min_amount) || 
                !empty($filter_vendor);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- Responsive viewport setting for mobile devices -->
    <!-- Ensures proper scaling on phones and tablets -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expense Management - Financial Tracker</title>
    
    <!-- Include Chart.js library for data visualization -->
    <!-- Used for displaying expense charts and graphs -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        /* =============================================
           PROFESSIONAL FINANCIAL COLOR PALETTE
           CSS custom properties for consistent theming
        ============================================= */
        :root {
            /* Main background gradient - professional blue */
            --primary-bg: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            /* Card background color with transparency for glass effect */
            --card-bg: rgba(255, 255, 255, 0.95);
            /* Primary text color - dark blue-gray for readability */
            --text-color: #2c3e50;
            /* Header background gradient */
            --header-bg: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
            /* Accent color for expenses (red) - draws attention to spending */
            --accent-color: #e74c3c;
            /* Secondary accent color (blue) - for buttons and highlights */
            --accent-secondary: #2980b9;
            /* Danger color for warnings and delete actions */
            --danger-color: #e74c3c;
            /* Warning color for alerts and doll character */
            --warning-color: #f39c12;
            /* Success color for positive actions and confirmations */
            --success-color: #27ae60;
        }

        /* Dark theme color overrides */
        [data-theme="dark"] {
            /* Dark mode background gradient - deeper blues */
            --primary-bg: linear-gradient(135deg, #0f1c30 0%, #1a3658 100%);
            /* Dark mode card background - dark with transparency */
            --card-bg: rgba(44, 62, 80, 0.95);
            /* Light text color for dark background - ensures contrast */
            --text-color: #ecf0f1;
            /* Dark mode header gradient */
            --header-bg: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            /* Maintain accent colors in dark mode for consistency */
            --accent-color: #e74c3c;
            --accent-secondary: #3498db;
            --danger-color: #e74c3c;
            --warning-color: #f39c12;
            --success-color: #27ae60;
        }

        /* Reset all default margins and paddings for consistent styling */
        * {
            margin: 0;
            padding: 0;
            /* Include padding and border in element's total width/height */
            box-sizing: border-box;
            /* Modern font stack for better readability across devices */
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Main body styling with gradient background */
        body {
            /* Apply background gradient from CSS variables */
            background: var(--primary-bg);
            /* Minimum height of viewport - ensures full screen coverage */
            min-height: 100vh;
            /* Text color from CSS variables */
            color: var(--text-color);
            /* Positioning context for absolute positioned children */
            position: relative;
            /* Hide horizontal scrollbar */
            overflow-x: hidden;
            /* Smooth transitions for theme changes */
            transition: all 0.3s ease;
        }

        /* Main container for centering content with maximum width */
        .container {
            /* Maximum width for large screens - prevents overly wide layouts */
            max-width: 1400px;
            /* Center container horizontally */
            margin: 0 auto;
            /* Internal spacing around content */
            padding: 20px;
            /* Ensure content stays above background elements */
            position: relative;
            z-index: 1;
        }

        /* =============================================
           HEADER BAR - Fixed navigation at top
        ============================================= */
        .header-bar {
            /* Fixed positioning to stay at top during scroll */
            position: fixed;
            top: 0;
            left: 0;
            /* Full width of viewport */
            width: 100%;
            /* Header background from variables */
            background: var(--header-bg);
            /* White text color for contrast against colored background */
            color: white;
            /* Vertical padding */
            padding: 15px 0;
            /* Shadow for depth perception - creates separation from content */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            /* High z-index to stay above other content */
            z-index: 1000;
            /* Flexbox for horizontal layout of header items */
            display: flex;
            /* Space between logo and controls */
            justify-content: space-between;
            /* Center items vertically */
            align-items: center;
            /* Fixed header height for consistent spacing */
            height: 80px;
        }

        /* Header content wrapper for proper alignment */
        .header-content {
            /* Flexbox for horizontal layout */
            display: flex;
            /* Space between left and right sections */
            justify-content: space-between;
            /* Center items vertically */
            align-items: center;
            /* Full width of parent */
            width: 100%;
            /* Maximum width constraint matching main container */
            max-width: 1400px;
            /* Center horizontally */
            margin: 0 auto;
            /* Horizontal padding */
            padding: 0 20px;
        }

        /* Application title styling - main branding */
        .app-title {
            /* Larger font size for prominence */
            font-size: 1.8rem;
            /* Semi-bold font weight for emphasis */
            font-weight: 600;
            /* Letter spacing for better readability and premium feel */
            letter-spacing: 1px;
        }

        /* Header controls container for theme and time widgets */
        .header-controls {
            /* Flexbox for horizontal layout */
            display: flex;
            /* Center items vertically */
            align-items: center;
            /* Space between control elements */
            gap: 20px;
        }

        /* Theme toggle button styling */
        .theme-toggle {
            /* Semi-transparent white background for glass effect */
            background: rgba(255, 255, 255, 0.15);
            /* Remove default border */
            border: none;
            /* White text color for contrast */
            color: white;
            /* Internal padding for comfortable clicking */
            padding: 10px 15px;
            /* Rounded corners for modern appearance */
            border-radius: 20px;
            /* Pointer cursor indicates clickable element */
            cursor: pointer;
            /* Smooth transition for hover effects */
            transition: all 0.3s ease;
        }

        /* Theme toggle hover effect */
        .theme-toggle:hover {
            /* Darker background on hover for feedback */
            background: rgba(255, 255, 255, 0.25);
            /* Slight scale effect on hover for interactivity */
            transform: scale(1.05);
        }

        /* Time display container with glassmorphism effect */
        .time-display {
            /* Semi-transparent background */
            background: rgba(255, 255, 255, 0.1);
            /* Internal padding */
            padding: 10px 20px;
            /* Rounded corners */
            border-radius: 25px;
            /* Center text horizontally */
            text-align: center;
            /* Blur effect for glassmorphism - modern UI trend */
            backdrop-filter: blur(10px);
            /* Subtle border for definition */
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        /* Time icon styling - larger emoji */
        .time-icon {
            /* Larger icon size for visual emphasis */
            font-size: 1.5rem;
            /* Small space below icon */
            margin-bottom: 2px;
        }

        /* Greeting text styling in time widget */
        .time-greeting {
            /* Bold font weight for emphasis */
            font-weight: 600;
            /* Standard font size */
            font-size: 1rem;
        }

        /* Actual time text styling */
        .time-text {
            /* Smaller font size for secondary information */
            font-size: 0.8rem;
            /* Slightly transparent for hierarchy */
            opacity: 0.9;
        }

        /* =============================================
           MAIN CONTENT - Adjusted for fixed header
        ============================================= */
        .main-content {
            /* Space for fixed header - prevents content hiding behind header */
            margin-top: 100px;
            /* Minimum height calculation for full viewport coverage */
            min-height: calc(100vh - 120px);
        }

        /* =============================================
           HERO SECTION - 3:2 ratio layout
        ============================================= */
        .hero-section {
            /* CSS Grid for two-column layout */
            display: grid;
            /* 3:2 ratio for columns - welcome card larger than stats */
            grid-template-columns: 3fr 2fr;
            /* Space between columns */
            gap: 30px;
            /* Space below section */
            margin-bottom: 40px;
            /* Fixed height for consistency across devices */
            height: 400px;
        }

        /* Welcome card styling - main promotional area */
        .welcome-card {
            /* Card background from variables */
            background: var(--card-bg);
            /* Generous internal spacing */
            padding: 40px;
            /* Rounded corners for modern card design */
            border-radius: 25px;
            /* Shadow for depth and separation from background */
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            /* Border with accent color for brand consistency */
            border: 2px solid var(--accent-secondary);
            /* Flexbox for vertical centering of content */
            display: flex;
            flex-direction: column;
            /* Center content vertically within card */
            justify-content: center;
            /* Glassmorphism effect for modern appearance */
            backdrop-filter: blur(10px);
        }

        /* Main heading in welcome card - primary attention grabber */
        .welcome-card h1 {
            /* Large font size for prominence and hierarchy */
            font-size: 2.8rem;
            /* Accent color for heading - matches brand */
            color: var(--accent-secondary);
            /* Space below heading for content separation */
            margin-bottom: 15px;
            /* Bold font weight for emphasis */
            font-weight: 600;
            /* Line height for readability with large text */
            line-height: 1.2;
        }

        /* Quote text styling - inspirational message */
        .welcome-card .quote {
            /* Medium font size for comfortable reading */
            font-size: 1.3rem;
            /* Text color from variables for consistency */
            color: var(--text-color);
            /* Italic style for quotes - visual distinction */
            font-style: italic;
            /* Space below quote for separation */
            margin-bottom: 25px;
            /* Line height for readability */
            line-height: 1.6;
            /* Slight transparency for secondary importance */
            opacity: 0.8;
        }

        /* Statistics card styling - data overview */
        .stats-card {
            /* Card background matching welcome card */
            background: var(--card-bg);
            /* Internal spacing */
            padding: 40px;
            /* Rounded corners */
            border-radius: 25px;
            /* Shadow for depth */
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            /* Border with accent color */
            border: 2px solid var(--accent-secondary);
            /* Glassmorphism effect */
            backdrop-filter: blur(10px);
            /* Flexbox for vertical centering */
            display: flex;
            flex-direction: column;
            /* Center content vertically */
            justify-content: center;
        }

        /* Statistics grid layout - 2x2 grid of stats */
        .stats-grid {
            /* CSS Grid for statistics layout */
            display: grid;
            /* Two equal columns */
            grid-template-columns: 1fr 1fr;
            /* Space between grid items */
            gap: 20px;
        }

        /* Individual statistic item styling */
        .stat-item {
            /* Center text horizontally within stat block */
            text-align: center;
            /* Internal spacing for content */
            padding: 25px 15px;
            /* Card background for individual stat blocks */
            background: var(--card-bg);
            /* Rounded corners */
            border-radius: 15px;
            /* Border with accent color */
            border: 1px solid var(--accent-secondary);
            /* Shadow for depth and interactivity indication */
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            /* Pointer cursor indicates interactive element */
            cursor: pointer;
            /* Smooth transition for hover effects */
            transition: all 0.3s ease;
        }

        /* Stat item hover effect - interactive feedback */
        .stat-item:hover {
            /* Scale up on hover for tactile feedback */
            transform: scale(1.05);
            /* Enhanced shadow with accent color glow */
            box-shadow: 0 8px 25px rgba(231, 76, 60, 0.3);
        }

        /* Stat value number styling - most important number */
        .stat-value {
            /* Large font size for number prominence */
            font-size: 2rem;
            /* Bold font weight for emphasis */
            font-weight: 700;
            /* Accent color for numbers - draws attention to data */
            color: var(--accent-color);
            /* Space below number for label separation */
            margin-bottom: 5px;
        }

        /* Stat label text styling - describes what the number represents */
        .stat-label {
            /* Smaller font size for secondary information */
            font-size: 0.9rem;
            /* Text color from variables */
            color: var(--text-color);
            /* Medium font weight for readability */
            font-weight: 500;
            /* Slight transparency for visual hierarchy */
            opacity: 0.8;
        }

        /* =============================================
           DOLL SYSTEM - Animated character at bottom right
        ============================================= */
        .doll-container {
            /* Fixed positioning for always-visible character */
            position: fixed;
            /* Position from bottom of viewport */
            bottom: 30px;
            /* Position from right of viewport */
            right: 30px;
            /* High z-index to stay above all other content */
            z-index: 2000;
            /* Flexbox for vertical layout of message and character */
            display: flex;
            flex-direction: column;
            /* Align items to right edge */
            align-items: flex-end;
            /* Space between message bubble and character */
            gap: 15px;
        }

        /* Doll message bubble styling - speech bubble appearance */
        .doll-message {
            /* Card background for message bubble */
            background: var(--card-bg);
            /* Internal spacing for text */
            padding: 20px 25px;
            /* Rounded corners for bubble appearance */
            border-radius: 20px;
            /* Shadow for depth and separation */
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            /* Border with warning color for attention */
            border: 3px solid var(--warning-color);
            /* Maximum width constraint for readable line length */
            max-width: 280px;
            /* Positioning context for speech bubble tail */
            position: relative;
            /* Entrance animation for smooth appearance */
            animation: messagePop 0.5s ease-out;
        }

        /* Keyframes for message pop animation */
        @keyframes messagePop {
            0% { 
                /* Start from below and scaled down - creates pop effect */
                transform: translateY(100px) scale(0.8); 
                /* Start invisible - fade in effect */
                opacity: 0; 
            }
            100% { 
                /* End at normal position and size */
                transform: translateY(0) scale(1); 
                /* End fully visible */
                opacity: 1; 
            }
        }

        /* Speech bubble tail - triangle pointing to character */
        .doll-message::after {
            /* Empty content for pseudo-element */
            content: "";
            /* Absolute positioning relative to message bubble */
            position: absolute;
            /* Position below message bubble */
            bottom: -10px;
            /* Position from right - aligns with character */
            right: 30px;
            /* CSS triangle dimensions */
            border-width: 10px 10px 0 10px;
            /* Solid border style for triangle */
            border-style: solid;
            /* Triangle color matching message border */
            border-color: var(--warning-color) transparent transparent transparent;
        }

        /* Main doll message text - primary message content */
        .doll-text {
            /* Medium font size for readability */
            font-size: 1.2rem;
            /* Warning color for text - matches border */
            color: var(--warning-color);
            /* Bold font weight for emphasis */
            font-weight: 600;
            /* Space below main text for subtext separation */
            margin-bottom: 8px;
        }

        /* Doll subtext styling - secondary message content */
        .doll-subtext {
            /* Standard font size */
            font-size: 1rem;
            /* Text color from variables */
            color: var(--text-color);
            /* Line height for readability */
            line-height: 1.4;
            /* Slight transparency for visual hierarchy */
            opacity: 0.8;
        }

        /* Doll character circle - main interactive element */
        .doll-character {
            /* Fixed width for consistent circle */
            width: 100px;
            /* Fixed height for perfect circle */
            height: 100px;
            /* Gradient background for visual appeal */
            background: linear-gradient(135deg, var(--warning-color), #f1c40f);
            /* Circular shape using border-radius */
            border-radius: 50%;
            /* Flexbox for centering emoji content */
            display: flex;
            /* Center vertically */
            align-items: center;
            /* Center horizontally */
            justify-content: center;
            /* Large emoji size for visibility */
            font-size: 3rem;
            /* White text color for contrast against gradient */
            color: white;
            /* Shadow for depth and glow effect */
            box-shadow: 0 10px 25px rgba(243, 156, 18, 0.4);
            /* Pointer cursor indicates clickable element */
            cursor: pointer;
            /* Smooth transition for hover effects */
            transition: all 0.3s ease;
            /* Continuous floating animation for attention */
            animation: float 3s ease-in-out infinite;
        }

        /* Doll character hover effect - interactive feedback */
        .doll-character:hover {
            /* Scale up on hover for tactile feedback */
            transform: scale(1.1);
            /* Enhanced shadow on hover for glow effect */
            box-shadow: 0 15px 35px rgba(243, 156, 18, 0.6);
        }

        /* Keyframes for floating animation - gentle up/down movement */
        @keyframes float {
            0%, 100% { 
                /* Normal position */
                transform: translateY(0px); 
            }
            50% { 
                /* Float upward - creates bouncing effect */
                transform: translateY(-15px); 
            }
        }

        /* =============================================
           CONTENT SECTIONS - 3:2 ratio grid layouts
        ============================================= */
        .content-section {
            /* CSS Grid for two-column layout */
            display: grid;
            /* 3:2 ratio for columns - form larger than insights */
            grid-template-columns: 3fr 2fr;
            /* Space between columns */
            gap: 30px;
            /* Space below section */
            margin-bottom: 40px;
        }

        /* Card component styling - reusable card design */
        .card {
            /* Card background from variables */
            background: var(--card-bg);
            /* Internal spacing */
            padding: 35px;
            /* Rounded corners for modern design */
            border-radius: 20px;
            /* Subtle shadow for depth */
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            /* Border with accent color for definition */
            border: 1px solid var(--accent-secondary);
            /* Glassmorphism effect for modern UI */
            backdrop-filter: blur(10px);
        }

        /* Card heading styling - section titles */
        .card h2 {
            /* Accent color for headings - brand consistency */
            color: var(--accent-secondary);
            /* Space below heading for content separation */
            margin-bottom: 25px;
            /* Semi-bold font weight for emphasis */
            font-weight: 600;
            /* Medium font size for hierarchy */
            font-size: 1.5rem;
            /* Flexbox for icon and text alignment */
            display: flex;
            /* Center items vertically */
            align-items: center;
            /* Space between icon and text */
            gap: 15px;
        }

        /* Card icon styling - decorative element for sections */
        .card-icon {
            /* Fixed width for consistent icon size */
            width: 50px;
            /* Fixed height matching width */
            height: 50px;
            /* Gradient background for visual appeal */
            background: linear-gradient(135deg, var(--accent-secondary), #3498db);
            /* Slightly rounded corners - modern squared circle */
            border-radius: 12px;
            /* Flexbox for centering icon content */
            display: flex;
            /* Center vertically */
            align-items: center;
            /* Center horizontally */
            justify-content: center;
            /* White text color for contrast against gradient */
            color: white;
            /* Bold font weight for icon emphasis */
            font-weight: bold;
            /* Larger icon size for visibility */
            font-size: 1.4rem;
            /* Shadow for depth and separation */
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
        }

        /* =============================================
           FORM STYLING - Consistent form element design
        ============================================= */
        .form-group {
            /* Space between form groups for visual separation */
            margin-bottom: 20px;
        }

        /* Form label styling - field descriptions */
        label {
            /* Block display for full width and proper spacing */
            display: block;
            /* Space below label for separation from input */
            margin-bottom: 8px;
            /* Text color from variables */
            color: var(--text-color);
            /* Medium font weight for readability */
            font-weight: 500;
        }

        /* Input, textarea, and select styling - consistent form controls */
        input, textarea, select {
            /* Full width of container for consistent sizing */
            width: 100%;
            /* Internal spacing for comfortable typing */
            padding: 14px 16px;
            /* Border with accent color for brand consistency */
            border: 2px solid var(--accent-secondary);
            /* Rounded corners for modern appearance */
            border-radius: 12px;
            /* Standard font size for readability */
            font-size: 1rem;
            /* Smooth transition for focus effects */
            transition: all 0.3s ease;
            /* Background from variables for theme consistency */
            background: var(--card-bg);
            /* Text color from variables */
            color: var(--text-color);
        }

        /* Focus state for form elements - accessibility enhancement */
        input:focus, textarea:focus, select:focus {
            /* Remove default browser outline */
            outline: none;
            /* Change border color on focus for visual feedback */
            border-color: var(--accent-color);
            /* Glow effect on focus for emphasis */
            box-shadow: 0 0 0 3px rgba(231, 76, 60, 0.2);
        }

        /* Primary button styling - main call-to-action buttons */
        .btn {
            /* Gradient background for visual appeal */
            background: linear-gradient(135deg, var(--accent-color), #e74c3c);
            /* White text color for contrast */
            color: white;
            /* Internal spacing for comfortable clicking */
            padding: 14px 35px;
            /* Remove default border */
            border: none;
            /* Rounded corners for modern design */
            border-radius: 12px;
            /* Pointer cursor indicates clickable element */
            cursor: pointer;
            /* Standard font size */
            font-size: 1rem;
            /* Medium font weight for emphasis */
            font-weight: 500;
            /* Smooth transition for hover effects */
            transition: all 0.3s ease;
            /* Shadow with accent color for depth */
            box-shadow: 0 4px 15px rgba(231, 76, 60, 0.3);
        }

        /* Button hover effect - interactive feedback */
        .btn:hover {
            /* Lift effect on hover for tactile feedback */
            transform: translateY(-2px);
            /* Enhanced shadow on hover for glow effect */
            box-shadow: 0 8px 25px rgba(231, 76, 60, 0.4);
        }

        /* Secondary button variant - for less important actions */
        .btn-secondary {
            /* Different gradient for secondary actions - visual distinction */
            background: linear-gradient(135deg, var(--accent-secondary), #3498db);
        }

        /* =============================================
           MESSAGE STYLING - Alert and status messages
        ============================================= */
        .message {
            /* Internal spacing for message content */
            padding: 18px;
            /* Rounded corners for modern appearance */
            border-radius: 12px;
            /* Space below message for separation from following content */
            margin-bottom: 25px;
            /* Center text horizontally for emphasis */
            text-align: center;
            /* Medium font weight for readability */
            font-weight: 500;
            /* Border for all messages - definition */
            border: 1px solid;
        }

        /* Error message styling - for validation errors and failures */
        .error {
            /* Light red background for warning */
            background: #ffebee;
            /* Dark red text for readability and urgency */
            color: #c62828;
            /* Red border for visual association with error */
            border-color: #ffcdd2;
        }

        /* Success message styling - for confirmations and successes */
        .success {
            /* Light green background for positive feedback */
            background: #e8f5e9;
            /* Dark green text for readability and success indication */
            color: #2e7d32;
            /* Green border for visual association with success */
            border-color: #c8e6c9;
        }

        /* =============================================
           TABLE STYLES - Data presentation
        ============================================= */
        .table-container {
            /* Card-like container for tables - consistent with other elements */
            background: var(--card-bg);
            /* Internal spacing */
            padding: 35px;
            /* Rounded corners */
            border-radius: 20px;
            /* Subtle shadow for depth */
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            /* Space below container */
            margin-bottom: 30px;
            /* Border with accent color for definition */
            border: 1px solid var(--accent-secondary);
        }

        /* Table element styling - data grid */
        table {
            /* Full width of container for optimal space usage */
            width: 100%;
            /* Remove space between borders for clean lines */
            border-collapse: collapse;
            /* Space above table for separation from heading */
            margin-top: 20px;
        }

        /* Table header and cell styling - consistent cell design */
        th, td {
            /* Internal cell spacing for readable content */
            padding: 16px;
            /* Left-aligned text for natural reading flow */
            text-align: left;
            /* Bottom border for row separation */
            border-bottom: 1px solid #e0e0e0;
        }

        /* Table header specific styling - column labels */
        th {
            /* Light gray background for header distinction */
            background: #f8f9fa;
            /* Accent color for header text */
            color: var(--accent-secondary);
            /* Semi-bold font weight for emphasis */
            font-weight: 600;
            /* Smaller font size for compact headers */
            font-size: 0.9rem;
            /* Uppercase text for formal table appearance */
            text-transform: uppercase;
            /* Letter spacing for readability of uppercase text */
            letter-spacing: 1px;
        }

        /* Action links in table cells - edit/delete operations */
        .action-links a {
            /* Accent color for links - consistent with brand */
            color: var(--accent-secondary);
            /* Remove underline for clean appearance */
            text-decoration: none;
            /* Horizontal spacing between links */
            margin: 0 8px;
            /* Medium font weight for emphasis */
            font-weight: 500;
            /* Smooth color transition for hover effects */
            transition: color 0.3s ease;
            /* Internal spacing for clickable area */
            padding: 6px 12px;
            /* Rounded corners for modern button appearance */
            border-radius: 6px;
            /* Transparent border for consistent sizing on hover */
            border: 1px solid transparent;
        }

        /* Action link hover effect - interactive feedback */
        .action-links a:hover {
            /* Light background on hover for visual feedback */
            background: rgba(52, 152, 219, 0.1);
            /* Border color on hover for definition */
            border-color: var(--accent-secondary);
        }

        /* Delete action link styling - dangerous operation indication */
        .action-links a[onclick] {
            /* Danger color for delete actions - red for warning */
            color: var(--danger-color);
        }

        /* Delete action hover effect - reinforced warning */
        .action-links a[onclick]:hover {
            /* Light red background for warning feedback */
            background: rgba(231, 76, 60, 0.1);
            /* Red border on hover for consistent warning theme */
            border-color: var(--danger-color);
        }

        /* Back button styling - navigation element */
        .back-btn {
            /* Flexbox for icon and text alignment */
            display: inline-flex;
            /* Center items vertically */
            align-items: center;
            /* Space between icon and text */
            gap: 10px;
            /* Accent color for text */
            color: var(--accent-secondary);
            /* Remove underline for clean appearance */
            text-decoration: none;
            /* Space above button for separation */
            margin-top: 20px;
            /* Internal spacing for comfortable clicking */
            padding: 12px 25px;
            /* Card background for consistent styling */
            background: var(--card-bg);
            /* Rounded corners */
            border-radius: 12px;
            /* Smooth transition for hover effects */
            transition: all 0.3s ease;
            /* Medium font weight for emphasis */
            font-weight: 500;
            /* Border with accent color for definition */
            border: 1px solid var(--accent-secondary);
        }

        /* Back button hover effect - interactive feedback */
        .back-btn:hover {
            /* Move left on hover for directional feedback */
            transform: translateX(-5px);
            /* Shadow on hover for depth and emphasis */
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.2);
        }

        /* =============================================
           RESPONSIVE DESIGN - Mobile device adaptations
        ============================================= */
        @media (max-width: 768px) {
            /* Hero section mobile adaptation */
            .hero-section {
                /* Single column on mobile for vertical stacking */
                grid-template-columns: 1fr;
                /* Auto height for content-based sizing */
                height: auto;
            }
            
            /* Content section mobile adaptation */
            .content-section {
                /* Single column on mobile */
                grid-template-columns: 1fr;
            }
            
            /* Stats grid mobile adaptation */
            .stats-grid {
                /* Single column for stats on mobile - better use of space */
                grid-template-columns: 1fr;
            }
            
            /* Header controls mobile adaptation */
            .header-controls {
                /* Smaller gaps on mobile for compact layout */
                gap: 10px;
            }
            
            /* Search box mobile adaptation */
            .search-box {
                /* Smaller search box on mobile */
                width: 200px;
            }
            
            /* Search box focus mobile adaptation */
            .search-box:focus {
                /* Smaller expanded width on mobile */
                width: 250px;
            }
        }
    </style>
</head>

<!-- Apply current theme to body using data attribute -->
<!-- This enables CSS to target specific themes with attribute selectors -->
<body data-theme="<?php echo $current_theme; ?>">

    <!-- SIMPLE BACK TO DASHBOARD LINK -->
    <!-- Provides easy navigation back to main dashboard -->
    <div style="background: #333; padding: 15px; text-align: center;">
        <!-- Back to main dashboard link -->
        <a href="../dashboard-finance2/index.php" 
           style="color: white; text-decoration: none; padding: 12px 25px; background: #007bff; border-radius: 6px; font-weight: bold; display: inline-block;">
            ← Back to Zeeshan Dashboard  <!-- Navigation arrow and text -->
        </a>
        <!-- Link to income management page -->
        <a href="incomes.php" class="back-btn" style="margin: 0 10px; background: #27ae60; border-color: #27ae60;">
            💰 Go to Income Page  <!-- Money bag emoji and text -->
        </a>
    </div>

    <!-- =============================================
         DOLL SYSTEM - Animated character
    ============================================= -->
    <div class="doll-container">
        <?php if($show_doll): ?>
        <!-- Show doll message when form is submitted successfully -->
        <div class="doll-message" id="dollMessage">
            <!-- Main greeting from doll -->
            <div class="doll-text">Hello there! 👋</div>
            <!-- Success confirmation message -->
            <div class="doll-subtext">Expense recorded successfully!</div>
            <!-- Financial advice reminder -->
            <div class="doll-subtext">Stay mindful of your spending! 💡</div>
        </div>
        
        <!-- Auto-hide doll message after 5 seconds -->
        <!-- Prevents permanent screen clutter while providing feedback -->
        <script>
            // Set timeout to hide doll message after 5 seconds
            setTimeout(function() {
                // Get reference to doll message element
                const dollMessage = document.getElementById('dollMessage');
                // Check if element exists before trying to hide it
                if (dollMessage) {
                    // Hide the message by setting display to none
                    dollMessage.style.display = 'none';
                }
            }, 5000);  // 5000 milliseconds = 5 seconds
        </script>
        <?php endif; ?>
        
        <!-- Doll character always visible and interactive -->
        <!-- Clicking shows random financial tips -->
        <div class="doll-character" onclick="showRandomMessage()">
            💸  <!-- Money with wings emoji for doll character -->
        </div>
    </div>

    <!-- =============================================
         HEADER BAR - Fixed navigation
    ============================================= -->
    <div class="header-bar">
        <div class="header-content">
            <!-- Application title with emoji for visual appeal -->
            <div class="app-title">
                💰 Expense Management  <!-- Money bag emoji and app name -->
            </div>
            <div class="header-controls">
                <!-- Theme toggle button - switches between light/dark modes -->
                <button class="theme-toggle" onclick="toggleTheme()">
                    <!-- Dynamic button text based on current theme -->
                    <?php echo $current_theme == 'light' ? '🌙 Dark' : '☀️ Light'; ?> Mode
                </button>

                <!-- Time display widget - shows greeting and current time -->
                <div class="time-display">
                    <!-- Time-appropriate icon (sunrise, sun, sunset, moon) -->
                    <div class="time-icon"><?php echo $time_image; ?></div>
                    <!-- Dynamic greeting based on time of day -->
                    <div class="time-greeting"><?php echo $greeting; ?>!</div>
                    <!-- Current time in 12-hour format -->
                    <div class="time-text"><?php echo $current_time; ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main content container - holds all page content -->
    <div class="container">
        <div class="main-content">
            <!-- =============================================
                 HERO SECTION - Welcome and statistics
            ============================================= -->
            <div class="hero-section">
                <!-- Welcome card with inspirational quote and branding -->
                <div class="welcome-card">
                    <!-- Main page heading -->
                    <h1>Expense Management<br>System</h1>
                    <!-- Random inspirational financial quote -->
                    <p class="quote">"<?php echo $random_quote; ?>"</p>
                    <!-- Decorative icons container -->
                    <div style="display: flex; gap: 15px; margin-top: 20px;">
                        <!-- Money with wings icon -->
                        <div style="width: 60px; height: 60px; background: var(--accent-color); border-radius: 15px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: white;">💸</div>
                        <!-- Chart icon for statistics -->
                        <div style="width: 60px; height: 60px; background: var(--accent-secondary); border-radius: 15px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: white;">📊</div>
                        <!-- Target icon for goals -->
                        <div style="width: 60px; height: 60px; background: var(--warning-color); border-radius: 15px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: white;">🎯</div>
                    </div>
                </div>

                <!-- Statistics card - shows key metrics at a glance -->
                <div class="stats-card">
                    <div class="stats-grid">
                        <!-- Total expenses count -->
                        <div class="stat-item">
                            <!-- Dynamic total expenses count from database -->
                            <div class="stat-value"><?php echo $stats['total']; ?></div>
                            <div class="stat-label">Total Expenses</div>
                        </div>
                        <!-- Total amount spent -->
                        <div class="stat-item">
                            <!-- Formatted total amount with dollar sign and 2 decimal places -->
                            <div class="stat-value">$<?php echo number_format($stats['total_amount'], 2); ?></div>
                            <div class="stat-label">Total Amount</div>
                        </div>
                        <!-- Budget tracking concept -->
                        <div class="stat-item">
                            <!-- Target emoji for budgeting concept -->
                            <div class="stat-value">🎯</div>
                            <div class="stat-label">Smart Budgeting</div>
                        </div>
                        <!-- Financial control concept -->
                        <div class="stat-item">
                            <!-- Flexed bicep emoji for financial control -->
                            <div class="stat-value">💪</div>
                            <div class="stat-label">Financial Control</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- =============================================
                 MESSAGE DISPLAY - Success and error messages
            ============================================= -->
            <?php if($error): ?>
                <!-- Display error message if validation fails or database error occurs -->
                <div class="message error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if($success): ?>
                <!-- Display success message after successful operations -->
                <div class="message success"><?php echo $success; ?></div>
            <?php endif; ?>

            <!-- =============================================
                 MAIN CONTENT SECTION - Forms and data
            ============================================= -->
            <div class="content-section">
                <!-- ADD EXPENSE FORM CARD - Primary data entry form -->
                <div class="card">
                    <!-- Form section heading with plus icon -->
                    <h2>
                        <div class="card-icon">+</div>
                        Add New Expense
                    </h2>
                    <!-- Expense submission form -->
                    <form method="POST">
                        <!-- Amount input field - required monetary value -->
                        <div class="form-group">
                            <label>Amount ($)</label>
                            <!-- Number input for expense amount with validation -->
                            <input type="number" name="amount" step="0.01" min="0.01" 
                                   value="<?php echo $_POST['amount'] ?? ''; ?>" 
                                   placeholder="0.00" required id="amountInput">
                        </div>
                        
                        <!-- Vendor input field - where money was spent -->
                        <div class="form-group">
                            <label>Vendor</label>
                            <!-- Text input for vendor name with datalist for suggestions -->
                            <input type="text" name="vendor" 
                                   value="<?php echo $_POST['vendor'] ?? ''; ?>" 
                                   placeholder="Where did you spend?" required
                                   list="recentVendors" id="vendorInput">
                        </div>
                        
                        <!-- Date input field - when expense occurred -->
                        <div class="form-group">
                            <label>Date</label>
                            <!-- Date picker with max set to today to prevent future dates -->
                            <input type="date" name="date_spent" 
                                   value="<?php echo $_POST['date_spent'] ?? date('Y-m-d'); ?>" 
                                   max="<?php echo date('Y-m-d'); ?>" required id="dateInput">
                        </div>
                        
                        <!-- Description textarea - optional details about expense -->
                        <div class="form-group">
                            <label>Description (Optional)</label>
                            <!-- Multi-line text input for expense description -->
                            <textarea name="description" rows="3" 
                                      placeholder="What was this for?" id="descriptionInput"><?php echo $_POST['description'] ?? ''; ?></textarea>
                        </div>
                        
                        <!-- Submit button - triggers form processing -->
                        <button type="submit" name="add_expense" class="btn">Add Expense Record</button>
                    </form>
                </div>
                
                <!-- QUICK ADD EXPENSES - Common expense shortcuts -->
                <div class="card" style="margin-top: 20px;">
                    <!-- Quick add section heading -->
                    <h3>⚡ Quick Add Common Expenses</h3>
                    <!-- Grid layout for quick add buttons -->
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-top: 15px;">
                        <!-- Quick add buttons for common expenses -->
                        <!-- Coffee expense button -->
                        <button type="button" class="btn" onclick="quickExpense('Coffee', 5.00)" style="background: #8B4513;">☕ Coffee $5</button>
                        <!-- Lunch expense button -->
                        <button type="button" class="btn" onclick="quickExpense('Lunch', 15.00)" style="background: #FF6B35;">🍔 Lunch $15</button>
                        <!-- Groceries expense button -->
                        <button type="button" class="btn" onclick="quickExpense('Groceries', 50.00)" style="background: #2E8B57;">🛒 Groceries $50</button>
                        <!-- Fuel expense button -->
                        <button type="button" class="btn" onclick="quickExpense('Fuel', 40.00)" style="background: #4169E1;">⛽ Fuel $40</button>
                    </div>
                </div>

                <!-- QUICK STATS CARD - Financial insights and averages -->
                <div class="card">
                    <!-- Insights section heading with chart icon -->
                    <h2>
                        <div class="card-icon">📈</div>
                        Expense Insights
                    </h2>
                    
                    <!-- Average expense calculation -->
                    <div class="stat-item" style="margin-bottom: 20px;">
                        <div class="stat-value">
                            <?php 
                            // Calculate average expense amount
                            // Prevent division by zero if no expenses exist
                            $average = $stats['total'] > 0 ? $stats['total_amount'] / $stats['total'] : 0;
                            // Display formatted average with dollar sign
                            echo '$' . number_format($average, 2); 
                            ?>
                        </div>
                        <div class="stat-label">Average Expense</div>
                    </div>
                    
                    <!-- Daily spending tip - educational content -->
                    <div style="background: var(--card-bg); padding: 20px; border-radius: 15px; border: 1px solid var(--accent-secondary); margin-top: 20px;">
                        <!-- Tip heading with lightbulb emoji -->
                        <h4 style="color: var(--accent-secondary); margin-bottom: 10px;">💡 Spending Tip</h4>
                        <!-- Educational tip text -->
                        <p style="color: var(--text-color); line-height: 1.5; font-size: 0.9rem;">
                            Track every expense, no matter how small. Small purchases add up quickly over time!
                        </p>
                    </div>
                </div>
            </div>

            <!-- =============================================
                 SEARCH & FILTER SECTION - Data filtering interface
            ============================================= -->
            <div class="table-container">
                <!-- Search section heading with magnifying glass icon -->
                <h2 style="color: var(--accent-secondary); margin-bottom: 25px; display: flex; align-items: center; gap: 15px;">
                    <div class="card-icon">🔍</div>
                    Search & Filter Expense Records
                </h2>
                
                <!-- Simple Search Box - quick text search -->
                <form method="GET" style="margin-bottom: 20px;">
                    <!-- Text input for searching expense records -->
                    <input type="text" 
                           name="search_query" 
                           placeholder="Search expense records..." 
                           value="<?php echo htmlspecialchars($search_query); ?>"
                           style="width: 100%; padding: 12px; border: 2px solid var(--accent-secondary); border-radius: 8px;">
                </form>
                
                <!-- Filter Form - advanced filtering options -->
                <form method="GET" class="filter-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 20px;">
                    <!-- Hidden input to preserve search query when applying filters -->
                    <input type="hidden" name="search_query" value="<?php echo htmlspecialchars($search_query); ?>">
                    
                    <!-- Start date filter - expenses from specific date -->
                    <div class="form-group">
                        <label>From Date</label>
                        <!-- Date input for filtering expenses from a specific date -->
                        <input type="date" name="start_date" value="<?php echo htmlspecialchars($filter_start_date); ?>"
                               style="width: 100%; padding: 10px; border: 2px solid var(--accent-secondary); border-radius: 8px;">
                    </div>
                    
                    <!-- End date filter - expenses until specific date -->
                    <div class="form-group">
                        <label>To Date</label>
                        <!-- Date input for filtering expenses until a specific date -->
                        <input type="date" name="end_date" value="<?php echo htmlspecialchars($filter_end_date); ?>"
                               style="width: 100%; padding: 10px; border: 2px solid var(--accent-secondary); border-radius: 8px;">
                    </div>
                    
                    <!-- Minimum amount filter - expenses above certain value -->
                    <div class="form-group">
                        <label>Minimum Amount ($)</label>
                        <!-- Number input for filtering expenses by minimum amount -->
                        <input type="number" name="min_amount" step="0.01" value="<?php echo htmlspecialchars($filter_min_amount); ?>" placeholder="0.00"
                               style="width: 100%; padding: 10px; border: 2px solid var(--accent-secondary); border-radius: 8px;">
                    </div>
                    
                    <!-- Vendor search filter - specific store/merchant -->
                    <div class="form-group">
                        <label>Search Vendor</label>
                        <!-- Text input for filtering by vendor name -->
                        <input type="text" name="vendor_search" value="<?php echo htmlspecialchars($filter_vendor); ?>" placeholder="Store name..."
                               style="width: 100%; padding: 10px; border: 2px solid var(--accent-secondary); border-radius: 8px;">
                    </div>
                    
                    <!-- Filter actions - apply and clear filters -->
                    <div class="form-group" style="display: flex; flex-direction: column; gap: 10px;">
                        <!-- Submit button to apply filters -->
                        <button type="submit" class="btn" style="width: 100%">Apply Filters</button>
                        <!-- Link to clear all filters and return to default view -->
                        <a href="expenses.php" style="display: block; text-align: center; color: var(--accent-secondary); text-decoration: none; font-weight: 500;">Clear All</a>
                    </div>
                </form>
            </div>

            <!-- =============================================
                 EXPENSE HISTORY TABLE - Data presentation
            ============================================= -->
            <div class="table-container">
                <!-- History section heading with clipboard icon -->
                <h2 style="color: var(--accent-secondary); margin-bottom: 25px; display: flex; align-items: center; gap: 15px;">
                    <div class="card-icon">📋</div>
                    Expense History
                </h2>
                
                <!-- Export button - data export functionality -->
                <div style="text-align: right; margin-bottom: 20px;">
                    <!-- Link to export expenses to CSV file -->
                    <a href="export_expenses.php" class="btn" style="background: linear-gradient(135deg, #27ae60, #2ecc71); text-decoration: none;">
                        📥 Export to CSV  <!-- Download arrow emoji and text -->
                    </a>
                </div>
                
                <?php if(count($expenses) > 0): ?>
                    <!-- Expense data table - displays all filtered expenses -->
                    <table>
                        <thead>
                            <tr>
                                <th>Amount</th>        <!-- Column for expense amount -->
                                <th>Vendor</th>        <!-- Column for vendor name -->
                                <th>Date</th>          <!-- Column for expense date -->
                                <th>Description</th>   <!-- Column for expense description -->
                                <th>Actions</th>       <!-- Column for edit/delete actions -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($expenses as $expense): ?>
                            <tr>
                                <!-- Formatted amount with red color for expense emphasis -->
                                <td style="font-weight: 600; color: var(--accent-color);">
                                    <!-- Display amount with dollar sign and 2 decimal places -->
                                    $<?php echo number_format($expense['Amount'], 2); ?>
                                </td>
                                <!-- Vendor name with HTML special chars for security -->
                                <td><?php echo htmlspecialchars($expense['Vendor']); ?></td>
                                <!-- Date of expense in YYYY-MM-DD format -->
                                <td><?php echo $expense['DateSpent']; ?></td>
                                <!-- Description with HTML special chars for security -->
                                <td><?php echo htmlspecialchars($expense['Description']); ?></td>
                                <!-- Action links for edit and delete operations -->
                                <td class="action-links">
                                    <!-- Edit link with pencil emoji -->
                                    <a href="edit_expenses.php?id=<?php echo $expense['ExpenseID']; ?>">✏️ Edit</a>
                                    <!-- Delete link with trash can emoji and confirmation dialog -->
                                    <a href="delete_expenses.php?id=<?php echo $expense['ExpenseID']; ?>" 
                                       onclick="return confirm('Are you sure you want to delete this expense record?')">🗑️ Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <!-- Empty state message - shown when no expenses match filters -->
                    <p style="text-align: center; color: var(--text-color); opacity: 0.7; padding: 60px 20px; font-style: italic; font-size: 1.1rem;">
                        <!-- Dynamic message based on whether filters are active -->
                        No expense records found. <?php echo ($show_filters) ? 'Try adjusting your search filters.' : 'Start tracking by adding your first expense above.'; ?>
                    </p>
                <?php endif; ?>
            </div>

            <!-- =============================================
                 EXPENSE CHART - Data visualization
            ============================================= -->
            <div class="table-container">
                <!-- Chart section heading with bar chart icon -->
                <h2 style="color: var(--accent-secondary); margin-bottom: 25px; display: flex; align-items: center; gap: 15px;">
                    <div class="card-icon">📊</div>
                    Expense Statistics Chart
                </h2>
                
                <!-- Chart container - holds the Chart.js visualization -->
                <div style="height: 300px; background: var(--card-bg); border-radius: 15px; padding: 20px;">
                    <!-- Canvas element for Chart.js to render the chart -->
                    <canvas id="expenseChart"></canvas>
                </div>
                
                <script>
                    // Initialize expense chart using Chart.js
                    // Chart displays total amount, average expense, and record count
                    // Get canvas context for drawing
                    const ctx = document.getElementById('expenseChart').getContext('2d');
                    // Create new Chart instance
                    const expenseChart = new Chart(ctx, {
                        type: 'bar', // Bar chart for comparing different metrics
                        data: {
                            // Labels for each bar on x-axis
                            labels: ['Total Expenses', 'Average Expense', 'Records Count'],
                            datasets: [{
                                label: 'Expense Statistics',  // Dataset label for legend
                                // Data values from PHP for each bar
                                data: [
                                    <?php echo $stats['total_amount'] ?? 0; ?>,  // Total amount spent
                                    <?php echo $stats['total'] > 0 ? ($stats['total_amount'] / $stats['total']) : 0; ?>,  // Average expense
                                    <?php echo $stats['total'] ?? 0; ?>  // Total number of expenses
                                ],
                                // Background colors for each bar
                                backgroundColor: [
                                    'rgba(231, 76, 60, 0.8)',  // Red for total amount
                                    'rgba(52, 152, 219, 0.8)', // Blue for average
                                    'rgba(155, 89, 182, 0.8)'  // Purple for count
                                ],
                                // Border colors for each bar
                                borderColor: [
                                    'rgba(231, 76, 60, 1)',    // Solid red border
                                    'rgba(52, 152, 219, 1)',   // Solid blue border
                                    'rgba(155, 89, 182, 1)'    // Solid purple border
                                ],
                                borderWidth: 1  // 1px border width
                            }]
                        },
                        options: {
                            responsive: true, // Chart adjusts to container size
                            maintainAspectRatio: false, // Allows custom height without maintaining aspect ratio
                            scales: {
                                y: {
                                    beginAtZero: true // Y-axis starts at 0 for proper visualization
                                }
                            }
                        }
                    });
                </script>
            </div>
            
            <!-- =============================================
                 NAVIGATION - Back to dashboard
            ============================================= -->
            <a href="../dashboard-finance2/index.php" class="back-btn">
                ← Back to Dashboard  <!-- Left arrow and text for navigation -->
            </a>
        </div>
    </div>

    <!-- =============================================
         JAVASCRIPT FUNCTIONALITY
    ============================================= -->
    <script>
        // =============================================
        // THEME TOGGLE FUNCTIONALITY
        // =============================================
        function toggleTheme() {
            // Get current body element to read current theme
            const body = document.body;
            // Get current theme or default to light if not set
            const currentTheme = body.getAttribute('data-theme') || 'light';
            // Determine new theme (toggle between light and dark)
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            
            // Apply new theme to body using data attribute
            body.setAttribute('data-theme', newTheme);
            // Save theme preference to localStorage for persistence across page loads
            localStorage.setItem('theme', newTheme);
            
            // Update theme button text to reflect new state
            const themeButton = document.querySelector('.theme-toggle');
            // Check if theme button exists before updating
            if (themeButton) {
                // Set button text based on new theme
                themeButton.textContent = newTheme === 'light' ? '🌙 Dark Mode' : '☀️ Light Mode';
            }
            
            // Send theme preference to server for session persistence
            // This ensures theme is remembered even after browser restart
            fetch('update_theme.php', {
                method: 'POST',  // HTTP POST method
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},  // Form data content type
                body: 'theme=' + newTheme  // Send theme value as form data
            }).catch(err => console.log('Theme update error:', err));  // Log any errors
        }

        // =============================================
        // QUICK EXPENSE FUNCTION
        // =============================================
        function quickExpense(vendor, amount) {
            // Use IDs for reliable targeting of form fields
            // Fill vendor input with provided vendor name
            document.getElementById('vendorInput').value = vendor;
            // Fill amount input with provided amount
            document.getElementById('amountInput').value = amount;
            // Set date to today's date
            document.getElementById('dateInput').value = '<?php echo date('Y-m-d'); ?>';
            // Pre-fill description with quick add prefix
            document.getElementById('descriptionInput').value = 'Quick add: ' + vendor;
            
            // Scroll to the form so user sees it's filled
            // Provides visual feedback that quick add worked
            document.getElementById('vendorInput').scrollIntoView({ 
                behavior: 'smooth',  // Smooth scrolling animation
                block: 'center'      // Center the element in viewport
            });
            
            // Show confirmation message
            alert('🚀 Quick expense filled: ' + vendor + ' for $' + amount + '. Click "Add Expense Record" to save!');
        }

        // =============================================
        // DOLL RANDOM MESSAGE FUNCTION
        // =============================================
        function showRandomMessage() {
            // Array of random financial tips and motivational messages
            const messages = [
                "Track every expense to master your budget! 💪",
                "Small expenses today = Big savings tomorrow! 🌟",
                "Knowing where your money goes is financial power! 🔋",
                "Budgeting is telling your money where to go! 🎯",
                "Every tracked expense is a step toward financial freedom! 🚀",
                "Smart spending = More saving! 🏦"
            ];
            
            // Select random message from array using Math.random()
            const randomMessage = messages[Math.floor(Math.random() * messages.length)];
            
            // Create message element dynamically
            const messageDiv = document.createElement('div');
            // Apply doll message styling
            messageDiv.className = 'doll-message';
            // Set HTML content for the message
            messageDiv.innerHTML = `
                <div class="doll-text">Financial Tip! 💡</div>
                <div class="doll-subtext">${randomMessage}</div>
            `;
            
            // Add message to doll container above the character
            const dollContainer = document.querySelector('.doll-container');
            // Check if doll container exists
            if (dollContainer) {
                // Insert message before the doll character
                dollContainer.insertBefore(messageDiv, document.querySelector('.doll-character'));
                
                // Auto-remove message after 5 seconds to prevent clutter
                setTimeout(() => {
                    // Check if message still exists in DOM
                    if (messageDiv.parentNode) {
                        // Remove message from DOM
                        messageDiv.remove();
                    }
                }, 5000);  // Remove after 5 seconds
            }
        }

        // =============================================
        // AUTO-SCROLL TO RESULTS AFTER SEARCH/FILTER
        // =============================================
        document.addEventListener('DOMContentLoaded', function() {
            // Theme setup on page load - apply saved theme preference
            const savedTheme = localStorage.getItem('theme') || 'light';
            // Apply saved theme to body
            document.body.setAttribute('data-theme', savedTheme);
            
            // Update theme button text to match current theme
            const themeButton = document.querySelector('.theme-toggle');
            // Check if theme button exists
            if (themeButton) {
                // Set button text based on saved theme
                themeButton.textContent = savedTheme === 'light' ? '🌙 Dark Mode' : '☀️ Light Mode';
            }

            // Check if we have search/filter parameters in URL
            // This indicates user performed a search and we should show results
            const urlParams = new URLSearchParams(window.location.search);
            // Check if any search or filter parameters are present
            const hasSearch = urlParams.has('search_query') || urlParams.has('start_date') || 
                             urlParams.has('end_date') || urlParams.has('min_amount') || 
                             urlParams.has('vendor_search');
            
            // If search parameters exist, automatically scroll to results section
            if (hasSearch) {
                // Log for debugging
                console.log('Search detected, scrolling to results...');
                
                // Wait for page to fully load before scrolling
                setTimeout(() => {
                    // Find the expense history table container
                    const tableContainers = document.querySelectorAll('.table-container');
                    let resultsSection = null;
                    
                    // Look for the table container with expense history content
                    tableContainers.forEach(container => {
                        // Check if container has expense history content
                        if (container.innerHTML.includes('Expense History') || 
                            container.innerHTML.includes('expense records')) {
                            resultsSection = container;
                        }
                    });
                    
                    // If not found, use first table container as fallback
                    if (!resultsSection && tableContainers.length > 0) {
                        resultsSection = tableContainers[0];
                    }
                    
                    // Scroll to results section if found
                    if (resultsSection) {
                        // Log for debugging
                        console.log('Scrolling to results section');
                        // Smooth scroll to results section
                        resultsSection.scrollIntoView({ 
                            behavior: 'smooth', // Smooth scrolling animation
                            block: 'start' // Align to top of viewport
                        });
                        
                        // Add temporary highlight effect to draw attention to results
                        resultsSection.style.transition = 'all 0.5s ease';  // Smooth transition
                        resultsSection.style.boxShadow = '0 0 0 3px var(--accent-color)';  // Red glow effect
                        // Remove highlight after 2 seconds
                        setTimeout(() => {
                            resultsSection.style.boxShadow = ''; // Remove highlight
                        }, 2000);  // 2 second duration
                    }
                }, 300); // Small delay to ensure page is fully rendered
            }
        });
    </script>
</body>
</html>